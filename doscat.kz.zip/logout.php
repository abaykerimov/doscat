<?php
session_start();
//Include FB config file
require_once 'fbConfig.php';

//Unset user data from session
unset($_SESSION['userData']);
unset($_SESSION['user_id']);
unset($_SESSION['admin_id']);

//Destroy session data
$facebook->destroySession();

//Redirect to homepage
header("Location:index.php");
?>