<?php
//ini_set('error_reporting', E_ALL);
//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);
header('Content-type: text/html; charset=utf8');
session_start();
$gym_id = $_SESSION['gym_id'];
$status = $_SESSION['status'];
include("bd.php");
require_once 'actions/functions.php';
require_once 'actions/filter.php';

//получим массив по плану
$result = $conn->query("set names utf8");
if(isset($_GET['id']) and ($status == 1 || $status == 2)) {
    //надо проверить 1 админ я в сессии или не админ
    if ($_SESSION["admin_id"] > 0) {

    } else {
        $_SESSION['admin_id'] = $_SESSION['user_id'];
    }
    $_SESSION['user_id'] = $_GET['id'];
} else {
    if ($_SESSION["admin_id"] > 0) {
        $_SESSION["user_id"] = $_SESSION["admin_id"];
        $_SESSION['admin_id'] = 0;
    }
}
$id = $_SESSION["user_id"];
if (!isset($id) and !is_numeric($id)) {
    header("Location: login.php");
}

$active_plan = active($id);
$balance = balance($id);
if($status == 1 || $status == 0) {
    $sql = "SELECT u.id,u.first_name,u.last_name,u.email,u.phone,u.dateOfBirthday,
    (SELECT name FROM Gyms g WHERE g.id=u.id_gym) as gym_name,
    (SELECT address FROM Gyms g WHERE g.id=u.id_gym) as gym_address,u.custom_address,u.address_1,u.address_2,u.address_boolean,u.user_status,
    (SELECT lastPayment FROM HistoryOfPayment h WHERE h.user_id=u.id ORDER BY id DESC LIMIT 1) as lastPayment,
    (SELECT dateOfPayment FROM HistoryOfPayment h WHERE h.user_id=u.id ORDER BY id DESC LIMIT 1) as dateOfPayment,
    (SELECT paymentMethod FROM HistoryOfPayment h WHERE h.user_id=u.id ORDER BY id DESC LIMIT 1) as paymentMethod
    FROM Users u WHERE u.id = '$id'";
} else {
    $sql = "SELECT u.id,u.first_name,u.last_name,u.email,u.phone,u.dateOfBirthday,
    (SELECT name FROM Gyms g WHERE g.id=u.id_gym) as gym_name,
    (SELECT address FROM Gyms g WHERE g.id=u.id_gym) as gym_address,u.custom_address,u.address_1,u.address_2,u.address_boolean,u.user_status,
    (SELECT lastPayment FROM HistoryOfPayment h WHERE h.user_id=u.id ORDER BY id DESC LIMIT 1) as lastPayment,
    (SELECT dateOfPayment FROM HistoryOfPayment h WHERE h.user_id=u.id ORDER BY id DESC LIMIT 1) as dateOfPayment,
    (SELECT paymentMethod FROM HistoryOfPayment h WHERE h.user_id=u.id ORDER BY id DESC LIMIT 1) as paymentMethod
    FROM Users u WHERE u.id = '$id' AND u.id_gym = '$gym_id'";
}

$result = $conn->query($sql);

$row = $result->fetch_assoc();
$fname = $row['first_name'];
$lname = $row['last_name'];
$phone = $row['phone'];
$email = $row['email'];
$picture = $row['picture'];
$dateOfBirthday = $row['dateOfBirthday'];
$gym_name = $row['gym_name'];
$gym_address = $row['gym_address'];
$custom_address = $row['custom_address'];
$address1 = $row['address_1'];
$address2 = $row['address_2'];
$bool = $row['address_boolean'];
$lastPayment = $row['lastPayment'];
$dateOfPayment = $row['dateOfPayment'];
$paymentMethod = $row['paymentMethod'];
$user_status = $row['user_status'];
?>
<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name=viewport content="width=device-width, initial-scale=1">
    <meta http-equiv="content-type" content="text/html; charset=UTF-8"/>

    <title>Профиль <?php echo $fname. " ". $lname ?></title>
    <link rel="canonical" href=""/>
    <meta name="robots" content="index, follow"/>
    <meta name="keywords" content=""/>
    <meta name="description" content=""/>

    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet/less" type="text/css" href="css/main.less">
    <script type="text/javascript" src="js/less.min.js"></script>

    <!-- Include Bootstrap Datepicker -->
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/css/datepicker.min.css"/>
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/css/datepicker3.min.css"/>
    <style>
        .get{
            margin-top: 10px;
        }
        .block_cabinet .nav-tabs {
            margin-top: 10px;
        }
        .block_cabinet .nav-tabs li {
            width: auto;
            border: 1px;
        }
        .block_cabinet .nav-tabs li a {
            font-size: 16px;
        }
    </style>
</head>
<body>
<?php
include("template.php");
?>


<div class="container block_cabinet text-center" id="menu">
    <?php echo '<p style="text-align: left;font-size: 18px;margin-top: 20px;"><b>'.$fname.' '.$lname.'</b></p>' ?>
    <?php if($status == 1 || $status == 2) {echo '<p style="text-align: left;font-size: 18px;"><b>Баланс: '.$balance.'</b></p>';}  ?>
    <ul class="nav nav-tabs">
        <li><a href="profile.php?id=<?php echo $id ?>">Личные данные</a></li>
        <li><a href="pay.php?id=<?php echo $id ?>">Баланс и платежи</a></li>
        <li><a href="calendar.php?id=<?php echo $id ?>">Календарь питания</a></li>
        <li class = "active"><a href="#">Уведомления</a></li>

    </ul>
    <div id="myTabContent" class="col-lg-12">

        <div class="panel-title" style="font-size: 20px;text-align: center;margin-top: 15px;"><span>Уведомления</span></div><br>
        <table class="table table-hover " id="tablesorted" style="width: 100%">
            <thead>
            <tr>
                <th>Дата изменений</th>
                <th>Уведомления</th>
            </tr>
            </thead>
            <tbody class = "text-left">
            <?php
            //$first = date('Y-m-01');
            $query = "SELECT user_id, news, plan_id, date_now from News  WHERE user_id = $id";
            //я убрал  AND c.date BETWEEN '$first' AND '$last'
            $result = $conn->query($query);
            while ($row = $result->fetch_assoc()) {
                ?>
                <tr>
                    <td><?php echo $row['date_now'] ?></td>
                    <td><?php echo $row['news'] ?></td>
                </tr>
                <?php
            }
            $result->close();
            ?>
            </tbody>
        </table>

    </div>

</div>

<div class="block_footer">
    <div class="container text-center">
        <a href="#menu" class="scroll"><span class="glyphicon glyphicon-arrow-up"></span>НАВЕРХ</a>
        <br><br><br><br>
        <p class="lead">Алматы, 2017</p>
    </div>
</div>

</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://bootswatch.com/bower_components/bootstrap/dist/js/bootstrap.min.js" type="text/javascript"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/js/bootstrap-datepicker.min.js"></script>
<script type="text/javascript" src="js/owl.carousel.min.js"></script>
<script type="text/javascript" src="js/jquery.scrollTo.min.js"></script>
<script type="text/javascript" src="js/jquery.inputmask.bundle.js"></script>
<script type="text/javascript" src="js/sweetalert.min.js"></script>
<script type="text/javascript" src="js/js.js"></script>

<script>

    function actions(action, id){
        $.ajax({
            url: "admin/actions.php",
            data: {action: action, client_id:id},
            type: "POST",
            success: function (data) {
                switch (action) {
                    case "deleteClient":
                        window.location = "admin/clients.php";
                        break;
                }
            }
        })
    }

    !function(a){a.fn.datepicker.dates.ru={days:["Воскресенье","Понедельник","Вторник","Среда","Четверг","Пятница","Суббота"],daysShort:["Вск","Пнд","Втр","Срд","Чтв","Птн","Суб"],daysMin:["Вс","Пн","Вт","Ср","Чт","Пт","Сб"],months:["Январь","Февраль","Март","Апрель","Май","Июнь","Июль","Август","Сентябрь","Октябрь","Ноябрь","Декабрь"],monthsShort:["Янв","Фев","Мар","Апр","Май","Июн","Июл","Авг","Сен","Окт","Ноя","Дек"],today:"Сегодня",clear:"Очистить",format:"dd.mm.yyyy",weekStart:1}}(jQuery);

    $('.date').datepicker({
        autoclose: true,
        format: 'yyyy-mm-dd',
        language: 'ru',
        todayHighlight: true
    });

    if ($("input.checkbox").is(':checked')) {
        $('input[name=custom_address]').attr('disabled', true);
    }

    function update_user(action, id) {
        var first_name = $('#user_fname').val();
        var last_name = $('#user_lname').val();
        var phone = $('#user_phone').val();
        var email = $('#user_email').val();
        var db = $('#user_db').val();
        var gym = $("#user_gym").val();
        var check = $('input:checkbox:checked').val();
        var custom = $("#custom_address").val();
        var custom1 = $("#custom_address_1").val();
        var custom2 = $("#custom_address_2").val();
        var sum = $("#admin_sum").val();
        var pass1 = $("#pass1").val();
        var pass2 = $("#pass2").val();
        var user_status = $("#user_status").val();
        $.ajax({
            url: "admin/actions.php",
            data: {action: action, id: id, first_name: first_name, last_name: last_name, phone: phone, email: email, db: db,
                gym:gym, check:check, custom:custom, admin_sum:sum, pass1:pass1, pass2:pass2, custom1:custom1, custom2:custom2, user_status:user_status},
            type: "POST",
            success: function (data) {
                switch (action) {
                    case "editUserInfo":
                        if(data){
                            $(".alert1").append(data);
                            $("#alert1").fadeIn( 300 ).delay( 1500 ).fadeOut( 400);
                        } else {
                            $(".alert1").append("<div id='alert1' class='alert-box success'>Профиль изменен</div>");
                            $("#alert1").fadeIn( 300 ).delay( 1500 ).fadeOut( 400);
                        }

                        break;
                    case "editUserGym":
                        $(".alert2").append("<div id='alert2' class='alert-box success'>Спортзал изменен</div>");
                        $("#alert2").fadeIn( 300 ).delay( 1500 ).fadeOut( 400);
                        break;
                    case "editUserAddress":
                        $(".alert3").append("<div id='alert3' class='alert-box success'>Адрес изменен</div>");
                        $("#alert3").fadeIn( 300 ).delay( 1500 ).fadeOut( 400);
                        break;
                    case "editUserPassword":
                        if(data == 0) {
                            $(".alert4").append("<div id='alert4' class='alert-box success'>Пароли не совпадают!</div>");
                            $("#alert4").fadeIn( 300 ).delay( 1500 ).fadeOut( 400);
                        } else {
                            $(".alert4").append("<div id='alert4' class='alert-box success'>Пароль изменен</div>");
                            $("#alert4").fadeIn( 300 ).delay( 1500 ).fadeOut( 400);
                        }
                        break;
                }
            }
        });
        $("#alert1").remove();
        $("#alert2").remove();
        $("#alert3").remove();
        $("#alert4").remove();
    }

    function getAddress(action, value) {
        $.ajax({
            url: "admin/actions.php",
            data: {action:action,gym_id:value},
            type: "POST",
            success: function (data) {
                switch (action) {
                    case "getAddress":
                        $("#gym_address").html(data);
                        break;
                }
            }
        })
    }


    function boxDisable(e, t) {
        if (t.is(':checked')) {
            $(e).find('input[name=custom_address]').attr('disabled', true);
            $("#custom_address").val('');
        } else {
            $(e).find('input[name=custom_address]').removeAttr('disabled');
            $("#user_gym").val('');
            $("#gym_address").text('');
        }
    }

</script>
</html>