<?php
header('Content-type: text/html; charset=utf8');
session_start();
require_once 'fbConfig.php';
require_once 'User.php';
include("fbcontroller.php");

$id = $_SESSION['user_id'];
if ($id || $fbUser){
    header("Location: index.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Регистрация</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet/less" type="text/css" href="css/main.less">
    <script type="text/javascript" src="js/less.min.js"></script>
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
    <style type="text/css">
        body {
            padding-top: 20px;
            background-color: #f9f9f9;
        }
        .alert-success {
            background-color: rgba(0, 170, 29, 0.24);
            border-color: rgba(0, 170, 29, 0.24);
            color: #3c9a5f;
        }
        .container {
            position:relative;
            padding-top:30px;
            max-height:900px;
            padding-bottom:50px;
        }

        @media screen and (max-width: 600px) {
            form {
                width:auto;
                padding: 0 20px;
            }
        }
        img {
            border: none;
            max-width: 100%;
            height: auto;
            width: auto\9; /* ie8 */
        }
    </style>

    <script src="/js/jquery-1.11.3.min.js"></script>
    <script src="/js/bootstrap.min.js"></script>
    <style>
        .control-label {
            text-align: left !important;
        }
    </style>

</head>
<body>
<div class="container">

    <div id="signupbox" class="mainbox col-md-4 col-md-offset-4 col-sm-8 col-sm-offset-2">
        <div class="panel panel-info" style="background: #f9f9f9; border-color: #f9f9f9;">
            <div class="panel-heading" style="background: #f9f9f9; color: #585858; border-color: #f9f9f9;">
                <div class="panel-title" style="font-size: 15px;text-align:center"><span>Создать аккаунт</span></div>

            </div>
            <div class="panel-body">
                <form id="signupform" class="form-horizontal" role="form" style="text-align:left;">
                    <div id="signupalert" style="display:none" class="alert alert-danger">
                        <p>Error:</p>
                        <span></span>
                    </div>

                    <div style="margin-bottom: 10px" class="input-group">

                        <span class="input-group-addon"><i class="glyphicon glyphicon-envelope"></i></span>
                        <input id="email" type="text" class="form-control" name="email" value=""
                               placeholder="Почта" required>
                    </div>

                    <div style="margin-bottom: 10px" class="input-group">
                        <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                        <input type="text" class="form-control" name="firstname"
                               placeholder="Имя" required>
                    </div>

                    <div style="margin-bottom: 10px" class="input-group">
                        <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                        <input type="text" class="form-control" name="lastname"
                               placeholder="Фамилия" required>
                    </div>

                    <div style="margin-bottom: 10px" class="input-group">
                        <span class="input-group-addon"><i class="glyphicon glyphicon-phone"></i></span>
                        <input id="phone" type="text" class="form-control" name="phone"
                               placeholder="Телефон" required>
                    </div>

                    <div style="margin-bottom: 10px" class="input-group">
                        <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
                        <input type="password" class="form-control" name="passwd"
                               placeholder="Введите пароль" pattern=".{5,100}" required title="Пароль должен состоять как минимум из 5 символов">
                    </div>

                    <div style="margin-bottom: 10px" class="input-group">
                        <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
                        <input type="password" class="form-control" name="confpasswd"
                               placeholder="Подтвердите пароль" required>
                    </div>

                    <div style="margin-top:10px" class="form-group">
                        <!-- Button -->
                        <div class="col-sm-12 controls">
                            <input type="hidden" name="type" value="register">
                            <button id="btn-signup" type="submit" class="btn btn-info" style="width: 100%"><i
                                    class="glyphicon glyphicon-hand-right"></i> &nbsp;Зарегистрироваться
                            </button>
                        </div>
                    </div>
                </form>
				<p style="text-align: center">или войти</p>
                <a href="login.php"> <button class="btn btn-success" style="display: block;margin: 0 auto;">Войти</button></a>
            </div>
        </div>
    </div>
</div>
<script src="/js/ajaxscript.js"></script>
<script src="js/jquery.maskedinput.js"></script>
<script type="text/javascript">
    $(document).ready(function(){
        $("#phone").mask("+7 (999) 999-99-99");
    });
</script>
</body>
</html>
