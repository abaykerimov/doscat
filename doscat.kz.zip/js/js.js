$(document).ready(function(){

    //событие отправки формы, валидация не нужна, так как он сделает отправку, после стандартной валидации bootstrap
    $('#Zakaz').submit(function() {
        $('.sendzakaz').addClass('disabled');
        // начать повторы с интервалом 2 сек
        var count = 0,
            timerId = setInterval(function() {
                count++;
                if (count == 1) $('.sendzakaz').html("<span class='glyphicon glyphicon-chevron-right'></span>");
                if (count == 2) $('.sendzakaz').html("<span class='glyphicon glyphicon-chevron-right'></span><span class='glyphicon glyphicon-chevron-right'></span>");
                if (count == 3) $('.sendzakaz').html("<span class='glyphicon glyphicon-chevron-right'></span><span class='glyphicon glyphicon-chevron-right'></span><span class='glyphicon glyphicon-chevron-right'></span>");
                if (count == 4) $('.sendzakaz').html("<span class='glyphicon glyphicon-chevron-left'></span><span class='glyphicon glyphicon-chevron-left'></span><span class='glyphicon glyphicon-chevron-left'></span>");
                if (count == 5) $('.sendzakaz').html("<span class='glyphicon glyphicon-chevron-left'></span><span class='glyphicon glyphicon-chevron-left'></span>");
                if (count == 6) $('.sendzakaz').html("<span class='glyphicon glyphicon-chevron-left'></span>");
                if (count == 7) count = 0;
        }, 500);

        var name = $(".form-control.name").val();
        var phone = $(".form-control.phone").val();
        var program = $("#select").val();
        var days = $("#custom-handle").text();
        var sum = $("#costForAll").val();
        var surname = $(".form-control.surname").val();
        var mail = $(".form-control.mail").val();
        var date = $(".form-control.date").val();
        var dzen = $("input[name=dzen]:checked").val();
        var id_product = $("#id_product").val();

        var address = $("input[name=address]").val();
        var gym = $("select[name=gym]").val();

        $.ajax({
            type:'POST',
            url:'actions/addRequest.php',
            data:{user_name:name, phone:phone, program:program, days:days, sum:sum, surname:surname, mail:mail, date:date, dzen:dzen, address:address, gym:gym },
            success:function(responce){
                var answer = jQuery.parseJSON($.trim(responce));
                if (answer[0].status == "SUCCESS") {
                    swal("Отлично!", answer[0].message, "success");
                } else {
                    swal("Внимание!",answer[0].message, "warning")
                }
            },
            error:function(responce){
                swal("Ошибка!", "Попробуйте обновить страницу и повторить попытку", "error");
            }
        }).done(function(){
            //сказать что все ок
            $('.sendzakaz').removeClass('disabled').html('Отправить');
            clearInterval(timerId);

            $('#Zakaz').reset();
        });

        //запрет отправки, то есть перезагрузки страницы
        return false;
    });

});

$(function () {
    $("[rel='tooltip']").tooltip();

    $("input[type='tel']").inputmask("+7 (999) 999-99-99");

    $(".owl").owlCarousel({
        navigation : false, // Show next and prev buttons
        navigationText : ["",""],
        pagination : true,
        slideSpeed : 300,
        paginationSpeed : 400,
        autoPlay: 3000, //Set AutoPlay to 3 seconds
        stopOnHover : true,
        items : 6,
        itemsDesktop : [1199,5],
        itemsDesktopSmall : [979,4]
    });

    var $scrollto = $(".scroll");
    $scrollto.click(function(e) {
        e.preventDefault();
        $.scrollTo($($(this).attr('href')).offset().top-80,1400);
    });

    var $scrolltopocket = $(".scroll_pocket");
    $scrolltopocket.click(function(e) {
        e.preventDefault();
        var dataid = $(this).attr("data-id");
        $('#select option').each(function(){

            if (dataid == $(this).val()) {
                this.selected=true;
            } else {
                this.selected=false;
            }

        });

        $.scrollTo($($(this).attr('href')).offset().top-80,1400);
    });

});
