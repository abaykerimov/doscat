/**
 * Created by abay- on 09.02.2017.
 */
function getMenu(url, selector) {
    $.ajax({
        type: "GET",
        url: url,
        //dataType: "html",
        success: function(response){
            $(selector).html(response);
        },
        error: function(response){
            $(selector).html(response);
        }
    });
}

getMenu("actions/getMenu.php?program=1&d=yesterday", "#yes1200slim");
getMenu("actions/getMenu.php?program=1&d=today", "#today1200slim");
getMenu("actions/getMenu.php?program=1&d=tomorrow", "#tom1200slim");
getMenu("actions/getMenu.php?program=2&d=yesterday", "#yes2800slim");
getMenu("actions/getMenu.php?program=2&d=today", "#today2800slim");
getMenu("actions/getMenu.php?program=2&d=tomorrow", "#tom2800slim");

getMenu("actions/getMenu.php?program=3&d=yesterday", "#yes1200day");
getMenu("actions/getMenu.php?program=3&d=today", "#today1200day");
getMenu("actions/getMenu.php?program=3&d=tomorrow", "#tom1200day");
getMenu("actions/getMenu.php?program=4&d=yesterday", "#yes2800day");
getMenu("actions/getMenu.php?program=4&d=today", "#today2800day");
getMenu("actions/getMenu.php?program=4&d=tomorrow", "#tom2800day");