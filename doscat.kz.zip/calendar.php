<?php
//ini_set('error_reporting', E_ALL);
//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);
header('Content-type: text/html; charset=utf8');
session_start();
include("bd.php");
require_once 'actions/functions.php';
require_once 'actions/filter.php';

//получим массив по плану
$result = $conn->query("set names utf8");
if(isset($_GET['id']) and ($_SESSION['status'] == 1 || $_SESSION['status'] == 2)) {
    //надо проверить 1 админ я в сессии или не админ
    if ($_SESSION["admin_id"] > 0) {

    } else {
        $_SESSION['admin_id'] = $_SESSION['user_id'];
    }
    $_SESSION['user_id'] = $_GET['id'];
} else {
    if ($_SESSION["admin_id"] > 0) {
        $_SESSION["user_id"] = $_SESSION["admin_id"];
        $_SESSION['admin_id'] = 0;
    }
}
$id = $_SESSION["user_id"];
if (!isset($id) and !is_numeric($id)) {
    header("Location: login.php");
}

$active_plan = active($id);
$balance = balance($id);
$sql = "SELECT u.id,u.first_name,u.last_name,u.email,u.phone,u.dateOfBirthday,
    (SELECT name FROM Gyms g WHERE g.id=u.id_gym) as gym_name,
    (SELECT address FROM Gyms g WHERE g.id=u.id_gym) as gym_address,u.custom_address,u.address_boolean,
    (SELECT lastPayment FROM HistoryOfPayment h WHERE h.user_id=u.id ORDER BY id DESC LIMIT 1) as lastPayment,
    (SELECT dateOfPayment FROM HistoryOfPayment h WHERE h.user_id=u.id ORDER BY id DESC LIMIT 1) as dateOfPayment,
    (SELECT paymentMethod FROM HistoryOfPayment h WHERE h.user_id=u.id ORDER BY id DESC LIMIT 1) as paymentMethod
    FROM Users u WHERE u.id = '$id'";
$result = $conn->query($sql);

$row = $result->fetch_assoc();
$fname = $row['first_name'];
$lname = $row['last_name'];
$phone = $row['phone'];
$email = $row['email'];
$picture = $row['picture'];
$dateOfBirthday = $row['dateOfBirthday'];
$gym_name = $row['gym_name'];
$gym_address = $row['gym_address'];
$custom_address = $row['custom_address'];
$bool = $row['address_boolean'];
$lastPayment = $row['lastPayment'];
$dateOfPayment = $row['dateOfPayment'];
$paymentMethod = $row['paymentMethod'];
?>
<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name=viewport content="width=device-width, initial-scale=1">
    <meta http-equiv="content-type" content="text/html; charset=UTF-8"/>

    <title>Календарь профиля - <?php echo $fname. " ". $lname ?></title>
    <link rel="canonical" href=""/>
    <meta name="robots" content="index, follow"/>
    <meta name="keywords" content=""/>
    <meta name="description" content=""/>

    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet/less" type="text/css" href="css/main.less">
    <script type="text/javascript" src="js/less.min.js"></script>

    <!-- Include Bootstrap Datepicker -->
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/css/datepicker.min.css"/>
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/css/datepicker3.min.css"/>
    <style>
        .block_cabinet .nav-tabs {
            margin-top: 10px;
        }
        .block_cabinet .nav-tabs li {
            width: auto;
            border: 1px;
        }
        .block_cabinet .nav-tabs li a {
            font-size: 16px;
        }
        .table th {
            text-align: center;
        }
        .addBtn {
            margin-bottom: 20px;
        }
        select.del_status {
            margin-top: 0px;
            height: 40px;
            font-size: 13px;
            padding: 0px 15px;
        }
    </style>
</head>
<body>
<?php
include("template.php");
?>

<div class="container block_cabinet text-center" id="menu">
    <?php echo '<p style="text-align: left;font-size: 18px;margin-top: 20px;"><b>'.$fname.' '.$lname.'</b></p>' ?>
    <?php if($status == 1 || $status == 2) {echo '<p style="text-align: left;font-size: 18px;"><b>Баланс: '.$balance.'</b></p>';}  ?>
    <ul class="nav nav-tabs">
        <li><a href="profile.php?id=<?php echo $id ?>">Личные данные</a></li>
        <li><a href="pay.php?id=<?php echo $id ?>">Баланс и платежи</a></li>
        <li class="active"><a href="#">Календарь питания</a></li>
        <li><a href="api.php?id=<?php echo $id ?>">Уведомления</a></li>
    </ul>
    <br><br>
    <p class="text-center">Календарь активируется администратором сайта или менеджером спортзала.</p><br><br>
    <?php if($_SESSION['status'] == 1 || $_SESSION['status'] == 2) { ?>
    <button class="btn btn-success addBtn">Добавить план питания</button><br>
    <?php } ?>
    <form class="form-horizontal text-center addPlan" onsubmit="return false;">
        <fieldset>
            <p style="font-size: 17px; margin-top: 20px"><b>План питания</b></p>

            <div class="form-group">
                <label for="check_address" class="col-lg-4 control-label">Тип доставки:</label>
                <div class="col-lg-4 text-left">
                    <select class="form-control" id="type" required onchange="getProduct('getProduct', this.value)">
                        <option value="" disabled selected>--Выберите тип--</option>
                        <option value="1">По адресу</option>
                        <option value="2">В спортзал</option>
                    </select>
                </div>

            </div>

            <div class="form-group">
                <label for="check_address" class="col-lg-4 control-label">План питания:</label>
                <div class="col-lg-4 text-left">
                    <select class="form-control" id="product" required>
                        <option value="" disabled selected>--Выберите план питания--</option>
                    </select>
                </div>

            </div>
            <div class="form-group">
                <label for="custom_address" class="col-lg-4 control-label">Дата начала:</label>
                <div class="col-lg-4 text-left">
                    <input class="form-control date" id="date_start" placeholder="Выберите дату" type="text">
                </div>
            </div>
            <div class="form-group">
                <label for="custom_address" class="col-lg-4 control-label">Кол-во дней:</label>
                <div class="col-lg-4 text-left">
                    <input class="form-control days" id="days" placeholder="Количество дней в плане" type="number">
                </div>
            </div>
            <div class="form-group alert4">
                <div class="col-lg-12">
                    <button type="submit" class="btn btn-warning" onclick="update_plan(<?php echo $id ?>)">Сохранить</button>
                </div>
            </div>
        </fieldset>
    </form>
    <?php if ($active_plan['status'] == "true") { ?>
        <div class="text-left dnone">
            <p>План питания: <?php echo $active_plan['name_program']; ?></p>
            <p>Дата покупки: <?php echo human_date($active_plan['date_start']); ?></p>
            <p>Дата начала питания: <?php echo human_date($active_plan['date_start_eat']); ?></p>
            <p>Дней питания пройдено: <?php echo $active_plan['days_off']; ?></p>
            <p>Дней питания осталось: <?php echo ($active_plan['days']-$active_plan['days_off']); ?></p>
        </div>
        <br>
            <?php
            //$arr_calen = []; id_plan
            //$query_calen = $conn->prepare("SELECT date, plan_id FROM Calendars WHERE plan_id in (SELECT id FROM Plans WHERE user_id = ?) ORDER by date");
            //$query_calen->bind_param('i', $id);
            $query_calen = $conn->prepare("SELECT date, plan_id FROM Calendars WHERE plan_id = ? ORDER by date");
            $query_calen->bind_param('i', $active_plan['id_plan']);
            $query_calen->execute();
            $query_calen->store_result();
            if ($query_calen->num_rows > 0) {
                $query_calen->bind_result($date_calen,$plan_id_calen);
                while ($query_calen->fetch()) {

                    $arr_calen[] = array(
                        'date_calen' => $date_calen,
                        'plan_id_calen' => $plan_id_calen
                    );

                }
            }
            $query_calen->close();

            //надо вывести цикл из дат
            $date_begin = $active_plan['date_start'];
            $date_end = $active_plan['date_end'];

            //переменная для кипера
            $pitanie_iz_bd = "[";
            $pitanie_count = 0;

        $pitanie_iz_bd_not_change = "";
        foreach ($arr_calen as $i => $value) {
            $arr = $arr_calen[$i];

            if (date("G") > 14) {
                $date_15 = date('Y-m-d', strtotime(date('Y-m-d').' + 1 days'));
            } else {
                $date_15 = date('Y-m-d');
            }

            if ($arr['date_calen'] > $date_15) {
                if ($pitanie_count == 0) {
                    $pitanie_iz_bd = $pitanie_iz_bd."'".$arr['date_calen']."'";
                } else {
                    $pitanie_iz_bd = $pitanie_iz_bd.", '".$arr['date_calen']."'";
                }

                $pitanie_count = 1;

            } else {
                $pitanie_iz_bd_not_change = $pitanie_iz_bd_not_change."case '".$arr['date_calen']."': return { tooltip: 'Питание', classes: 'active no-change' }; ";
            }
        }

            $pitanie_iz_bd = $pitanie_iz_bd."]";


            ?>
            <br>
        <p>Вы можете заказать питание на завтрашний день только до 15:00!</p>
        <div id="date_range"></div>
        <p id="info_about_days"></p>
        <p><span class="span_blue"></span> - пройденные дни питания, <span class="span_yellow"></span> - планируемые дни питания</p>
        <br><br>
        <div class="panel-title" style="font-size: 20px;text-align: center;margin-top: 15px;"><span>Реестр заявок</span></div><br>
        <table class="table table-hover " style="width: 100%">
            <thead>
            <tr>
                <th>План питания</th>
                <th>Доставка</th>
                <th>Количество дней</th>
                <th>Дата начала питания</th>
                <th>Стоимость в день</th>
                <th>Стоимость всего</th>
                <th>Дата покупки</th>
                <th>Дней пройдено</th>
                <th>Дней осталось</th>
                <th>Статус заявки</th>
                <?php if($status == 1) {?>
                    <th><span class="glyphicon glyphicon-trash"></span></th>
                <?php } ?>
            </tr>
            </thead>
            <tbody>
                <?php
                //dropdown
                $sqlType = "SELECT id, name FROM Status_inPlans ORDER by id";
                $resultType = $conn->query($sqlType);
                while($rowType = $resultType->fetch_assoc()){
                    $arr_dropdown[] = array(
                        'id' => $rowType['id'],
                        'name' => $rowType['name']
                    );
                }
                $resultType->close();

                $query_reestr = $conn->prepare("SELECT p.id, (SELECT pp.name FROM Program pp WHERE pp.id = (SELECT program_id FROM Product WHERE id = p.product_id)) as product_name, p.date, p.price, p.days, (SELECT name FROM Delivery_inPlans WHERE id = p.delivery) as delivery, p.status, (SELECT name FROM Status_inPlans WHERE id = p.status) as status_name FROM Plans p WHERE user_id = ? ORDER by date DESC");
                $query_reestr->bind_param('i', $id);
                $query_reestr->execute();
                $query_reestr->store_result();
                if ($query_reestr->num_rows > 0) {
                    $query_reestr->bind_result($reestr_id,$reestr_prod_name,$reestr_date,$reestr_price,$reestr_days,$reestr_dostavka,$reestr_status_id,$status_name);
                    while ($query_reestr->fetch()) {

                        if ($active_plan['id_plan'] == $reestr_id) {
                            $dney_proideno = $active_plan['days_off'];
                            $dney_ostalos = ($active_plan['days']-$active_plan['days_off']);
                            $data_start_eat = $active_plan['date_start_eat'];
                            $greenclassfortr = " class='success'";
                        } else {

                            $query_dayoff = $conn->prepare("SELECT COUNT(d.id), min(c.date) FROM Calendars c JOIN Delivery d ON c.id = d.calendar_id WHERE c.date <= DATE_ADD(CURDATE(),INTERVAL 1 DAY) and d.status = 1 and c.plan_id = ?");
                            $query_dayoff->bind_param('i', $reestr_id);
                            $query_dayoff->execute();
                            $query_dayoff->store_result();
                            if ($query_dayoff->num_rows > 0) {
                                $query_dayoff->bind_result($dney_proideno,$data_start_eat);
                                while ($query_dayoff->fetch()) {


                                }
                            }
                            $query_dayoff->close();

                            $dney_ostalos = $reestr_days-$dney_proideno;

                            $greenclassfortr = '';
                        }

                        //создадим дропдаун
                        $dropdown = "<div class='form-group' style='display:inline;'><select class='input-sm form-control update_plan' data-id='".$reestr_id."'>";
                        foreach ($arr_dropdown as $i => $value) {
                            $arr = $arr_dropdown[$i];

                            if ($arr['id'] == $reestr_status_id) {
                                $check = " selected";
                            } else {
                                $check = "";
                            }

                            $dropdown = $dropdown."<option value='".$arr['id']."'".$check.">".$arr['name']."</option>";
                        }
                        $dropdown = $dropdown."</select></div>";

                        if($status == 1) {
                            $edit_admin = "<td>".$dropdown."</td><td><form class='delete_plan'><input type='hidden' name='id' value='".$reestr_id."'><button class='btn btn-danger btn-sm'><span class='glyphicon glyphicon-trash'></span></button></form></td>";
                        } else {
                            $edit_admin = "<td>".$status_name."</td>";
                        }

                        printf("
                        <tr%s>
                            <td>%s</td>
                            <td>%s</td>
                            <td>%s</td>
                            <td>%s</td>
                            <td>%s</td>
                            <td>%s</td>
                            <td>%s</td>
                            <td>%s</td>
                            <td>%s</td>
                            %s
                        </tr>
                        ",$greenclassfortr,$reestr_prod_name,$reestr_dostavka,$reestr_days,format_date($data_start_eat),$reestr_price,$reestr_price*$reestr_days,format_date($reestr_date),$dney_proideno,$dney_ostalos,$edit_admin);
                    }
                }
                $query_reestr->close();

                ?>
            </tbody>
        </table>

    <div class="panel-title" style="font-size: 20px;text-align: center;margin-top: 15px;"><span>Журнал доставки</span></div><br>
    <table class="table table-hover " id="tablesorted" style="width: 100%">
        <thead>
        <tr>
            <th>Дата календаря</th>
            <th>План питания</th>
            <th>Кол-во</th>
            <th>Адрес</th>
            <th>Цена в день</th>
            <th width="20%" style="text-align: center">Комментарий</th>
            <?php if($status == 1 || $status == 2) { ?>
            <th>Статус доставки</th>
            <?php } ?>
        </tr>
        </thead>
        <tbody>
        <?php
        //$first = date('Y-m-01');
        $first = $arr_calen[0]['date_calen'];
        $last = date('Y-m-t');
        $result = $conn->query("set names utf8");
        $query = "SELECT c.id, u.id as 'u_id', c.date, u.custom_address, (SELECT address FROM Gyms WHERE id = u.id_gym) as 'gym',
    u.first_name, u.last_name, u.phone, (SELECT (SELECT name FROM Program WHERE id = program_id) as 'name' FROM Product WHERE id = (SELECT product_id FROM Plans WHERE id = c.plan_id)) as 'plan',
    (SELECT quantity FROM Delivery WHERE calendar_id = c.id) as 'quantity', (SELECT admin_comment FROM Delivery WHERE calendar_id = c.id) as 'comment',
    (SELECT date_time FROM Delivery WHERE calendar_id = c.id) as 'time', (SELECT status FROM Delivery WHERE calendar_id = c.id) as 'status',
    (SELECT fact_time FROM Delivery WHERE calendar_id = c.id) as 'fact_time', (SELECT price FROM Product WHERE id = (SELECT product_id FROM Plans WHERE id = c.plan_id)) as 'price'
    FROM Calendars c JOIN Users u ON u.id = (SELECT user_id FROM Plans WHERE id = c.plan_id) WHERE u.id = '$id' ORDER BY c.date DESC";
        //я убрал  AND c.date BETWEEN '$first' AND '$last'
        $result = $conn->query($query);
        while ($row = $result->fetch_assoc()) {
            $date_sql = DateTime::createFromFormat('Y-m-d', $row['date']);
            $date = $date_sql->format("d-m-Y");

            if (!empty($row['status'])) {
                $pitanie_iz_bd_not_change = "case '".$row['date']."': return { classes: 'active no-change dostavka' };".$pitanie_iz_bd_not_change;
            }

            if ($row['status'] == 1) {
                $css = "style='color:green'";
            } else {
                $css = "style='color:red'";
            }

            ?>
            <tr>
                <td><?php echo $date ?><br><?php $date_day = new DateTime($date);echo numberforday($date_day->format("w")); ?></td>
                <td><?php echo $row['plan'] ?></td>
                <td><?php echo $row['quantity'] ?></td>
                <td class="text-left"><?php echo $row['custom_address']; if($row['custom_address']=="") echo $row['gym'] ?></td>
                <td><?php echo $row['price'] ?></td>
                <td><?php echo $row['comment'] ?></td>
                <td style="width: 18%">
                    <?php if($status == 1 || $status == 2) { ?>
                        <select class="form-control del_status" id="del_status_<?php echo $row['id'] ?>" onchange="getRequest('editCalendarDelivery', <?php echo $row['id'] ?>, this.value)" <?php echo $css ?>>
                            <option value="0"<?php if($row['status'] == 0) echo 'selected' ?>>Не доставлено</option>
                            <option value="1"<?php if($row['status'] == 1) echo 'selected' ?>>Доставлено</option>
                        </select>
                    <?php } else { echo $status_name; } ?>
                </td>
            </tr>
            <input type="hidden" id="del_user_id" value="<?php echo $row['u_id'] ?>">
            <?php
        }
        $result->close();
        ?>
        </tbody>
    </table>
    <?php } ?>
</div>

<div class="block_footer">
    <div class="container text-center">
        <a href="#menu" class="scroll"><span class="glyphicon glyphicon-arrow-up"></span>НАВЕРХ</a>
        <br><br><br><br>
        <p class="lead">Алматы, 2017</p>
    </div>
</div>

</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://bootswatch.com/bower_components/bootstrap/dist/js/bootstrap.min.js" type="text/javascript"></script>
<script src="js/bootstrap-datepicker.min.js"></script>
<script type="text/javascript" src="js/jquery.scrollTo.min.js"></script>
<script type="text/javascript" src="js/owl.carousel.min.js"></script>
<script type="text/javascript" src="js/sweetalert.min.js"></script>
<script type="text/javascript" src="js/jquery.inputmask.bundle.js"></script>
<script type="text/javascript" src="js/js.js"></script>
<script>

    !function(a){a.fn.datepicker.dates.ru={days:["Воскресенье","Понедельник","Вторник","Среда","Четверг","Пятница","Суббота"],daysShort:["Вск","Пнд","Втр","Срд","Чтв","Птн","Суб"],daysMin:["Вс","Пн","Вт","Ср","Чт","Пт","Сб"],months:["Январь","Февраль","Март","Апрель","Май","Июнь","Июль","Август","Сентябрь","Октябрь","Ноябрь","Декабрь"],monthsShort:["Янв","Фев","Мар","Апр","Май","Июн","Июл","Авг","Сен","Окт","Ноя","Дек"],today:"Сегодня",clear:"Очистить",format:"dd.mm.yyyy",weekStart:1,monthsTitle:"Месяцы"}}(jQuery);

    $('.date').datepicker({
            autoclose: true,
            format: 'yyyy-mm-dd',
            language: 'ru',
            todayHighlight: true
        });

    $(".addPlan").css("display", "none");
    $(".addBtn").click(function(){
        $(".addPlan").css("display", "block");
    });

    function getProduct(action, val){
        $.ajax({
            url: "admin/actions.php",
            data: {action: action, value:val},
            type: "POST",
            success: function (data) {
                switch (action) {
                    case "getProduct":
                        $("#product").html(data);
                        break;
                }
            }
        })
    }

    function update_plan(id){
        var product = $("#product").val();
        var date_start = $("#date_start").val();
        var days = $("#days").val();
        $.ajax({
            url: "actions/addPlan.php",
            data: {user_id:id, id_product:product, date_start:date_start, days:days},
            type: "POST",
            success: function (data) {
                $(".alert4").append("<div id='alert4' class='alert-box success'>Календарь создан</div>");
                $("#alert4").fadeIn( 300 ).delay( 1500 ).fadeOut( 400);
                location.reload();
            }
        })
    }

    $(function() {
        var $datepicker = $("#date_range");

        var arr_pitanie_iz_bd = <?php if (empty($pitanie_iz_bd)){echo 0;} else {echo $pitanie_iz_bd;} ?>;
        var count_multidate = <?php echo ($active_plan['days']+$active_plan['freezing']); ?>;
        var count_may_selected_dates = <?php echo ($active_plan['days']-$active_plan['days_off']); ?>;
        var selected_dates = 0;

        var Data = new Date();
        var startDate;
        if (Data.getHours() > 14) {
            startDate = '+2d';
        } else {
            startDate = '+1d';
        }


        $datepicker.datepicker({
            maxViewMode: 2,
            format: "yyyy-mm-dd",
            <?php if ($status != 1) { ?>
            //еще нужно разрешить до 15-00
            startDate: startDate,
            <?php } ?>
            endDate: "<?php echo $active_plan['date_end']; ?>",
            language: "ru",
            //multidate: count_may_selected_dates,
            multidate: true,
            todayHighlight: true,
            beforeShowDay: function (date){
                //if (date.getMonth() == (new Date()).getMonth()-1)
                //alert(date.getFullYear()+"-"+date.getMonth()+"-"+date.getDate());
                var month = parseInt(date.getMonth())+parseInt(1), data4;
                if (month < 10)  {
                    month = "0"+month;
                }
                if (date.getDate() > 9) {
                    data4 = date.getDate();
                } else {
                    data4 = "0"+date.getDate();
                }
                switch (date.getFullYear()+"-"+month+"-"+data4){
                    <?php echo $pitanie_iz_bd_not_change; ?>
                }
            }
        }).on("changeDate", function (e) {

            var arr_new_date = [];
            var arr_true_date = [];
            selected_dates = 0;

            //заполним массив выбранных дат
            for (var ii2 = 0, ll2 = count_multidate; ii2 < ll2; ii2++) {
                arr_new_date.push(e.format(ii2,'yyyy-mm-dd'));

                //посчитаем сколько уже выбрано дат
                if (e.format(ii2,'yyyy-mm-dd').length > 0) {
                    selected_dates++;
                    arr_true_date.push(e.format(ii2,'yyyy-mm-dd'));
                }
            }

            if (count_may_selected_dates < selected_dates) {
                //alert("fdf");
                delete arr_true_date[arr_true_date.length-1];
                $datepicker.datepicker('setDate', arr_true_date);
            } else {
                $("#info_about_days").html("Запланирована доставка питания на "+selected_dates+" день (дней) из "+count_may_selected_dates+" доступных.");
            }

            for (var ii = 0, ll = arr_new_date.length; ii < ll; ii++) {

                for (var i = 0, l = arr_pitanie_iz_bd.length; i < l; i++) {

                    if (arr_pitanie_iz_bd[i] == arr_new_date[ii]) {
                        //обнулим значения
                        arr_pitanie_iz_bd[i] = 0;
                        arr_new_date[ii] = 0;
                    }
                }
            }

            for (var i1 = 0, l1 = arr_pitanie_iz_bd.length; i1 < l1; i1++) {
                if (arr_pitanie_iz_bd[i1].length > 1) {
                    //отправим, чтобы удалилось
                    //alert("Delete - "+arr_pitanie_iz_bd[i1]);
                    addCalendar(arr_pitanie_iz_bd[i1]);
                }
            }

            for (var i2 = 0, l2 = arr_new_date.length; i2 < l2; i2++) {
                if (arr_new_date[i2].length > 1) {
                    //отправим, чтобы добавилось
                    //alert("Add - "+arr_new_date[i2]);
                    addCalendar(arr_new_date[i2]);
                }
            }

            arr_pitanie_iz_bd = [];
            for (var ii0 = 0, ll0 = count_multidate; ii0 < ll0; ii0++) {
                arr_pitanie_iz_bd.push(e.format(ii0,'yyyy-mm-dd'));
            }

            //alert(e.format(0,'yyyy-mm-dd'));
            //alert(e.format(1,'yyyy-mm-dd'));
            //alert(e.format(2,'yyyy-mm-dd'));
            //alert(e.date);
            //alert($datepicker.datepicker('getDates',{ format: "yyyy-mm-dd" }));


        });

        function addCalendar(date) {
            $.ajax({
                url: "actions/addCalendar.php",
                data: {date:date},
                type: "POST",
                success: function (responce) {
                    var answer = jQuery.parseJSON($.trim(responce));
                    if (answer[0].show) {
                        if (answer[0].status == "ERROR") {
                            //надо вернуть SELECT в прежнее состояние
                            //alert(date);

                            swal("Внимание!",answer[0].message, "warning");
                            //alert(answer[0].message);

                        } else {
                            swal("Отлично!",answer[0].message, "success");
                            //alert(answer[0].message);
                        }
                    }
                }
            });
        }

        $datepicker.datepicker('setDate', arr_pitanie_iz_bd);

        $('.delete_plan').submit(function() {
            var tr = $(this).parent().parent();

            var id = $(this).find("input[name=id]").val();

            swal({
                    title: "Подтвердите действие",
                    text: "Вы действительно хотите удалить запись?",
                    type: "info",
                    showCancelButton: true,
                    closeOnConfirm: false,
                    showLoaderOnConfirm: true,
                    confirmButtonText: "Да, удалить",
                    cancelButtonText: "Отмена"
                },
                function(){

                    $.ajax({
                        type:'POST',
                        url:'actions/updatePlans.php',
                        data:{type:"delete",id_plan:id},
                        success:function(responce){
                            var answer = jQuery.parseJSON($.trim(responce));

                            if (answer[0].status == "SUCCESS") {

                                //удалить запись из таблицы
                                tr.hide();

                                swal({
                                    title: "Отлично!",
                                    text: answer[0].message,
                                    type: "success",
                                    showCancelButton: false,
                                    closeOnConfirm: true,
                                    confirmButtonText: "Ок"
                                });

                            } else {
                                swal("Внимание!",answer[0].message, "warning")
                            }

                        },
                        error:function(responce){
                            swal("Ошибка!", "Попробуйте обновить страницу и повторить попытку", "error");
                        }
                    });

                });

            return false;
        });


        $(".update_plan").change(function(){
            var select = $(this);
            var status = select.val();
            var id = select.attr("data-id");

            select.attr("disabled","true");

            $.ajax({
                type:'POST',
                url:'actions/updatePlans.php',
                data:{type:"update",id_plan:id,status:status},
                success:function(responce){
                    var answer = jQuery.parseJSON($.trim(responce));

                    if (answer[0].status == "SUCCESS") {

                        select.parent().addClass("has-success");

                        //swal({
                        //    title: "Отлично!",
                        //    text: answer[0].message,
                        //    type: "success",
                        //    showCancelButton: false,
                        //    closeOnConfirm: true,
                        //    confirmButtonText: "Ок"
                        //});

                    } else {
                        select.parent().addClass("has-error");
                        swal("Внимание!","Ошибка! Попробуйте перезагрузить страницу.", "warning")
                    }

                },
                error:function(responce){
                    swal("Ошибка!", "Попробуйте обновить страницу и повторить попытку", "error");
                }
            }).done(function(){
                select.removeAttr("disabled");
            });



        });
    });

    function getRequest(action,val,status) {
        var user_id = $("#del_user_id").val();
        $.ajax({
            type: "POST",
            url: "admin/actions.php",
            data: {action:action,calendar:val,status_name:status,user_id:user_id},
            success: function(data){
                switch (action) {
                    case "editCalendarDelivery":
                        if(status == 0) {
                            $("#del_status_"+data).css("color", "red");
                        } else if(status == 1) {
                            $("#del_status_"+data).css("color", "green");
                        }
                        break;
                }

            }
        });
    }
</script>
</html>