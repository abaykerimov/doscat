<?php
session_start();

//Include Facebook SDK
require_once 'inc/facebook.php';

/*
 * Configuration and setup FB API
 */
$appId = '755951707885916'; //Facebook App ID
$appSecret = 'bc85739894e0809bad09c46d120685b8'; // Facebook App Secret
$redirectURL = 'http://www.doscat.kz/profile.php'; // Callback URL
$fbPermissions = 'email';  //Required facebook permissions

//Call Facebook API
$facebook = new Facebook(array(
  'appId'  => $appId,
  'secret' => $appSecret
));
$fbUser = $facebook->getUser();
?>