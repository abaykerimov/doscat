<?php
header('Content-type: text/html; charset=utf8');
include("bd.php");
include("actions/filter.php");
$error = "";
$msg = "";
error_reporting(0);
$check = 0;
$type = filter('type');
$firstname = filter("firstname");
$lastname = filter('lastname');
$passwd = filter('passwd');
$email = $_POST['email'];
$phone = filter('phone');

if (isset($_POST) && isset($type)) {

    if ($type == "login" && isset($_POST['email'], $_POST['password'])) {
        $p = md5(md5($_POST['password'] . md5(sha1($_POST['password']))));
        $query = $conn->query("SELECT * FROM Users WHERE email = '$email' AND password = '$p'");

        if ($query->num_rows == 1) {
            if($row = $query->fetch_assoc()){
                session_start();
                $_SESSION['user_id'] = $row['id'];
                $_SESSION['status'] = $row['user_status'];
                $_SESSION['gym_id'] = $row['id_gym'];

                if(!empty($_POST["remember"])) {
                    setcookie ("user_login",$_POST["email"],time()+ (10 * 365 * 24 * 60 * 60));
                    setcookie ("user_password",$_POST["password"],time()+ (10 * 365 * 24 * 60 * 60));
                } else {
                    if(isset($_COOKIE["user_login"])) {
                        setcookie ("user_login","");
                    }
                    if(isset($_COOKIE["user_password"])) {
                        setcookie ("user_password","");
                    }
                }
            }

            echo '{"error":0,"redir":"okk"}';
        } else {
            echo '{"error":1,"message":"Неправильные данные."}';
        }

    } else if ($type == "register" && isset($_POST['email'], $_POST['firstname'], $_POST['lastname'], $_POST['passwd'], $_POST['confpasswd'])) {

        $password = md5(md5($passwd . md5(sha1($passwd))));

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {

            echo '{"error":1,"message":"Введите валидную почту","focus":"email"}';

        } else {
            $query = $conn->query("SELECT id FROM Users WHERE email = '$email' OR phone = '$phone'");
            if ($query->num_rows > 0) {

                echo '{"error":2,"message":"Пользователь с такой почтой или телефоном уже существует."}';

            } else if ($passwd != $_POST['confpasswd']) {

                echo '{"error":1,"message":"Пароли не совпадают","focus":"confpasswd"}';

            } else {
				$query = $conn->query("set names utf8");
                $query = $conn->query("INSERT INTO Users (first_name,last_name, email,phone,password) VALUES('$firstname','$lastname','$email','$phone','$password')") or die($conn->error);
                echo '{"error":0,"message":"Пароль выслан на почту, спасибо.<br> <a href=\"login.php\">Нажмите</a>, чтобы войти","redir":"none"}';
                $check = 1;
            }
        }
    }

    $messageForAdmin = 'На сайте зарегистрирован новый пользователь:<br>

<p style="font-size:14px;">
Данные пользователя:<br>
Имя: '.$firstname.'<br>
Фамилия: '.$lastname.'<br>
Телефон: '.$phone.'<br>
Почта: '.$email.'<br>
Пароль: '.$passwd.' <br>
</p>';

    $message = 'Добрый день, '.$firstname.'!<br>

<p style="font-size:14px;">Спасибо за регистрацию на сайте Dostyk Catering! <br>
Ваши регистрационные данные:<br>
Имя: '.$firstname.'<br>
Фамилия: '.$lastname.'<br>
Телефон: '.$phone.'<br>
Почта: '.$email.'<br>
Пароль: '.$passwd.' <br>
<br>
<b>Рада знакомству! И прочитайте, пожалуйста, мое первое письмо для Вас.</b><br>
<br>
Меня зовут Жанар Дурманова. Dostyk Catering- это особый сервис здоровой еды. <br>
Лично для меня - это полное погружение и посвящение себя развитию этого <br>
непростого семейного дела. Я создала этот проект после того, как столкнулась на <br>
собственном опыте со  сложностями правильного питания в семье, не говоря уже об <br>
экологии в нашем городе. Как многодетную маму меня это сильно беспокоит, а как <br>
врачу-эндокринологу мне особенно хорошо известны последствия не правильного <br>
питания. Если вы это читаете, значит вы уже задумались об этом. Я искренне хочу <br>
помочь лично Вам и в целом нашим людям повысить культуру питания. Надеюсь вы <br>
станете нашим лучшим клиентом на долгое время и мы принесем пользу друг другу.<br>
<br>
Предлагаю отметить нашу Facebook-страницу <a href="http://facebook.com/dostykcatering">http://facebook.com/dostykcatering</a>, <br>
чтобы искать свой дзен здорового питания вместе.<br>
А на странице Instagram  <a href="http://instagram.com/dostykcatering">http://instagram.com/dostykcatering</a> мы регулярно проводим <br>
розыгрыши лотерей на демо-дни и прочие приятности.<br>
<br>
Что дает Вам регистрация на сайте Dostyk Catering:<br>
1. Информацию об актуальном меню на каждый день с указанием калориев /мы <br>
помогаем считать.<br>
2. Пополнение вашего Баланса /просто и удобно вести оплату.<br>
3. Управление Планами питания / вы ведь не стоите на месте.<br>
4. Управление Календарем питания через бронирование дней питания и <br>
перерывов для доставки / наша лучшая фишка.<br>
5. Управление вашими Бонусами / как приятно их копить ;)<br>
<br>
А еще вы можете получить не просто лучший сервис по доставке здорового питания, <br>
но и личные консультации от меня врача-эндокринолога, моей коллеги <br>
врача-диетолога и конечно нашего шеф-повара, который умеет готовить здоровую <br>
еду очень вкусно. Да, вас это может удивить и вы не поверите мне, пока не <br>
попробуете сами.<br>
<br>
Для начала я рекомендую Вам ознакомится с нашим Меню, потом с отличиями <br>
нашего Сервиса, далее выбрать необходимый План питания для себя. Для оплаты <br>
Вам нужно будет пополнить Баланс.<br>
<br>
Я всегда открыта и доступна для вопросов, пишите в любое время.<br>
<br>
Искренне ваша,<br>
Жанар Дурманова<br>
<a href="http://facebook.com/zhanardurmanova">http://facebook.com/zhanardurmanova</a> <br>
<br>
Директор <br>
Dostyk Catering, <br>
Ваш особый сервис здоровой еды<br>
<br>
Whatsapp:	+7-707-788-8989<br>
Telegram:	<a href="https://web.telegram.org/#/im?p=@DostykcateringBot">@dostykcateringbot</a> <br>
Site:		<a href="www.doscat.kz">www.doscat.kz</a> <br>
Facebook:	<a href="https://www.facebook.com/dostykcatering">https://www.facebook.com/dostykcatering</a><br>
Instagram:	<a href="http://instagram.com/dostykcatering">http://instagram.com/dostykcatering</a> <br>
Hashtag:	#doscat <br>
</p>';

    if ($check == 1){
        require 'phpmailer/PHPMailerAutoload.php';
        $date=date("Y-m-d H:i:s");
        $mail = new PHPMailer;
        $mail->isSMTP();                                      // Set mailer to use SMTP
        $mail->Host = 'mail.doscat.kz';  // Specify main and backup SMTP servers
        $mail->SMTPAuth = true;                               // Enable SMTP authentication
        $mail->Username = 'ok@doscat.kz';                 // SMTP username
        $mail->Password = 'iKqd24_8';                           // SMTP password
        $mail->SMTPSecure = 'ssl';                            // Enable TLS encryption, `ssl` also accepted
        $mail->Port = 465;                                    // TCP port to connect to
        $mail->From = 'ok@doscat.kz';
        $mail->FromName = 'ok@doscat.kz';
        $mail->addAddress('abaykerimov@gmail.com');
        $mail->addAddress('kozhaly@gmail.com');
        $mail->addAddress('art.denis@mail.ru');
        $mail->isHTML(true);                                  // Set email format to HTML
        $mail->CharSet = "UTF-8";
        $mail->Subject = 'Новый пользователь на сайте - '.$firstname.' '.$lastname;
        $mail->Body = $messageForAdmin;
        $mail->AltBody = 'Спасибо за регистрацию на сайте Dostyk Catering!';
        $mail->send();

        if (isset($email)) {
            $mail = new PHPMailer;
            $mail->isSMTP();                                      // Set mailer to use SMTP
            $mail->Host = 'mail.doscat.kz';  // Specify main and backup SMTP servers
            $mail->SMTPAuth = true;                               // Enable SMTP authentication
            $mail->Username = 'ok@doscat.kz';                 // SMTP username
            $mail->Password = 'iKqd24_8';                           // SMTP password
            $mail->SMTPSecure = 'ssl';                            // Enable TLS encryption, `ssl` also accepted
            $mail->Port = 465;                                    // TCP port to connect to
            $mail->From = 'ok@doscat.kz';
            $mail->FromName = 'ok@doscat.kz';
            $mail->addAddress($email);
            $mail->isHTML(true);                                  // Set email format to HTML
            $mail->CharSet = "UTF-8";
            $mail->Subject = 'Добро пожаловать в клуб Dostyk Catering, '.$firstname;
            $mail->Body = $message;
            $mail->AltBody = 'Спасибо за регистрацию на сайте Dostyk Catering!';
            $mail->send();

        }


    }
}

?>