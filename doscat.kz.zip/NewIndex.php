<?php
//ini_set('error_reporting', E_ALL);
//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);
session_start();
include("bd.php");
require_once 'fbConfig.php';
require_once 'User.php';

include("fbcontroller.php");

if(isset($_GET['id']) and ($_SESSION['user_id'] == 5 or $_SESSION['user_id'] == 16 or $_SESSION['admin_id'] == 16 or $_SESSION['admin_id'] == 5)) {
    //надо проверить 1 админ я в сессии или не админ
    if ($_SESSION["admin_id"] > 0) {

    } else {
        $_SESSION['admin_id'] = $_SESSION['user_id'];
    }
    $_SESSION['user_id'] = $_GET['id'];
} else {
    if ($_SESSION["admin_id"] > 0) {
        $_SESSION["user_id"] = $_SESSION["admin_id"];
        $_SESSION['admin_id'] = 0;
    }
}
$id = $_SESSION["user_id"];

$sql = "SELECT * FROM Users WHERE id = '$id'";
$result = $conn->query($sql);
$row = $result->fetch_assoc();
$fname = $row['first_name'];
$lname = $row['last_name'];
$phone = $row['phone'];
$email = $row['email'];
$picture = $row['picture'];
//$purse = $row['purse'];
//$male = $row['male'];
$dateOfBirthday = $row['dateOfBirthday'];
require_once 'actions/functions.php';
if (is_numeric($id)) {
    $active_plan = active($id);
}

?>
<!DOCTYPE html>
<html>
<head>    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

    <!--  Essential META Tags -->

    <meta property="og:title" content="Dostyk Catering- сервис здорового питания">
    <meta property="og:description" content="Dostyk Catering- сервис здорового питания в Алматы.">
    <meta property="og:image" content="http://doscat.kz/img/logos.png">
    <meta property="og:url" content="http://doscat.kz/">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!--  Non-Essential, But Recommended -->

    <meta name="og:site_name" content="Dostyk Catering- сервис здорового питания">
    <meta name="twitter:image:alt" content="Dostyk Catering- сервис здорового питания">

    <meta name=viewport content="width=device-width, initial-scale=1">
    <meta http-equiv="content-type" content="text/html; charset=UTF-8" />

    <title>Dostyk Catering- сервис здорового питания</title>
    <link rel="canonical" href=""/>
    <meta name="robots" content="index, follow" />
    <meta name="keywords" content="" />
    <meta name="description" content="" />

    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet/less" type="text/css" href="css/main.less">
    <script type="text/javascript" src="js/less.min.js"></script>


    <!-- Include Bootstrap Datepicker -->
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/css/datepicker.min.css"/>
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/css/datepicker3.min.css"/>

    <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png">
    <link rel="icon" type="image/png" href="/favicon-32x32.png" sizes="32x32">
    <link rel="icon" type="image/png" href="/favicon-16x16.png" sizes="16x16">
    <link rel="manifest" href="/manifest.json">
    <link rel="mask-icon" href="/safari-pinned-tab.svg" color="#5bbad5">
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <link rel="stylesheet" href="/resources/demos/style.css">

    <meta name="theme-color" content="#ffffff">


    <style>
        #block-for-slider {
            width: 100%;
            margin: 0 auto;
            margin-top: -15px;
        }

        #viewport {
            width: 100%;
            position: relative;
            overflow: hidden;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            -o-user-select: none;
            user-select: none;
            text-align: center;
        }

        #slidewrapper {
            position: relative;
            width: calc(100% * 4);
            -webkit-transition: 1s;
            -o-transition: 1s;
            transition: 1s;
            -webkit-transition-timing-function: cubic-bezier(.67,.01,.23,1);
            -o-transition-timing-function: cubic-bezier(.67,.01,.23,1);
            transition-timing-function: cubic-bezier(.67,.01,.23,1);
        }

        #slidewrapper, #slidewrapper ul, #slidewrapper li {
            margin: 0;
            padding: 0;
        }

        .slide {
            width: calc(100%/4);
            list-style: none;
            display: inline;
            float: left;
        }

        .slide-img {
            width: 100%;
        }

        #prev-btn, #next-btn {
            position: absolute;
            width: 50px;
            height: 50px;
            background-color: #fff;
            border-radius: 50%;
            top: calc(50% - 25px);
        }

        #prev-btn:hover, #next-btn:hover {
            cursor: pointer;
        }

        #prev-btn {
            left: 20px;
        }

        #next-btn {
            right: 20px;
        }

        #nav-btns {
            position: absolute;
            width: 100%;
            bottom: 20px;
            padding: 0;
            margin: 0;
            text-align: center;
        }

        .slide-nav-btn {
            position: relative;
            display: inline-block;
            list-style: none;
            width: 20px;
            height: 20px;
            background-color: #fff;
            border-radius: 50%;
            margin: 3px;
        }

        .slide-nav-btn:hover {
            cursor: pointer;
        }
        #custom-handle {
            width: 1.5em;
            height: 1.6em;
            top: 50%;
            margin-top: -.8em;
            text-align: center;
            line-height: 1.6em;
            background-color: yellow;
            font: 12pt Tahoma;
        }
        .block_menu .nav-tabs li {
            max-width: 50%;
            margin-left: 0;
        }
        span.glyphicon {
            color: #869791;
        }
        .carousel-inner>.active {
            display: block;
        }
        #slider::after
        {
            position: absolute;
            margin-left: 25%;
            content: "7";
            top: -25px;
            color: white;
            width: 24px;
            left: 0;
            font: 12pt Tahoma;
        }
        #slider::before
        {
            position: absolute;
            margin-left: 55%;
            content: "14";
            top: -25px;
            color: white;
            width: 24px;
            left: 0;
            font: 12pt Tahoma;
        }
        #sliderCover::after
        {
            position: absolute;
            margin-left: -1%;
            content: "1";
            top: -25px;
            color: white;
            width: 24px;
            left: 0;
            font: 12pt Tahoma;
        }
        #sliderCover::before
        {
            position: absolute;
            margin-left: 85%;
            content: "21";
            top: -25px;
            color: white;
            width: 24px;
            left: 0;
            font: 12pt Tahoma;
        }


    </style>
</head>
<body>
<nav class="navbar navbar-default navbar-fixed-top"<?php if (isset($fname)) {echo ' style="min-height: 81px"';} ?>>
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="index.php"><img src="img/logo.png" alt="Dostyk Catering - правильное питание с доставкой по Алматы"></a>
        </div>

        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav navbar-right">
                <?php
                if (isset($fname)){
                    ?>
                    <li><a href = "profile.php"><?php echo $fname; ?><br><?php echo $lname; ?></a></li>
                    <li><a href = "profile.php#balance">Баланс <br><?php echo number_format(balance($id), 0, ',', ' '); ?> тг</a></li>
                    <li><a href = "profile.php#kalendar">Спортзал<br> </a></li>
                    <li><a href = "profile.php#plan">План питания <br><?php if (empty($active_plan['name_product'])) {echo "Не выбран";} else {echo $active_plan['name_product'];} ?></a></li>

                    <?php
                } else {
                    ?>
                    <li><a href="login.php">Вход</a></li>
                    <li><a href="register.php">Регистрация</a></li>
                    <?php
                }
                ?>
                <?php if($fbUser || $id) { ?>
                    <li><a href="logout.php">Выйти</a></li>
                <?php } ?>
            </ul>
        </div>
    </div>
</nav>
<nav class="navbar navbar-inverse"<?php if (isset($fname)) {echo ' style="margin-top: 81px"';} ?>>
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-2">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
        </div>
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-2">
            <ul class="nav navbar-nav">
                <li><a href="#block_menu" class="scroll">Меню</a></li>
                <li><a href="#programs" class="scroll">Программы</a></li>
                <li><a href="http://doscat.kz/pay.php">Оплата</a></li>
                <li><a href="#partners" class="scroll">Партнеры</a></li>
                <li><a href="#about" class="scroll">Контакты</a></li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <li><a href="http://facebook.com/dostykcatering/" target="_blank" title="Мы в Facebook"><img class="ss" src="img/facebook.png" alt=""></a></li>
                <li><a href="https://www.instagram.com/dostykcatering/" target="_blank" title="Мы в Instagram"><img class="ss" src="img/instagram.png" alt=""></a></li>
                <li><a href="tel:+77079110502"><img class="ss" src="img/whatsapp.png" alt=""> +7 (707) 911-0502</a></li>
            </ul>
            <div class="navbar-form navbar-right">
                <!--<a href="#form" class="btn btn-warning" role="button" data-toggle="modal">Оставить заявку</a>-->
                <a href="#form" class="btn btn-warning scroll">Оставить заявку</a>
            </div>
        </div>
    </div>
</nav>

    <div id="block-for-slider">
        <div id="viewport">
            <ul id="slidewrapper">
                <li class="slide"><img src="https://hsto.org/files/8d4/b19/80d/8d4b1980d48c418090e2c4466d8c06e1.jpg" alt="1" class="slide-img"></li>
                <li class="slide"><img src="https://hsto.org/files/ef1/3d7/97e/ef13d797e4c642c7a1d4b2b91f7ad7b3.jpg" alt="2" class="slide-img"></li>
                <li class="slide"><img src="https://hsto.org/files/ec5/592/f1e/ec5592f1e814401eb38305682a8e88d4.jpg" alt="3" class="slide-img"></li>
                <li class="slide"><img src="https://hsto.org/files/eda/61a/3c5/eda61a3c53db408d820643998d9acd81.jpg" alt="4" class="slide-img"></li>
            </ul>

            <div id="prev-next-btns">
                <div id="prev-btn"></div>
                <div id="next-btn"></div>
            </div>

            <ul id="nav-btns">
                <li class="slide-nav-btn"></li>
                <li class="slide-nav-btn"></li>
                <li class="slide-nav-btn"></li>
                <li class="slide-nav-btn"></li>
            </ul>
        </div>
    </div>




<div class="block_price" id="programs" style="margin-top:20px;">
    <div class="container block_form text-center" id="form">
        <h1 class="main">О проекте</h1>

    </div>
</div>


<!-- HTML-код модального окна -->



<div class="block_partenrs text-center" id="partners">
    <div class="container text-center">
        <h1 class="main">Оставить заявку</h1>
        <div class="form-group" style="margin: auto; margin-left: 20%">
            <div class="col-lg-8">
                <select class="form-control" name="program" id="select" onchange="getDescription('getDescriptions', this.value);ForSinglePrice('getSinglePrice', this.value);" required>
                    <option value="" disabled selected >--Выберите план питания--</option>
                    <?php
                    $query = "SELECT  name, id FROM Program";
                    $results = $conn->query($query);
                    while ($row = $results->fetch_assoc()) { ?>
                        <option value="<?php echo $row["id"]; ?>"><?php echo $row["name"]; ?> </option>
                    <?php } ?>
                </select>
            </div>
            <div class="form-group">
                <br><br><br>
                <div class="col-lg-8 text-left">
                    <input class="form-control costPerDay" id="costPerDay" type="text" name="costPerDay" placeholder="Ваше имя">
                </div>
            </div>
            <div class="form-group">
                <br><br>
                <div class="col-lg-8 text-left">
                    <input class="form-control costPerDay" id="costPerDay" type="text" name="costPerDay" placeholder="Ваша почта">
                </div>
            </div>
            <br><br>
            <div class="form-group">
                <div class="col-lg-8">
                    <input class="form-control phone" id="inputPhone" type="tel" name="phone" required placeholder="Номер телефона">
                </div>
            </div>
        </div>
    </div>
</div>

<div class="block_about text-center" id="about">
    <div class="container">
        <div class="info">
            <div class="tocenter">
                <p class="lead"><span class="glyphicon glyphicon-map-marker"></span> <strong> Адрес:</strong> г. Алматы,
                    ТРЦ Ритц-Палас, пр.Аль-фараби, 1</p>
                <p class="lead"><span class="glyphicon glyphicon-envelope"></span> <strong> E-mail:</strong> zhkiro@gmail.com</p>
                <p class="lead"><span class="fa fa-whatsapp"></span> <strong> Whatsapp:</strong> <a
                        href="tel:+77079110502"> +7(707) 911-0502</a></p>
            </div>
        </div>
    </div>
    <script type="text/javascript" charset="utf-8" async src="https://api-maps.yandex.ru/services/constructor/1.0/js/?sid=3acBKpQRKAWA_qzil9zEO-Vfgof_9nLf&amp;width=100%25&amp;height=400&amp;lang=ru_RU&amp;sourceType=constructor&amp;scroll=false"></script>
</div>
<ul class="bxslider">
    <li>
        <iframe src="http://player.vimeo.com/video/17914974" width="500" height="281" frameborder="0" webkitAllowFullScreen mozallowfullscreen allowFullScreen></iframe>
    </li>
    <li><img src="https://hsto.org/files/eda/61a/3c5/eda61a3c53db408d820643998d9acd81.jpg" /></li>
</ul>
<div class="block_footer">
    <div class="container text-center">
        <a href="#block_menu" class="scroll"><span class="glyphicon glyphicon-arrow-up"></span>НАВЕРХ</a>
        <br><br><br><br>
        <p class="lead">Алматы, 2017</p>
    </div>
</div>

</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://bootswatch.com/bower_components/bootstrap/dist/js/bootstrap.min.js" type="text/javascript"></script>
<script src="js/bootstrap-datepicker.min.js"></script>
<script type="text/javascript" src="js/owl.carousel.min.js"></script>
<script type="text/javascript" src="js/sweetalert.min.js"></script>
<script type="text/javascript" src="js/jquery.scrollTo.min.js"></script>
<script type="text/javascript" src="js/jquery.inputmask.bundle.js"></script>
<script type="text/javascript" src="js/js.js"></script>

<script src="https://use.fontawesome.com/3173fe6f59.js"></script>

<script>
    $(function () {
        $('#inputDate').datepicker({
            autoclose: true,
            dateFormat: 'yy-mm-dd',
            language: 'ru',
            todayHighlight: true
        });
        $.datepicker.regional['ru'] = {clearStatus: '',
            monthNames: ['Январь','Февраль','Март','Апрель','Май','Июнь',
                'Июль','Август','Сентябрь','Октябрь','Ноябрь','Декабрь'],
            monthNamesShort: ['Янв','Фев','Мар','Апр','Май','Июн',
                'Июл','Авг','Сен','Окт','Ноя','Дек'],
            dayNames: ['Воскресенье','Понедельник','Вторник','Среда','Четверг','Пятница','Суббота'],
            dayNamesShort: ['Вс','Пн','Вт','Ср','Чт','Пт','Сб'],
            dayNamesMin: ['Вс','Пн','Вт','Ср','Чт','Пт','Сб'],
            firstDay: 1 };
        $.datepicker.setDefaults($.datepicker.regional['ru']);
    });

    function getValueToZero() {
        $( "#custom-handle" ).css('left', '0%');
        $( "#custom-handle" ).text(1);
        $("#costPerDay").val(0);
        $("#costForAll").val(0);
        $("#save").val(0);
    }

</script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script src="/js/plugins/jquery.fitvids.js"></script>
<script src="/js/jquery.bxslider.js"></script>
<script>
    $("#gym_select").hide();
    function getDescription(action, value) {

        $.ajax({
            url: "admin/actionsGani.php",
            data: {action:action, program_id:value},
            type: "POST",
            success: function (data) {
                switch (action) {
                    case "getDescriptions":
                        $("#photodesc").html(data);
                        $("#Attention").text("");
                        break;
                }
            }
        })
    }

    function ForSinglePrice(action, value) {
        var  singlePrice;
        var typeSinglePrice = $('input[name="dzen"]:checked').val();

        $.ajax({
            url: "admin/actionsGani.php",
            data: {action:action, program_id:value, type:typeSinglePrice},
            type: "POST",
            success: function (data) {
                switch (action) {
                    case "getSinglePrice":
                        var arr = data.split("_");
                        singlePrice = arr[0];
                        $('#id_product').val(arr[1]);
                        $( "#custom-handle" ).css('left', '0%');
                        $( "#custom-handle" ).text(1);
                        $("#costPerDay").val(singlePrice);
                        $("#costForAll").val(singlePrice);
                        $("#save").val(0);
                        break;
                }
            }
        })
    }
    function ForSinglePriceCheckbox(action, value) {
        var  singlePrice;
        var  a = $('#select option:selected').val();

        $.ajax({
            url: "admin/actionsGani.php",
            data: {action:action, program_id:a, type:value},
            type: "POST",
            success: function (data) {
                switch (action) {
                    case "getSinglePriceForCheckbox":
                        var arr = data.split("_");
                        singlePrice = arr[0];
                        $('#id_product').val(arr[1]);
                        $( "#custom-handle" ).css('left', '0%');
                        $( "#custom-handle" ).text(1);
                        $("#costPerDay").val(singlePrice);
                        $("#costForAll").val(singlePrice);
                        $("#save").val(0);
                        break;
                }
            }
        })
    }
    $('.bxslider').bxSlider({
        video: true,
        useCSS: false
    });
    function getPrice(Price, highPrice, value )
    {
        if (value<7)
        {
            $("#costForAll").val(value*Price);
            $("#save").val(0);
        }
        if (value>=7 && value<14)
        {
            $("#costForAll").val(value *Price);
            $("#save").val(value*(highPrice-Price));
        }
        if (value>=14 && value<21)
        {
            $("#costForAll").val(value *Price);
            $("#save").val(value*(highPrice-Price));
        }

        if (value>=21 )
        {
            $("#costForAll").val(value *Price);
            $("#save").val(value*(highPrice-Price));
        }
    }

</script>

<script>(function(d, s, id) {
        var js, fjs = d.getElementsByTagName(s)[0];
        if (d.getElementById(id)) return;
        js = d.createElement(s); js.id = id;
        js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.8&appId=1248719045210121";
        fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'facebook-jssdk'));

    function getMenu(url, selector) {
        $.ajax({
            type: "GET",
            url: url,
            //dataType: "html",
            success: function(response){
                $(selector).html(response);
            },
            error: function(response){
                $(selector).html(response);
            }
        });
    }
    function changeTypeInbox(value) {
        if(value == 1) {
            $("#gym_select").hide();
            $("#custom_address").show();
        }
        if (value == 2)
        {
            $("#gym_select").show();
            $("#custom_address").hide();
        }
    }
    var slideNow = 1;
    var slideCount = $('#slidewrapper').children().length;
    var slideInterval = 3000;
    var navBtnId = 0;
    var translateWidth = 0;

    $(document).ready(function() {
        var switchInterval = setInterval(nextSlide, slideInterval);

        $('#viewport').hover(function() {
            clearInterval(switchInterval);
        }, function() {
            switchInterval = setInterval(nextSlide, slideInterval);
        });

        $('#next-btn').click(function() {
            nextSlide();
        });

        $('#prev-btn').click(function() {
            prevSlide();
        });

        $('.slide-nav-btn').click(function() {
            navBtnId = $(this).index();

            if (navBtnId + 1 != slideNow) {
                translateWidth = -$('#viewport').width() * (navBtnId);
                $('#slidewrapper').css({
                    'transform': 'translate(' + translateWidth + 'px, 0)',
                    '-webkit-transform': 'translate(' + translateWidth + 'px, 0)',
                    '-ms-transform': 'translate(' + translateWidth + 'px, 0)',
                });
                slideNow = navBtnId + 1;
            }
        });
    });


    function nextSlide() {
        if (slideNow == slideCount || slideNow <= 0 || slideNow > slideCount) {
            $('#slidewrapper').css('transform', 'translate(0, 0)');
            slideNow = 1;
        } else {
            translateWidth = -$('#viewport').width() * (slideNow);
            $('#slidewrapper').css({
                'transform': 'translate(' + translateWidth + 'px, 0)',
                '-webkit-transform': 'translate(' + translateWidth + 'px, 0)',
                '-ms-transform': 'translate(' + translateWidth + 'px, 0)',
            });
            slideNow++;
        }
    }

    function prevSlide() {
        if (slideNow == 1 || slideNow <= 0 || slideNow > slideCount) {
            translateWidth = -$('#viewport').width() * (slideCount - 1);
            $('#slidewrapper').css({
                'transform': 'translate(' + translateWidth + 'px, 0)',
                '-webkit-transform': 'translate(' + translateWidth + 'px, 0)',
                '-ms-transform': 'translate(' + translateWidth + 'px, 0)',
            });
            slideNow = slideCount;
        } else {
            translateWidth = -$('#viewport').width() * (slideNow - 2);
            $('#slidewrapper').css({
                'transform': 'translate(' + translateWidth + 'px, 0)',
                '-webkit-transform': 'translate(' + translateWidth + 'px, 0)',
                '-ms-transform': 'translate(' + translateWidth + 'px, 0)',
            });
            slideNow--;
        }
    }

    getMenu("actions/getMenu.php?program=1&d=yesterday", "#yes1200slim");
    getMenu("actions/getMenu.php?program=1&d=today", "#today1200slim");
    getMenu("actions/getMenu.php?program=1&d=tomorrow", "#tom1200slim");
    getMenu("actions/getMenu.php?program=2&d=yesterday", "#yes2800slim");
    getMenu("actions/getMenu.php?program=2&d=today", "#today2800slim");
    getMenu("actions/getMenu.php?program=2&d=tomorrow", "#tom2800slim");

    getMenu("actions/getMenu.php?program=3&d=yesterday", "#yes1200day");
    getMenu("actions/getMenu.php?program=3&d=today", "#today1200day");
    getMenu("actions/getMenu.php?program=3&d=tomorrow", "#tom1200day");
    getMenu("actions/getMenu.php?program=4&d=yesterday", "#yes2800day");
    getMenu("actions/getMenu.php?program=4&d=today", "#today2800day");
    getMenu("actions/getMenu.php?program=4&d=tomorrow", "#tom2800day");

</script>

<script src="/js/plugins/jquery.fitvids.js"></script>
<script src="/js/jquery.bxslider.js"></script>

</html>                                                                                                                                            