<?php
header('Content-type: text/html; charset=utf8');
session_start();
include("../bd.php");

$id = $_SESSION["user_id"];
$food_id = $_GET['id'];

$result = $conn->query("set names utf8");
$sql = "SELECT * FROM Foods WHERE id = '$food_id'";
$result = $conn->query($sql);
$row = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="zxx">
<head>

    <!-- TITLE OF SITE -->
    <title>Редактировать еду</title>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0" />
    <!--[if IE]><meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1'><![endif]-->
    <meta name="author" content="bierx_87" />
    <meta name="description" content="" />
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <link rel="stylesheet/less" type="text/css" href="../css/main.less">
    <script type="text/javascript" src="../js/less.min.js"></script>
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <noscript>
        <strong>Warning!</strong>
        Your browser does not support HTML5 so some elements on this page are simulated using JScript. Unfortunately your browser has JScript disabled. Please enable it in order to display this page.
    </noscript>
    <style>
        .file-upload input[type="file"]{
            display: none;/* скрываем input file */
        }
        /* задаем стили кнопки выбора файла*/

        .file-upload {
            position: relative;
            overflow: hidden;
            width: 150px;
            height: 50px;
            background: transparent;
            color: #fff;
            text-align: center;
            border: 4px double #1c1c1c;
        }

        .file-upload:hover {
            background: #c8c8c8;
        }

        /* Растягиваем label на всю область блока .file-upload */

        .file-upload label {
            display: block;
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            cursor: pointer;
        }

        /* стиль текста на кнопке*/
        .file-upload span {
            line-height: 40px;
            font-size: 14px;
            color: #000;
        }

        .col-md-6.col-md-offset-2 {
            margin-bottom: 15px;
        }
    </style>
</head>
<body>
<?php
include("menuTemp.php");
?>
<!-- HEADER END -->
<div class="container block_menu text-center">
    <div id="myTabContent" class="col-md-12">

        <div class="col-md-6 col-md-offset-2">
            <label class="col-lg-4 control-label">Фото</label>
            <div class="col-lg-8">
                <form id="uploadForm" method="post" action="../actions/upload.php">
                    <div id="targetLayer" style="float: left">
                        <img id="avatar" src="<?php echo $row['photo'] ?>" width="100px" />
                    </div>
                    <div id="uploadFormLayer" style="float: right">
                        <div class="file-upload">
                            <label>
                                <input type="file" name="file" id="upload-file" onchange="getFileName();">
                                <span>Выберите фото</span>
                            </label>

                        </div>
                        <span class="showname" style="position: absolute;float: right; font-size: 14px;"></span>
                        <button style="width: 100%;font-size: 14px;float: right" type="submit" class="btn btn-success btnSubmit">Загрузить</button>
                    </div>
                </form>
            </div>
        </div>

        <div class="col-md-6 col-md-offset-2">
            <label class="col-lg-4 control-label">Название</label>
            <div class="col-lg-8">
                <input class="form-control name" type="text" placeholder="Название" required value="<?php echo $row['name'] ?>">
            </div>
        </div>
        <div class="col-md-6 col-md-offset-2">
            <label class="col-lg-4 control-label">Описание</label>
            <div class="col-lg-8">
                <textarea class="form-control description" placeholder="Описание" required><?php echo $row['description'] ?></textarea>
            </div>
        </div>
        <div class="col-md-6 col-md-offset-2">
            <label class="col-lg-4 control-label">Ккалория</label>
            <div class="col-lg-8">
                <input class="form-control kcal" type="number" placeholder="Ккалория" required value="<?php echo $row['kcal'] ?>">
            </div>
        </div>
        <div class="col-md-6 col-md-offset-2">
            <label class="col-lg-4 control-label">Белок</label>
            <div class="col-lg-8">
                <input class="form-control protein" type="number" placeholder="Белок" required value="<?php echo $row['protein'] ?>">
            </div>
        </div>
        <div class="col-md-6 col-md-offset-2">
            <label class="col-lg-4 control-label">Жир</label>
            <div class="col-lg-8">
                <input class="form-control fat" type="number" placeholder="Жир" required value="<?php echo $row['fat'] ?>">
            </div>
        </div>
        <div class="col-md-6 col-md-offset-2">
            <label class="col-lg-4 control-label">Углеводы</label>
            <div class="col-lg-8">
                <input class="form-control carbo" type="number" placeholder="Углеводы" required value="<?php echo $row['carbohydrate'] ?>">
            </div>
        </div>
        <?php if($row['isDessert'] == 1) { ?>
            <div class="col-md-6 col-md-offset-2">
                <label class="col-lg-4 control-label">Ед. изм</label>
                <div class="col-lg-8">
                    <input class="form-control unit" type="number" placeholder="Ед. изм" required value="<?php echo $row['unit'] ?>">
                </div>
            </div>
            <div class="col-md-6 col-md-offset-2">
                <label class="col-lg-4 control-label">Цена</label>
                <div class="col-lg-8">
                    <input class="form-control price" type="number" placeholder="Цена" required value="<?php echo $row['price'] ?>">
                </div>
            </div>
        <?php } ?>
        <input type="hidden" class="hid_type" value="<?php echo $row['isDessert'] ?>">
        <?php if($id == 5 || $id == 16){ ?>
        <div class="col-md-6 col-md-offset-2">
            <div class="checkbox">
                <label class="col-lg-4 control-label"><input type="checkbox" value="1" <?php if($row['isCheck'] == 1) echo 'checked' ?>>Замок</label>
            </div>
        </div><?php } ?>
        <div class="col-md-6 col-md-offset-3 add">
            <button class="btn btn-success" onclick="actions('editFood', <?php echo $food_id ?>)">Сохранить</button>
            <button class="btn btn-default">Отмена</button>
        </div>
    </div>
</div>

<!-- SCRIPTS -->
<script src="../js/jquery-1.11.3.min.js" type="text/javascript"></script>
<script src="../js/bootstrap.min.js" type="text/javascript"></script>
<script src="../js/jquery.validate.min.js" type="text/javascript"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script>
    var get_type = $(".hid_type").val();

    function actions(action, id) {
        var photo = $('#avatar').attr("src");
        var description = $(".form-control.description").val();
        var name = $('.form-control.name').val();
        var kcal = $('.form-control.kcal').val();
        var protein = $(".form-control.protein").val();
        var fat = $(".form-control.fat").val();
        var carbo = $(".form-control.carbo").val();
        var check = $('input:checkbox:checked').val();
        var unit = $(".form-control.unit").val();
        var price = $(".form-control.price").val();
        $.ajax({
            url: "actions.php",
            data: {action:action, food_id:id, photo:photo, name:name, description:description,kcal:kcal, protein:protein, fat:fat, carbo:carbo, unit:unit, price:price,check:check},
            type: "POST",
            success: function (data) {
                switch (action) {
                    case "editFood":
                        $(".col-md-6.col-md-offset-2.add").append("<div id='suggnot' class='alert-box success'>Рецепт отредактирован</div>");
                        $( "div#suggnot" ).fadeIn( 300 ).delay( 1500 ).fadeOut( 400 );
                        if(get_type == 1) {
                            window.location = "foods.php?type=1";
                        } else {
                            window.location = "foods.php?type=0";
                        }
                        break;
                }
            }
        });
        $( "div#suggnot").remove();
    }

    function getFileName() {
        $(".btn.btn-success.btnSubmit").css("margin-top", "25px");
        var filename = $('input[type=file]').val().replace(/C:\\fakepath\\/i, '');
        $('.showname').html(filename);
    }

    $(document).ready(function (e) {
        $("#uploadForm").on('submit',(function(e) {
            e.preventDefault();
            $.ajax({
                url: "../actions/upload.php",
                type: "POST",
                data:  new FormData(this),
                contentType: false,
                cache: false,
                processData:false,
                success: function(data)
                {
                    $("#targetLayer").html(data);
                },
                error: function()
                {
                }
            });
        }));
    });

    $(".btn-default").click(function(){
        if(get_type == 1) {
            window.location = "foods.php?type=1";
        } else {
            window.location = "foods.php?type=0";
        }
    });
</script>

</body>
</html>
