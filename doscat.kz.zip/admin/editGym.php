<?php
header('Content-type: text/html; charset=utf8');
session_start();
$id = $_SESSION["user_id"];
$gym_id = $_GET['id'];
include("../bd.php");
$result = $conn->query("set names utf8");
$sql = "SELECT * FROM Gyms WHERE id = '$gym_id'";
$result = $conn->query($sql);
$row = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="zxx">
<head>

    <!-- TITLE OF SITE -->
    <title>Редактировать спортзал</title>


    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0" />
    <!--[if IE]><meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1'><![endif]-->
    <meta name="author" content="bierx_87" />
    <meta name="description" content="" />

    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <link rel="stylesheet/less" type="text/css" href="../css/main.less">
    <script type="text/javascript" src="../js/less.min.js"></script>
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <link rel="stylesheet" media="all" type="text/css" href="../css/jquery-ui-timepicker-addon.css" />


    <noscript>
        <strong>Warning!</strong>
        Your browser does not support HTML5 so some elements on this page are simulated using JScript. Unfortunately your browser has JScript disabled. Please enable it in order to display this page.
    </noscript>
</head>

<body>

<!-- HEADER -->
<?php
include("menuTemp.php");
?>
<!-- HEADER END -->
<div class="container block_menu text-center">
    <div id="myTabContent" class="col-md-12">
        <div class="form">
            <form class="form-horizontal" id="form">
                <fieldset>
                    <p style="font-size: 17px"><b>Спортзал</b></p>
                    <hr>
                    <div class="form-group">
                        <label for="inputName" class="col-lg-4 control-label">Название:</label>
                        <div class="col-lg-4 text-left">
                            <input class="form-control" id="gym_name" type="text" placeholder="Название спортзала" value="<?php echo $row['name'] ?>">
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="inputAddress" class="col-lg-4 control-label">Адрес:</label>
                        <div class="col-lg-4">
                            <input class="form-control" id="gym_address" placeholder="Адрес спортзала" type="text" value="<?php echo $row['address'] ?>">
                        </div>
                    </div>

                    <div class="form-group text-center add">
                        <div class="col-lg-12">
                            <button type="submit" class="btn btn-success submit" onclick="actions('editGym', <?php echo $gym_id ?>)">Сохранить</button>
                        </div>
                    </div>

                </fieldset>
            </form>
        </div>
    </div>
</div>

<!-- CONTACT END -->

<!-- SCRIPTS -->
<script src="../js/jquery-1.11.3.min.js" type="text/javascript"></script>
<script src="../js/bootstrap.min.js" type="text/javascript"></script>
<script src="../js/jquery.validate.min.js" type="text/javascript"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script type="text/javascript" src="../js/jquery-ui-timepicker-addon.js"></script>
<script type="text/javascript" src="../js/jquery-ui-timepicker-addon-i18n.min.js"></script>
<script type="text/javascript" src="../js/jquery.maskedinput.js"></script>

<script>

    function actions(action, id){
        var gym_name = $("#gym_name").val();
        var gym_address = $("#gym_address").val();

        $.ajax({
            url: "actions.php",
            data: {action: action, gym_id:id, gym_name:gym_name,gym_address: gym_address},
            type: "POST",
            success: function (data) {
                switch (action) {
                    case "editGym":
                        $(".add").append("<div id='suggnot' class='alert-box success'>Спортзал успешно отредактирован</div>");
                        $( "div#suggnot" ).fadeIn( 300 ).delay( 1500 ).fadeOut( 400 );
                        window.location = "gyms.php";
                        break;
                }
            }
        })
    }
</script>
</body>
</html>
