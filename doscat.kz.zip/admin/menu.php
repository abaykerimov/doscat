<?php
header('Content-type: text/html; charset=utf8');
session_start();
include("../bd.php");
include("../actions/filter.php");
$id = $_SESSION["user_id"];
$type = filter("type");
?>

<!DOCTYPE html>
<html lang="zxx">
<head>

    <!-- TITLE OF SITE -->
    <title>Меню</title>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0"/>
    <!--[if IE]>
    <meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1'><![endif]-->
    <meta name="author" content="bierx_87"/>
    <meta name="description" content=""/>
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <link rel="stylesheet/less" type="text/css" href="../css/main.less">
    <script type="text/javascript" src="../js/less.min.js"></script>
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <link rel="stylesheet" type="text/css" href="../css/font-awesome.min.css">

    <noscript>
        <strong>Warning!</strong>
        Your browser does not support HTML5 so some elements on this page are simulated using JScript. Unfortunately
        your browser has JScript disabled. Please enable it in order to display this page.
    </noscript>
    <style>
        .get {
            margin-top: 10px;
        }

        .form-control {
            display: inline-block;
            max-width: 250px;
            margin-top: 20px;;
        }

        .modal-dialog {
            width: 60%;
        }
    </style>
</head>
<body>
<!-- HEADER -->
<?php
include("menuTemp.php");
?>
<!-- HEADER END -->
<div class="container block_menu text-center">
    <div id="myTabContent" class="tab-content">
        <?php if($type == 3) { ?>
            <a href="addMenu.php?type=3"><button class="btn btn-success">Добавить меню</button></a>
        <?php } else { ?>
            <a href="addMenu.php?type=5"><button class="btn btn-success">Добавить меню</button></a>
        <?php } ?>

        <div class="panel-title" style="font-size: 20px;text-align: center;margin-top: 15px;">
            <?php if($type == 3) { ?>
                <span>3-х разовое питание</span>
            <?php } else { ?>
                <span>5-ти разовое питание</span>
            <?php } ?>
        </div>

        <input class="form-control" id="datepicker" placeholder="Выберите дату">
        <select class="form-control" id="programFilter" onchange="actions('getMenuProgram',this.value, <?php echo $type ?>)">
            <option value="">--Программа--</option>
            <?php
            $queryProgram = "SELECT * FROM Program";
            $resultProgram = $conn->query($queryProgram);
            while ($rowProgram = $resultProgram->fetch_assoc()) {
                ?>
                <option value="<?php echo $rowProgram["id"]; ?>"><?php echo $rowProgram["name"]; ?></option>
                <?php
            }
            $resultProgram->close();
            ?>
        </select>
        <table class="table table-hover " style="width: 100%;background: white">
            <?php
            $resultMenu = $conn->query("set names utf8");
            $sqlMenu = "SELECT id, (SELECT name FROM Program WHERE id = program_id) as program, menu_number,date_start,kcal,protein,fat,carbo FROM Menu ORDER BY date_start DESC";
            $resultMenu = $conn->query($sqlMenu);
            $count = 0;
            while ($rowMenu = $resultMenu->fetch_assoc()) {
            $menu_id = $rowMenu['id'];

            $result = $conn->query("set names utf8");
            $sql = "SELECT DISTINCT food_type_id, (SELECT type_name FROM Food_Type WHERE id=food_type_id) as name FROM Menu_Foods m JOIN Food_Type ft ON ft.id=m.food_type_id WHERE menu_id = '$menu_id' ORDER BY ft.sort";
            $result = $conn->query($sql);
            if ($result->num_rows > 0 && $result->num_rows == $type){

            if ($count == 0) {
            ?>

            <thead>
            <tr>
                <th class='th_name' style="width: 5%">№</th>
                <th width="10%">Дата недели</th>
                <?php
                while ($row = $result->fetch_assoc()) {
                    ?>
                    <!--SELECT DISTINCT `food_type_id` FROM `Menu_Foods`
                    WHERE `menu_id` in (SELECT id FROM Menu WHERE date_start = "2017-01-09") ORDER by `food_type_id`
                    запомни в переменную число количество -->
                    <th><?php echo $row['name'] ?></th>
                <?php } ?>
                <th>Ккал</th>
                <th>Белок</th>
                <th>Жир</th>
                <th>Угл</th>
            </tr>
            </thead>
            <tbody>
            <?php
            $count++;
            }
            $date = DateTime::createFromFormat('Y-m-d', $rowMenu['date_start']);
            $date_start = $date->format("d-m-y"); ?>
            <tr data-toggle="modal" data-target="#myModal" style="cursor: pointer"
                onclick="actions('getMenu',<?php echo $rowMenu['id'] ?>)">
                <td><?php echo $rowMenu['id'] ?></td>
                <td width="20%"><?php echo $date_start ?><br>
                    <?php $day = date('l', strtotime($rowMenu['date_start']));
                    if ($day == "Monday") {
                        $day = "Понедельник";
                    } else if ($day == "Tuesday") {
                        $day = "Вторник";
                    } else if ($day == "Wednesday") {
                        $day = "Среда";
                    } else if ($day == "Thursday") {
                        $day = "Четверг";
                    } else if ($day == "Friday") {
                        $day = "Пятница";
                    } else if ($day == "Saturday") {
                        $day = "Суббота";
                    } else if ($day == "Sunday") {
                        $day = "Воскресенье";
                    }
                    echo $day;?><br>
                    <?php echo $rowMenu['program'] ?></td>
                <?php
                $resultType = $conn->query("set names utf8");
                $sqlType = "SELECT DISTINCT food_type_id
                    FROM Menu_Foods m JOIN Food_Type ft ON ft.id=m.food_type_id WHERE menu_id = '$menu_id' ORDER by ft.sort";

                $resultType = $conn->query($sqlType);
                if ($resultType->num_rows > 0){
                while ($rowType = $resultType->fetch_assoc()) {
                    //здесь сравнить переменную с размером массива
                    echo '<td>';
                    $type_id = $rowType['food_type_id'];
                    $resultFood = $conn->query("set names utf8");
                    $sqlFood = "SELECT f.id, f.name, m.portion,TRUNCATE((f.kcal*m.portion/100),2) as calcKcal, TRUNCATE((f.protein*m.portion/100),2) as calcPro,
                        TRUNCATE((f.fat*m.portion/100),2) as calcFat, TRUNCATE((f.carbohydrate*m.portion/100),2) as calcCarbo
                        FROM Menu_Foods m JOIN Foods f ON f.id = m.food_id
                        WHERE m.menu_id = '$menu_id' and m.food_type_id = '$type_id'";
                    $resultFood = $conn->query($sqlFood);

                    while ($rowFood = $resultFood->fetch_assoc()) {
                        ?>
                        <div class="col-md-12"
                             style="margin-bottom: 10px;padding-left: 0;"><?php echo $rowFood['name'] ?></div>
                    <?php }
                    echo "</td>";
                } ?>
                <td class="kcal"><?php echo $rowMenu['kcal'] ?></td>
                <td class="protein"><?php echo $rowMenu['protein'] ?></td>
                <td class="fat"><?php echo $rowMenu['fat'] ?></td>
                <td class="carbo"><?php echo $rowMenu['carbo'] ?></td>
            </tr>
            <?php }
            }
            } ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Карточка меню</h4>
            </div>
            <div class="modal-body">

            </div>
        </div>

    </div>
</div>

<!-- SCRIPTS -->
<script src="../js/jquery-1.11.3.min.js" type="text/javascript"></script>
<script src="../js/bootstrap.min.js" type="text/javascript"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script>

    $(function () {
        $('#datepicker').datepicker({
            autoclose: true,
            dateFormat: 'yy-mm-dd',
            language: 'ru',
            todayHighlight: true,
            onSelect: function () {
                var date = $("#datepicker").val();
                getMenu(date, <?php echo $type ?>);
            }
        });
        $.datepicker.regional['ru'] = {
            clearText: 'Effacer', clearStatus: '',
            monthNames: ['Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь',
                'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь'],
            monthNamesShort: ['Янв', 'Фев', 'Мар', 'Апр', 'Май', 'Июн',
                'Июл', 'Авг', 'Сен', 'Окт', 'Ноя', 'Дек'],
            dayNames: ['Воскресенье', 'Понедельник', 'Вторник', 'Среда', 'Четверг', 'Пятница', 'Суббота'],
            dayNamesShort: ['Вс', 'Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб'],
            dayNamesMin: ['Вс', 'Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб'],
            firstDay: 1
        };
        $.datepicker.setDefaults($.datepicker.regional['ru']);
    });

    function getMenu(val, get_type) {
        $.ajax({
            type: "POST",
            url: "../actions/getMenuForWeek.php",
            data: {select_date:val, get_type:get_type},
            success: function (data) {
                $("table.table").html(data);
            }
        });
    }

    function actions(action, id, get_type) {
        $.ajax({
            url: "actions.php",
            data: {action: action, menu_id: id, get_type:get_type},
            type: "POST",
            success: function (data) {
                switch (action) {
                    case "deleteMenu":
                        location.reload();
                        break;
                    case "getMenuProgram":
                        $("table.table").html(data);
                        break;
                    case "getMenu":
                        $(".modal-body").html(data);
                        break;
                }
                function sumFood(selector, text) {
                    var sum = 0;

                    $(selector).each(function () {
                        sum += Number($(this).text());
                    });
                    return $(text).text(sum.toFixed(2));
                }

                sumFood('.type_1 .kcal', '.sumFKcal_1');
                sumFood('.type_1 .protein', '.sumFPro_1');
                sumFood('.type_1 .fat', '.sumFFat_1');
                sumFood('.type_1 .carbo', '.sumFCarbo_1');
                sumFood('.type_2 .kcal', '.sumFKcal_2');
                sumFood('.type_2 .protein', '.sumFPro_2');
                sumFood('.type_2 .fat', '.sumFFat_2');
                sumFood('.type_2 .carbo', '.sumFCarbo_2');
                sumFood('.type_3 .kcal', '.sumFKcal_3');
                sumFood('.type_3 .protein', '.sumFPro_3');
                sumFood('.type_3 .fat', '.sumFFat_3');
                sumFood('.type_3 .carbo', '.sumFCarbo_3');
                sumFood('.type_4 .kcal', '.sumFKcal_4');
                sumFood('.type_4 .protein', '.sumFPro_4');
                sumFood('.type_4 .fat', '.sumFFat_4');
                sumFood('.type_4 .carbo', '.sumFCarbo_4');
                sumFood('.type_5 .kcal', '.sumFKcal_5');
                sumFood('.type_5 .protein', '.sumFPro_5');
                sumFood('.type_5 .fat', '.sumFFat_5');
                sumFood('.type_5 .carbo', '.sumFCarbo_5');

                sumFood('.typeKcal', '.sumKcal');
                sumFood('.typePro', '.sumPro');
                sumFood('.typeFat', '.sumFat');
                sumFood('.typeCarbo', '.sumCarbo');
            }

        });
    }

</script>
</body>
</html>
