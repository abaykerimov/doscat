<?php
header('Content-type: text/html; charset=utf8');
session_start();
$gym_id = $_SESSION['gym_id'];
$status = $_SESSION['status'];
$id = $_SESSION["user_id"];
include("../bd.php");
?>

<!DOCTYPE html>
<html lang="zxx">
<head>

    <!-- TITLE OF SITE -->
    <title>Создать заявку</title>


    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0"/>
    <!--[if IE]>
    <meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1'><![endif]-->
    <meta name="author" content="bierx_87"/>
    <meta name="description" content=""/>

    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <link rel="stylesheet/less" type="text/css" href="../css/main.less">
    <script type="text/javascript" src="../js/less.min.js"></script>
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <link rel="stylesheet" media="all" type="text/css" href="../css/jquery-ui-timepicker-addon.css"/>


    <noscript>
        <strong>Warning!</strong>
        Your browser does not support HTML5 so some elements on this page are simulated using JScript. Unfortunately
        your browser has JScript disabled. Please enable it in order to display this page.
    </noscript>
    <style>
        .block_menu .form {
            max-width: 600px;
            margin: 40px auto;
            background: rgba(255, 255, 255, 0.5);
            padding: 5px 30px;
        }

        #custom-handle {
            width: 1.5em;
            height: 1.6em;
            top: 50%;
            margin-top: -.8em;
            text-align: center;
            line-height: 1.6em;
            background-color: yellow;
            font: 12pt Tahoma;
        }

        .block_menu .nav-tabs li {
            max-width: 50%;
            margin-left: 0;
        }

        span.glyphicon {
            color: #869791;
        }

        .carousel-inner > .active {
            display: block;
        }

        #slider::after {
            position: absolute;
            margin-left: 25%;
            content: "7";
            top: -25px;
            color: black;
            width: 24px;
            left: 0;
            font: 12pt Tahoma;
        }

        #slider::before {
            position: absolute;
            margin-left: 55%;
            content: "14";
            top: -25px;
            color: black;
            width: 24px;
            left: 0;
            font: 12pt Tahoma;
        }

        #sliderCover::after {
            position: absolute;
            margin-left: -1%;
            content: "1";
            top: -25px;
            color: black;
            width: 24px;
            left: 0;
            font: 12pt Tahoma;
        }

        #sliderCover::before {
            position: absolute;
            margin-left: 85%;
            content: "21";
            top: -25px;
            color: black;
            width: 24px;
            left: 0;
            font: 12pt Tahoma;
        }

        #user_list {
            float: left;
            list-style: none;
            margin: 0;
            padding: 0;
            width: 100%;
        }

        #user_list li {
            padding: 10px;
            background: #FAFAFA;
            border-bottom: #F0F0F0 1px solid;
            cursor: pointer
        }

        #user_list li:hover {
            background: #F0F0F0;
        }
    </style>
</head>

<body>

<!-- HEADER -->
<?php
include("menuTemp.php");
?>
<!-- HEADER END -->
<div class="container block_menu text-center">
    <div id="myTabContent" class="col-md-12">
        <h4>Заявка-калькулятор</h4>

        <div class="form" style="max-width: 1000px">
            <form class="form-horizontal" role="form" data-toggle="validator" id="Zakaz">
                <fieldset>
                    <div class="col-lg-6">
                        <div class="form-group" style=" vertical-align: bottom; margin-top: 60px;">
                            <label for="inputName" class="col-lg-4 control-label">ФИО*</label>

                            <div class="col-lg-8 text-left">
                                <input class="form-control name" id="inputName" type="text" name="name"
                                       placeholder="Анель Ахметова" required>

                                <div id="list_name"></div>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="inputPhone" class="col-lg-4 control-label">Телефон*</label>

                            <div class="col-lg-8">
                                <input class="form-control phone" id="inputPhone" placeholder="+7 (___) ___-__-__"
                                       type="tel" name="phone" required>

                            </div>
                        </div>

                        <div class="form-group">
                            <label for="select" class="col-lg-4 control-label">План питания*</label>

                            <div class="col-lg-8">
                                <select class="form-control" name="program" id="select"
                                        onchange="getDescription('getDescriptions', this.value);ForSinglePrice('getSinglePrice', this.value);"
                                        required>
                                    <option value="" disabled selected>--Выберите план питания--</option>
                                    <?php
                                    $query = "SELECT  name, id FROM Program";
                                    $results = $conn->query($query);
                                    while ($row = $results->fetch_assoc()) { ?>
                                        <option value="<?php echo $row["id"]; ?>"><?php echo $row["name"]; ?> </option>
                                    <?php } ?>
                                </select>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="inputPhone" class="col-lg-4 control-label">Дата начала питания*</label>

                            <div class="col-lg-8">
                                <input class="form-control date_start" id="date_start" placeholder="Дата начала питания"
                                       type="text" required>
                            </div>
                        </div>


                        <div class="form-group">
                            <label for="inputName" class="col-lg-4 control-label">Условия доставки</label>

                            <div class="col-lg-8 text-left">
                                <form action="handler.php">
                                    <p><input name="dzen" type="radio" value="1"
                                              onclick="getValueToZero(); ForSinglePriceCheckbox('getSinglePriceForCheckbox',this.value); ">
                                        До дома/офиса</p>

                                    <p><input name="dzen" type="radio" value="2"
                                              onclick="getValueToZero();ForSinglePriceCheckbox('getSinglePriceForCheckbox',this.value);">
                                        До партнерского спортзала</p>
                                    <?php if ($gym_id == 1 || $status == 1 || $gym_id == 2) { ?>
                                        <p><input name="dzen" type="radio" value="3" checked
                                                  onclick="getValueToZero();ForSinglePriceCheckbox('getSinglePriceForCheckbox',this.value);">Особые
                                            условия</p>
                                    <?php } ?>
                                </form>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="form-group">
                                <label for="inputName" class="col-lg-4 control-label">Количество дней</label>

                                <div id="slider" class="col-lg-8"
                                     style="margin-top:15px; margin-left: 20px; width: 300px;">
                                    <div id="sliderCover">
                                        <div id="custom-handle" class="ui-slider-handle"></div>
                                    </div>
                                </div>
                            </div>
                            <div id="changePrice">
                                <div class="form-group">

                                    <label for="inputName" class="col-lg-4 control-label">Стоимость в день</label>

                                    <div class="col-lg-8 text-left">
                                        <input class="form-control costPerDay" id="costPerDay" type="text"
                                               name="costPerDay" placeholder="" disabled>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="inputName" class="col-lg-4 control-label">Стоимость всего </label>

                                <div class="col-lg-8 text-left">
                                    <input class="form-control costForAll" id="costForAll" type="text" name="costForAll"
                                           placeholder="" disabled style="color:SandyBrown;">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="inputName" class="col-lg-4 control-label">Экономия</label>

                                <div class="col-lg-8 text-left">
                                    <input class="form-control save" id="save" type="text" name="save" placeholder=""
                                           disabled style="color:green;">
                                </div>
                            </div>
                            <div class="form-group">

                            </div>

                            <div class="form-group">
                                <label for="inputPhone" class="col-lg-4 control-label"></label>

                                <div class="col-lg-8 text-left">
                                    <h6>* Бесплатная доставка по г.Алматы в квадрате:
                                        пр.Достык-пр.Саина-пр.Аль-Фараби-пр.Райымбека</h6>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div id="photodesc"></div>
                </fieldset>
            </form>
        </div>
    </div>
</div>

<!-- CONTACT END -->

<!-- SCRIPTS -->
<script src="../js/jquery-1.11.3.min.js" type="text/javascript"></script>
<script src="../js/bootstrap.min.js" type="text/javascript"></script>
<script src="../js/jquery.validate.min.js" type="text/javascript"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script type="text/javascript" src="../js/jquery.maskedinput.js"></script>
<script type="text/javascript" src="../js/sweetalert.min.js"></script>
<script type="text/javascript" src="../js/owl.carousel.min.js"></script>

<script type="text/javascript" src="../js/jquery.inputmask.bundle.js"></script>
<script>
    $(function () {
        $('#date_start').datepicker({
            autoclose: true,
            dateFormat: 'yy-mm-dd',
            language: 'ru',
            todayHighlight: true
        });
        $.datepicker.regional['ru'] = {clearStatus: '',
            monthNames: ['Январь','Февраль','Март','Апрель','Май','Июнь',
                'Июль','Август','Сентябрь','Октябрь','Ноябрь','Декабрь'],
            monthNamesShort: ['Янв','Фев','Мар','Апр','Май','Июн',
                'Июл','Авг','Сен','Окт','Ноя','Дек'],
            dayNames: ['Воскресенье','Понедельник','Вторник','Среда','Четверг','Пятница','Суббота'],
            dayNamesShort: ['Вс','Пн','Вт','Ср','Чт','Пт','Сб'],
            dayNamesMin: ['Вс','Пн','Вт','Ср','Чт','Пт','Сб'],
            firstDay: 1 };
        $.datepicker.setDefaults($.datepicker.regional['ru']);
    });

    $("#inputPhone").mask("+7 (999) 999-99-99");

    $("#inputName").keyup(function () {
        $("#list_name").show();
        $.ajax({
            url: "actions.php",
            data: {action: "getOrderUserName", val: $(this).val()},
            type: "POST",
            success: function (data) {
                switch ("getOrderUserName") {
                    case "getOrderUserName":
                        $("#list_name").html(data);
                        break;
                }
            }
        })
    });

    function getName(f, p) {
        $("#inputName").val(f);
        $("#inputPhone").val(p);
        $("#list_name").hide();
    }

    function getValueToZero() {
        $("#custom-handle").css('left', '0%');
        $("#custom-handle").text(1);
        $("#costPerDay").val(0);
        $("#costForAll").val(0);
        $("#save").val(0);
    }

    function getDescription(action, value) {
        $.ajax({
            url: "actionsGani.php",
            data: {action: action, program_id: value},
            type: "POST",
            success: function (data) {
                switch (action) {
                    case "getDescriptions":
                        $("#photodesc").html(data);
                        break;
                }
            }
        })
    }

    function ForSinglePrice(action, value) {
        var singlePrice;
        var typeSinglePrice = $('input[name="dzen"]:checked').val();
        $.ajax({
            url: "actionsGani.php",
            data: {action: action, program_id: value, type: typeSinglePrice},
            type: "POST",
            success: function (data) {
                switch (action) {
                    case "getSinglePrice":
                        var arr = data.split("_");
                        singlePrice = arr[0];
                        $('#id_product').val(arr[1]);
                        $("#custom-handle").css('left', '0%');
                        $("#custom-handle").text(1);
                        $("#costPerDay").val(singlePrice);
                        $("#costForAll").val(singlePrice);
                        $("#save").val(0);
                        break;
                }
            }
        })
    }

    function ForSinglePriceCheckbox(action, value) {
        var singlePrice;
        var a = $('#select option:selected').val();
        $.ajax({
            url: "actionsGani.php",
            data: {action: action, program_id: a, type: value},
            type: "POST",
            success: function (data) {
                switch (action) {
                    case "getSinglePriceForCheckbox":
                        var arr = data.split("_");
                        singlePrice = arr[0];
                        $('#id_product').val(arr[1]);
                        $("#custom-handle").css('left', '0%');
                        $("#custom-handle").text(1);
                        $("#costPerDay").val(singlePrice);
                        $("#costForAll").val(singlePrice);
                        $("#save").val(0);
                        break;
                }
            }
        })
    }

    function getPrice(Price, highPrice, value) {
        if (value < 7) {
            $("#costForAll").val(value * Price);
            $("#save").val(0);
        }
        if (value >= 7 && value < 14) {
            $("#costForAll").val(value * Price);
            $("#save").val(value * (highPrice - Price));
        }
        if (value >= 14 && value < 21) {
            $("#costForAll").val(value * Price);
            $("#save").val(value * (highPrice - Price));
        }

        if (value >= 21) {
            $("#costForAll").val(value * Price);
            $("#save").val(value * (highPrice - Price));
        }
    }

    $(document).ready(function () {

        $('#Zakaz').submit(function () {
            $('.sendzakaz').addClass('disabled');

            var name = $(".form-control.name").val();
            var arr = name.split(' ');
            //console.log(arr[0], arr[1]);
            var phone = $(".form-control.phone").val();
            var program = $("#select").val();
            var days = $("#custom-handle").text();
            var sum = $("#costForAll").val();
            var type = $('input[name="dzen"]:checked').val();
            var date = $("#date_start").val();
            //console.log(name,phone,program ,days,sum,surname);
            $.ajax({
                type: 'POST',
                url: '../actions/addRequest.php',
                data: {
                    user_name: arr[0],
                    phone: phone,
                    program: program,
                    days: days,
                    sum: sum,
                    surname: arr[1],
                    dzen: type,
                    date: date
                },


                success: function (responce) {
                    var answer = jQuery.parseJSON($.trim(responce));
                    if (answer[0].status == "SUCCESS") {
                        swal("Отлично!", answer[0].message, "success");
                        setTimeout(function () {
                            window.location = "index.php";
                        }, 1500);
                    } else {
                        swal("Внимание!", answer[0].message, "warning")
                    }
                },
                error: function (responce) {
                    swal("Ошибка!", "Попробуйте обновить страницу и повторить попытку", "error");
                }
            });
            //запрет отправки, то есть перезагрузки страницы
            return false;
        });

    });

</script>

<script>
    $(function () {
        var handle = $("#custom-handle");
        $("#slider").slider({
            max: 24,
            min: 1,
            create: function () {
                handle.text($(this).slider("value"));
            },
            slide: function (event, ui) {
                handle.text(ui.value);
            },
            change: function (event, ui) {
                var typeOfProgram, price, highPrice;
                handle.text($(this).slider("value"));
                var type = $('input[name="dzen"]:checked').val();
                var a = $('#select option:selected').val();
                $.ajax({
                    url: "actionsGani.php",
                    data: {action: 'getPrice', value: ui.value, program_id: a, type: type},
                    type: "POST",
                    success: function (data) {
                        var arr = data.split('_');
                        price = arr[0];
                        highPrice = arr[1];
                        var id_product = arr[2];
                        $('#id_product').val(id_product);
                        $("#costPerDay").val(price);
                        getPrice(price, highPrice, ui.value);
                    }

                })
            }
        });
    });
</script>
</body>
</html>


