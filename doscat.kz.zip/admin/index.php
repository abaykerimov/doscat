<?php
//ini_set('error_reporting', E_ALL);
//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);
header('Content-type: text/html; charset=utf8');
session_start();
include("../bd.php");
$status = $_SESSION['status'];
$gym_id = $_SESSION['gym_id'];
include('../actions/functions.php');

$active_plan = active($id);
?>

<!DOCTYPE html>
<html lang="zxx">
<head>

    <!-- TITLE OF SITE -->
    <title>Все заявки</title>


    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0" />
    <!--[if IE]><meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1'><![endif]-->
    <meta name="author" content="bierx_87" />
    <meta name="description" content="" />

    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <link rel="stylesheet/less" type="text/css" href="../css/main.less">
    <script type="text/javascript" src="../js/less.min.js"></script>
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">

    <noscript>
        <strong>Warning!</strong>
        Your browser does not support HTML5 so some elements on this page are simulated using JScript. Unfortunately your browser has JScript disabled. Please enable it in order to display this page.
    </noscript>
    <style>
    .get{
        margin-top: 10px;
    }
    .form-control{
        display: inline-block;
        max-width: 250px;
        margin-top: 20px;;
    }
    .row-all-project {
        margin: 0;
        padding: 0;
        vertical-align: top;
        background-color: white!important;
        border: none!important;
    }
    .row-all-project h4 {
        border-bottom: 2px solid #dddddd;
        padding: 10px 15px;
        margin: 0;
        color: black;
    }
    .row-all-project a {
        border-bottom: 1px solid #dddddd;
        padding: 7px 10px;
        margin: 0;
        display: block;
        text-shadow: none;
    }
    .block_menu .nav-tabs li {
        display: block;
        max-width: 50%;
        margin-left: 0;
    }

    select.status {
        margin-top: -20px;
        height: 40px;
        font-size: 13px;
        padding: 0px 15px;
    }
</style>
</head>

<body>

<?php
include("menuTemp.php");
?>

<!-- HEADER END -->
<div class="container block_menu text-center">
    <div id="myTabContent" class="tab-content">
         <a href="addOrder.php"><button class="btn btn-success">Создать заявку</button></a>

        <div class="panel-title" style="font-size: 20px;text-align: center;margin-top: 15px;"><span>Заявки на питание</span></div>
        <input class="form-control" id="dateFilter" placeholder="Дата" type="text">
        <select class="form-control" id="statusFilter" onchange="getRequest('getOrderStatus',this.value)">
            <option value="">--Все статусы--</option>
            <?php
            $querySiP = "SELECT * FROM Status_inPlans";
            $resSiP = $conn->query($querySiP);
            while ($rowsSiP = $resSiP->fetch_assoc()) { ?>
                <option value="<?php echo $rowsSiP["id"]; ?>"><?php echo $rowsSiP["name"]; ?></option>
            <?php } ?>
        </select>

        <table class="table table-hover " style="width: 100%">
            <thead>
            <tr>
                <th width="7%">№</th>
                <th>ФИО</th>
                <th>План питания</th>
                <th width="15%">Доставка</th>
                <th>Дней всего</th>
                <th width="15%">Дата старт</th>
                <th>Стоимость в день</th>
                <th>Стоимость всего</th>
                <th width="15%">Дата покупки</th>
                <th>Дней пройдено</th>
                <th>Дней осталось</th>
                <?php if($status == 1 || $status == 2) {?>
                    <th>Статус заявки</th>
                <?php } ?>
            </tr>
            </thead>
            <tbody>
            <?php
            if($status == 1) {
                $query_reestr = $conn->prepare("SELECT p.id, u.first_name, u.last_name, sip.name, (SELECT pp.name FROM Program pp WHERE pp.id = (SELECT program_id FROM Product WHERE id = p.product_id)) as product_name, p.date, p.price, p.days, (SELECT name FROM Delivery_inPlans WHERE id = p.delivery) as delivery, p.status FROM Plans p JOIN Users u ON u.id = p.user_id JOIN Status_inPlans sip ON sip.id = p.status ORDER by date DESC");
            } else {
                $query_reestr = $conn->prepare("SELECT p.id, u.first_name, u.last_name, sip.name, (SELECT pp.name FROM Program pp WHERE pp.id = (SELECT program_id FROM Product WHERE id = p.product_id)) as product_name, p.date, p.price, p.days, (SELECT name FROM Delivery_inPlans WHERE id = p.delivery) as delivery, p.status FROM Plans p JOIN Users u ON u.id = p.user_id JOIN Status_inPlans sip ON sip.id = p.status WHERE u.id_gym = '$gym_id' ORDER by date DESC");
            }
            $query_reestr->execute();
            $query_reestr->store_result();
            if ($query_reestr->num_rows > 0) {
                $query_reestr->bind_result($reestr_id,$f_name, $l_name, $status_name, $reestr_prod_name,$reestr_date,$reestr_price,$reestr_days,$reestr_dostavka,$reestr_status_id);
                while ($query_reestr->fetch()) {
                    $d_reestr = DateTime::createFromFormat('Y-m-d', $reestr_date);
                    $reestr_d = $d_reestr->format("d-m-Y");
                    if ($active_plan['id_plan'] == $reestr_id) {
                        $dney_proideno = $active_plan['days_off'];
                        $dney_ostalos = ($active_plan['days']-$active_plan['days_off']);
                        $data_start_eat = $active_plan['date_start_eat'];

                    } else {
                        $query_dayoff = $conn->prepare("SELECT count(id), min(date) FROM Calendars WHERE date <= DATE_ADD(CURDATE(),INTERVAL 1 DAY) and plan_id = ?");
                        $query_dayoff->bind_param('i', $reestr_id);
                        $query_dayoff->execute();
                        $query_dayoff->store_result();
                        if ($query_dayoff->num_rows > 0) {
                            $query_dayoff->bind_result($dney_proideno,$data_start_eat);
                            while ($query_dayoff->fetch()) {
                            }
                        }

                        $query_dayoff->close();
                        $dney_ostalos = $reestr_days-$dney_proideno;
                    }
                    if($reestr_status_id == 1) {
                        $css = 'style = "color: red"';
                    } elseif ($reestr_status_id == 2) {
                        $css = 'style = "color: green"';
                    } elseif ($reestr_status_id == 3) {
                        $css = 'style = "color: black"';
                    } elseif ($reestr_status_id == 4) {
                        $css = 'style = "color: blue"';
                    }
                    ?>
                        <tr>
                            <td><?php echo $reestr_id ?></td>
                            <td><?php echo $f_name." ".$l_name ?></td>
                            <td><?php echo $reestr_prod_name ?></td>
                            <td><?php echo $reestr_dostavka ?></td>
                            <td><?php echo $reestr_days ?></td>
                            <td width="15%"><?php echo $data_start_eat ?></td>
                            <td><?php echo $reestr_price ?></td>
                            <td><?php echo $reestr_price*$reestr_days ?></td>
                            <td><?php echo $reestr_d ?></td>
                            <td><?php echo $dney_proideno ?></td>
                            <td><?php echo $dney_ostalos ?></td>
                            <td <?php if($status == 2) {echo $css;} else {echo 'style="width: 30%"';} ?>>
                                <?php if($status == 1) { ?>
                                <select class="form-control status" id="status_<?php echo $reestr_id ?>" onchange="getRequest('editOrder', <?php echo $reestr_id ?>, this.value)" <?php echo $css ?>>
                                    <?php
                                    $qSiP = "SELECT * FROM Status_inPlans";
                                    $rSiP = $conn->query($qSiP);
                                    while ($rowSiP = $rSiP->fetch_assoc()) { ?>
                                        <option value="<?php echo $rowSiP["id"]; ?>"<?php if($rowSiP["id"] == $reestr_status_id) echo 'selected' ?>><?php echo $rowSiP["name"]; ?></option>
                                    <?php } ?>
                                </select>
                                <?php } else { echo $status_name; } ?>
                            </td>
                        </tr>
                <?php }
            }
            $query_reestr->close();
            ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Заявка на питание</h4>
            </div>
            <div class="modal-body">

            </div>
        </div>
    </div>
</div>

<!-- CONTACT END -->
<!-- SCRIPTS -->
<script src="../js/jquery-1.11.3.min.js" type="text/javascript"></script>
<script src="../js/bootstrap.min.js" type="text/javascript"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/js/bootstrap-datepicker.min.js"></script>
<script src="../js/jquery.validate.min.js" type="text/javascript"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script type="text/javascript" src="../js/sweetalert.min.js"></script>
<script>
    $(function () {
        $('#dateFilter').datepicker({
            autoclose: true,
            dateFormat: 'dd-mm-yy',
            language: 'ru',
            todayHighlight: true,
            onSelect: function() {
                var date = $("#dateFilter").val();
                getRequest('getOrderRequest',date);
            }
        });
        $.datepicker.regional['ru'] = {clearStatus: '',
            monthNames: ['Январь','Февраль','Март','Апрель','Май','Июнь',
                'Июль','Август','Сентябрь','Октябрь','Ноябрь','Декабрь'],
            monthNamesShort: ['Янв','Фев','Мар','Апр','Май','Июн',
                'Июл','Авг','Сен','Окт','Ноя','Дек'],
            dayNames: ['Воскресенье','Понедельник','Вторник','Среда','Четверг','Пятница','Суббота'],
            dayNamesShort: ['Вс','Пн','Вт','Ср','Чт','Пт','Сб'],
            dayNamesMin: ['Вс','Пн','Вт','Ср','Чт','Пт','Сб'],
            firstDay: 1 };
        $.datepicker.setDefaults($.datepicker.regional['ru']);
    });

    function getRequest(action,val,status) {
        var d_filter = $("#dateFilter").val();
        var s_filter = $("#statusFilter").val();
        $.ajax({
            type: "POST",
            url: "actions.php",
            data: {action:action,val:val,d_filter:d_filter,s_filter:s_filter,status:status},
            success: function(data){
                switch (action) {
                    case "getOrder":
                        $(".modal-body").html(data);
                        break;
                    case "deleteOrder":
                        setTimeout(function(){
                            location.reload();
                        },1000);
                        break;
                    case "getOrderRequest":
                        $("table.table tbody").html(data);
                        break;
                    case "getOrderStatus":
                        $("table.table tbody").html(data);
                        break;
                    case "editOrder":
                        if(status == 1) {
                            $("#status_"+data).css("color", "red");
                        } else if(status == 2) {
                            $("#status_"+data).css("color", "green");
                        } else if(status == 4) {
                            $("#status_"+data).css("color", "gray");
                        }
                        swal("Заявка успешно отредактирована", "","success");
                        break;
                }

            }
        });
    }
</script>
</body>
</html>
