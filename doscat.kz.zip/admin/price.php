<?php
ini_set('error_reporting', E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
header('Content-type: text/html; charset=utf8');
session_start();
include("../bd.php");
$id = $_SESSION["user_id"];
?>

<!DOCTYPE html>
<html lang="zxx">
<head>

    <!-- TITLE OF SITE -->
    <title>Прайс лист</title>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0" />
    <!--[if IE]><meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1'><![endif]-->
    <meta name="author" content="bierx_87" />
    <meta name="description" content="" />
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <link rel="stylesheet/less" type="text/css" href="../css/main.less">
    <script type="text/javascript" src="../js/less.min.js"></script>
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <link rel="stylesheet" type="text/css" href="../css/font-awesome.min.css">

    <noscript>
        <strong>Warning!</strong>
        Your browser does not support HTML5 so some elements on this page are simulated using JScript. Unfortunately your browser has JScript disabled. Please enable it in order to display this page.
    </noscript>
    <style>
        .form-control{
            display: inline-block;
            max-width: 250px;
            margin-top: 20px;;
        }
    </style>
</head>
<body>

<?php
include("menuTemp.php");
?>
<!-- HEADER END -->
<div class="container block_menu text-center">
    <div id="myTabContent" class="tab-content">
        <a href="addPrice.php"><button class="btn btn-success">Добавить прайс-лист</button></a><br>
        <select class="form-control" id="price_type" onchange="getRequest('getPriceType',this.value)">
            <option value="">--Тип доставки--</option>
            <option value="1">По адресу</option>
            <option value="2">В спортзал</option>
            <option value="3">Особые условия</option>
        </select>
        <select required="required" class="form-control" id="program" onchange="getRequest('getPriceTypeProduct', this.value);" >
            <option value="" disabled selected >--Выберите план питания--</option>
            <?php
            $query = "SELECT name, id FROM Program";
            $results = $conn->query($query);
            while ($row = $results->fetch_assoc()) { ?>
                <option value="<?php echo $row["id"]; ?>"><?php echo $row["name"]; ?> </option>
            <?php } ?>
        </select>

        <div class="tab-pane fade active in" id="yesterday">

            <table class="table table-striped table-hover " id="tablesorted" style="width: 100%">
                <thead>
                <tr>
                    <th style="width: 5%">№</th>
                    <th>План питания</th>
                    <th>Калорий в рационе</th>
                    <th>Стоимость</th>
                    <th>Кол-во дней</th>
                    <th>Количество дней заморозки</th>
                    <th>Фото</th>
                    <th>Описание</th>
                    <th>Агентская комиссия</th>
                    <th>Вид прайс-листа</th>
                    <th>Действие</th>
                </tr>
                </thead>
                <tbody>
                <?php
                $result = $conn->query("set names utf8");
                $sql = "SELECT id,(SELECT id FROM Program WHERE id=program_id) as 'program',(SELECT photo FROM Program WHERE id=program_id) as 'photo',(SELECT name FROM Program WHERE id=program_id) as 'name',(SELECT kcal FROM Program WHERE id=program_id) as 'kcal',price,amount_days,(SELECT description FROM Program WHERE id=program_id) as 'description',freezing,commission,type FROM Product";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) { ?>
                        <tr>
                            <td><?php echo $row['id'] ?></td>
                            <td><?php echo $row['name'] ?></td>
                            <td><?php echo $row['kcal'] ?></td>
                            <td><?php echo $row['price'] ?></td>
                            <td><?php echo $row['amount_days'] ?></td>
                            <td><?php echo $row['freezing'] ?></td>
                            <td><img src="<?php echo $row['photo'] ?>" width="75px" height="75px">
                            </td>
                            <td><?php echo $row['description'] ?></td>
                            <td><?php echo $row['commission'] ?></td>
                            <td><?php if($row['type'] == 1) {echo 'По адресу';} else if($row['type'] == 2) {echo 'В спортзал';} else {echo 'Особые условия';}  ?></td>
                            <?php if($_SESSION['status'] == 1) { ?>
                            <td>
                                <a style="margin-right: 15px" href="editPrice.php?id=<?php echo $row['id'] ?>"><i class="glyphicon glyphicon-pencil"></i></a>
                                <a href="" onclick="actions('deletePrice', <?php echo $row['id'] ?>)"><i class="glyphicon glyphicon-trash"></i></a>
                            </td>
                            <?php } ?>
                        </tr>
                    <?php }} ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- SCRIPTS -->
<script src="../js/jquery-1.11.3.min.js" type="text/javascript"></script>
<script src="../js/bootstrap.min.js" type="text/javascript"></script>
<script src="../js/jquery.validate.min.js" type="text/javascript"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script>
    function actions(action, id) {
        $.ajax({
            url: "actions.php",
            data: {action:action, price_id:id},
            type: "POST",
            success: function (data) {
                switch (action) {
                    case "deletePrice":
                        location.reload();
                        break;
                }
            }
        });
    }

    $(".glyphicon-trash").click(function(){
        if(!confirm("Вы хотите удалить?"))
            return false;
    });

    function getRequest(action,val) {
        var price_type = $("#price_type").val();
        var program = $("#program").val();
        $.ajax({
            type: "POST",
            url: "actions.php",
            data: {action:action,val:val,price_type:price_type,program:program},
            success: function(data){
                switch (action) {
                    case "getPriceType":
                        $("table.table tbody").html(data);
                        break;
                    case "getPriceTypeProduct":
                        $("table.table tbody").html(data);
                        break;
                }

            }
        });
    }

</script>

</body>
</html>
