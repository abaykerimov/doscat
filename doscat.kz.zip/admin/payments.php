<?php
header('Content-type: text/html; charset=utf8');
session_start();
include("../bd.php");
$status = $_SESSION['status'];
$gym_id = $_SESSION['gym_id'];
include('../actions/functions.php');
?>

<!DOCTYPE html>
<html lang="zxx">
<head>

    <!-- TITLE OF SITE -->
    <title>Все платежи</title>


    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0" />
    <!--[if IE]><meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1'><![endif]-->
    <meta name="author" content="bierx_87" />
    <meta name="description" content="" />

    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <link rel="stylesheet/less" type="text/css" href="../css/main.less">
    <script type="text/javascript" src="../js/less.min.js"></script>
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">

    <noscript>
        <strong>Warning!</strong>
        Your browser does not support HTML5 so some elements on this page are simulated using JScript. Unfortunately your browser has JScript disabled. Please enable it in order to display this page.
    </noscript>
    <style>
        .get{
            margin-top: 10px;
        }
        .form-control{
            display: inline-block;
            max-width: 250px;
            margin-top: 20px;;
        }
        .row-all-project {
            margin: 0;
            padding: 0;
            vertical-align: top;
            background-color: white!important;
            border: none!important;
        }
        .row-all-project h4 {
            border-bottom: 2px solid #dddddd;
            padding: 10px 15px;
            margin: 0;
            color: black;
        }
        .row-all-project a {
            border-bottom: 1px solid #dddddd;
            padding: 7px 10px;
            margin: 0;
            display: block;
            text-shadow: none;
        }
        .block_menu .nav-tabs li {
            display: block;
            max-width: 50%;
            margin-left: 0;
        }
    </style>
</head>

<body>

<?php
include("menuTemp.php");
?>

<!-- HEADER END -->
<div class="container block_menu text-center">
    <div id="myTabContent" class="tab-content">

        <div class="panel-title" style="font-size: 20px;text-align: center;margin-top: 15px;"><span>Все платежи</span></div>
        <?php
        $query_balance = $conn->prepare("SELECT u.first_name, u.last_name, hp.id, hp.dateOfPayment, hp.lastPayment, hp.paymentMethod, (SELECT name FROM PaymentMethod WHERE id = paymentMethod) as `paymentMethodName`, hp.transaction, hp.comment FROM HistoryOfPayment hp JOIN Users u ON u.id = hp.user_id ORDER by dateOfPayment DESC");
        $query_balance->execute();
        $query_balance->store_result();
        if ($query_balance->num_rows > 0) {
            $query_balance->bind_result($f_name, $l_name, $id_balance,$dateOfPayment,$lastPayment,$paymentMethod,$paymentMethodName,$transaction,$comment);
            while ($query_balance->fetch()) {

                $arr_balance[] = array(
                    'first_name' => $f_name,
                    'last_name' => $l_name,
                    'id' => $id_balance,
                    'dateOfPayment' => $dateOfPayment,
                    'lastPayment' => $lastPayment,
                    'paymentMethod' => $paymentMethod,
                    'paymentMethodName' => $paymentMethodName,
                    'transaction' => $transaction,
                    'comment' => $comment
                );

            }
        }
        $query_balance->close();
        ?>
        <table class="table table-hover " style="width: 100%">
            <thead>
            <tr>
                <th width="20%">ФИО</th>
                <th>Сумма оплаты</th>
                <th width="10%">Дата оплаты</th>
                <th>Способ оплаты</th>
                <th>Номер транзакции</th>
                <th>Комментарий</th>
            </tr>
            </thead>
            <tbody>
            <?php
            foreach ($arr_balance as $i => $value) {
                $arr = $arr_balance[$i];
                $date = DateTime::createFromFormat('Y-m-d', $arr['dateOfPayment']);
                $date_request = $date->format("d-m-Y");
                echo "<tr>";
                echo "<td>".$arr['first_name']." ".$arr['last_name'] ."</td>";
                echo "<td>".number_format($arr['lastPayment'], 0, ',', ' ')." тг"."</td>";
                echo "<td>".$date_request."</td>";
                echo "<td>".$arr['paymentMethodName']."</td>";
                echo "<td>".$arr['transaction']."</td>";
                echo "<td>".$arr['comment']."</td>";
                echo "</tr>";
            }
            ?>
            </tbody>
        </table>
    </div>
</div>

<!-- CONTACT END -->
<!-- SCRIPTS -->
<script src="../js/jquery-1.11.3.min.js" type="text/javascript"></script>
<script src="../js/bootstrap.min.js" type="text/javascript"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/js/bootstrap-datepicker.min.js"></script>
<script src="../js/jquery.validate.min.js" type="text/javascript"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script>
    $(function () {
        $('#dateFilter').datepicker({
            autoclose: true,
            dateFormat: 'dd-mm-yy',
            language: 'ru',
            todayHighlight: true,
            onSelect: function() {
                var date = $("#dateFilter").val();
                getRequest('getOrderRequest',date);
            }
        });
        $.datepicker.regional['ru'] = {clearStatus: '',
            monthNames: ['Январь','Февраль','Март','Апрель','Май','Июнь',
                'Июль','Август','Сентябрь','Октябрь','Ноябрь','Декабрь'],
            monthNamesShort: ['Янв','Фев','Мар','Апр','Май','Июн',
                'Июл','Авг','Сен','Окт','Ноя','Дек'],
            dayNames: ['Воскресенье','Понедельник','Вторник','Среда','Четверг','Пятница','Суббота'],
            dayNamesShort: ['Вс','Пн','Вт','Ср','Чт','Пт','Сб'],
            dayNamesMin: ['Вс','Пн','Вт','Ср','Чт','Пт','Сб'],
            firstDay: 1 };
        $.datepicker.setDefaults($.datepicker.regional['ru']);
    });

    function getRequest(action,val) {
        var d_filter = $("#dateFilter").val();
        var s_filter = $("#statusFilter").val();
        $.ajax({
            type: "POST",
            url: "actions.php",
            data: {action:action,val:val,d_filter:d_filter,s_filter:s_filter},
            success: function(data){
                switch (action) {
                    case "getOrder":
                        $(".modal-body").html(data);
                        break;
                    case "deleteOrder":
                        setTimeout(function(){
                            location.reload();
                        },1000);
                        break;
                    case "getOrderRequest":
                        $("table.table tbody").html(data);
                        break;
                    case "getOrderStatus":
                        $("table.table tbody").html(data);
                        break;
                }

            }
        });
    }
</script>
</body>
</html>
