<?php
header('Content-type: text/html; charset=utf8');
session_start();
$status = $_SESSION['status'];
$gym_id = $_SESSION['gym_id'];
include("../bd.php");
include("../actions/filter.php");
include("../actions/functions.php");
$id = $_SESSION["user_id"];

$resultUser = $conn->query("set names utf8");
$sqlUser = "SELECT * FROM Users WHERE id = '$id'";
$resultUser = $conn->query($sqlUser);
$rowUser = $resultUser->fetch_assoc();
$user_status = $rowUser['user_status'];

$photo = filter('photo');
$name = filter('name');
$description = filter('description');
$kcal = filter('kcal');
$protein = filter('protein');
$fat = filter('fat');
$carbo = filter('carbo');

$action = $_POST["action"];
$food_id = $_POST["food_id"];
$menu_id = $_POST["menu_id"];
$food_value = $_POST["food_value"];
if (!empty($action)) {
    switch ($action) {
        case "addFood":
            $get_type = filter("get_type");
            $unit = filter("unit");
            $price = filter("price");
            $query = $conn->query("set names utf8");
            $query = $conn->query("SELECT id FROM Foods WHERE name = '$name'");
            if ($query->num_rows > 0) {
                echo '<script>alert("Такой рецепт уже существует!")</script>';

            } else {
                $insert_row = $conn->query("set names utf8");
                $insert_row = $conn->prepare('INSERT INTO Foods (photo, name, description, kcal, protein, fat, carbohydrate, unit, price, isDessert) VALUES (?,?,?,?,?,?,?,?,?,?)');
                $insert_row->bind_param('sssssssiii', $photo, $name, $description, $kcal, $protein, $fat, $carbo, $unit, $price, $get_type);
                $insert_row->execute();
                $insert_row->close();
            }
            break;
        case "editFood":
            $check = filter("check");
            $query = $conn->query("set names utf8");
            $query = $conn->prepare("UPDATE Foods SET name = '$name', photo = '$photo', description = '$description', kcal = '$kcal', protein = '$protein', fat = '$fat', carbohydrate = '$carbo',isCheck = '$check' WHERE id = ?");
            $query->bind_param('i', $food_id);
            $query->execute();
            if ($conn->errno) {
                die('Select Error (' . $conn->errno . ') ' . $conn->error);
            }
            $query->close();
            break;
        case "deleteFood":
            if (!empty($food_id)) {
                $query = $conn->prepare('DELETE FROM Foods WHERE id = ?');
                $query->bind_param('i', $food_id);
                $query->execute();
                if ($conn->errno) {
                    die('Select Error (' . $conn->errno . ') ' . $conn->error);
                }
                $query->close();
            }
            break;
        case "get_1":
            include("../actions/getFoodIngredients.php");
            break;
        case "get_2":
            include("../actions/getFoodIngredients.php");
            break;
        case "get_3":
            include("../actions/getFoodIngredients.php");
            break;
        case "get_4":
            include("../actions/getFoodIngredients.php");
            break;
        case "get_5":
            include("../actions/getFoodIngredients.php");
            break;
        case "get_6":
            include("../actions/getFoodIngredients.php");
            break;
        case "get_7":
            include("../actions/getFoodIngredients.php");
            break;
        case "get_8":
            include("../actions/getFoodIngredients.php");
            break;
        case "get_9":
            include("../actions/getFoodIngredients.php");
            break;
        case "get_10":
            include("../actions/getFoodIngredients.php");
            break;
        case "get_11":
            include("../actions/getFoodIngredients.php");
            break;
        case "get_12":
            include("../actions/getFoodIngredients.php");
            break;
        case "get_13":
            include("../actions/getFoodIngredients.php");
            break;
        case "addMenu":
            $program = filter('program');
            $number = rand(1, 1000);
            $date_post = filter('date');
            $date = DateTime::createFromFormat('d-m-Y', $date_post);
            $date_start = $date->format("Y-m-d");
            $numKcal = filter('numKcal');
            $kcal = filter("kcal");
            $pro = filter("pro");
            $fat = filter("fat");
            $carbo = filter("carbo");
            $menu_type = filter("menu_type");

            $query = $conn->query("set names utf8");
            $query = $conn->prepare('INSERT INTO Menu (program_id, menu_number, date_start, number_kcal,user_id,kcal,protein,fat,carbo,type) VALUES (?,?,?,?,?,?,?,?,?,?)');
            $query->bind_param('iisiissssi', $program, $number, $date_start, $numKcal, $id, $kcal, $pro, $fat, $carbo, $menu_type);
            $query->execute();
            $query->close();
            break;
        case "addFoods":
            $type = filter('food_types');
            $foods = filter('foods');
            $portion = filter('portion');
            $sql = "SELECT id FROM Menu ORDER BY id DESC LIMIT 1";
            $query = $conn->query($sql);
            while($row = $query->fetch_assoc()) {
                $result = $conn->prepare('INSERT INTO Menu_Foods (food_id, food_type_id, portion, menu_id) VALUES (?,?,?,?)');
                $result->bind_param('iiii', $foods, $type, $portion, $row['id']);
                $result->execute();
            }
            break;
        case "editMenu":
            $menuid = filter("id");
            $program = filter("program");
            $date = filter("date");
            $day = filter("day");
            $query = $conn->query("set names utf8");
            $query = $conn->prepare("UPDATE Menu SET program_id = '$program',date_start = '$date',day_of_the_week = '$day' WHERE id = ?");
            $query->bind_param('i', $menuid);
            $query->execute();
            $query->close();
            break;
        case "editFoods":
            $menuid = filter("id");
            $data_id = filter("data_id");
            $types = filter('food_types');
            $food = filter('foods');
            $portions = filter('portion');
            $query = $conn->query("set names utf8");
            $query = $conn->prepare("UPDATE Menu_Foods SET food_id = '$food',food_type_id = '$types',portion = '$portions' WHERE id = ?");
            $query->bind_param('i', $data_id);
            $query->execute();
            $query->close();
            break;
        case "deleteMenu":
            if (!empty($menu_id)) {
                $query = $conn->prepare('DELETE FROM Menu WHERE id = ?');
                $query->bind_param('i', $menu_id);
                $query->execute();
                if ($query) {
                    $result = $conn->prepare('DELETE FROM Menu_Foods WHERE menu_id = ?');
                    $result->bind_param('i', $menu_id);
                    $result->execute();
                }
                $query->close();
            }
            break;
        case "getAddress":
            $gym_id = filter("gym_id");
            if (!empty($gym_id)) {
                $result = $conn->query("set names utf8");
                $query = "SELECT address FROM Gyms WHERE id = '$gym_id'";
                $result = $conn->query($query);
                while ($row = $result->fetch_assoc()) { ?>
                    <?php echo $row["address"]; ?>
                    <?php
                }
                $result->close();
            }
            break;
        case "addOrder":
            $request_date = filter("request_date");
            $date = DateTime::createFromFormat('d-m-Y', $request_date);
            $date_request = $date->format("Y-m-d");
            $request_time = filter("request_time");
            $user = filter("user");
            $phone = filter("phone");
            $plan = filter("plan");
            $sport = filter("sport");
            $address = filter("address");
            $rcomment = filter("rcomment");
            $comment = filter("comment");
            $status = filter("status");
            $register = filter("register");
            $subscribe = filter("subscribe");
            $acomment = filter("acomment");
            if ($sport != "") {
                $bool = 1;
            } else {
                $bool = 0;
            }
            $insert_row = $conn->query("set names utf8");
            $insert_row = $conn->prepare('INSERT INTO Requests (request_date,request_time,product_id,name,phone,status,subscribe,isRegistered,custom_address,address_bool,gym_id) VALUES (?,?,?,?,?,?,?,?,?,?,?)');
            $insert_row->bind_param('ssisssiisii', $date_request, $request_time, $plan, $user, $phone, $status, $subscribe, $register, $address, $bool, $sport);
            $insert_row->execute();
            $r_id = $insert_row->insert_id;
            if ($insert_row) {
                $query = $conn->query("set names utf8");
                $query = $conn->prepare('INSERT INTO Request_Comments (request_comment, partner_comment, admin_comment, request_id) VALUES (?,?,?,?)');
                $query->bind_param('sssi', $rcomment, $comment, $acomment, $r_id);
                $query->execute();
            }
            $insert_row->close();
            break;
        case "getOrder":
            $order_id = filter("val");
            if (!empty($order_id)) {
                $result = $conn->query("set names utf8");
                $query = "SELECT p.id, u.first_name, u.last_name, u.phone, sip.name as status_name, u.custom_address, u.id_gym,(SELECT name FROM Gyms WHERE id = u.id_gym) as gym_name, (SELECT pp.name FROM Program pp WHERE pp.id = (SELECT program_id FROM Product WHERE id = p.product_id)) as product_name, p.date, p.price, p.days, (SELECT name FROM Delivery_inPlans WHERE id = p.delivery) as delivery, p.status FROM Plans p JOIN Users u ON u.id = p.user_id JOIN Status_inPlans sip ON sip.id = p.status WHERE p.id = '$order_id'";
                $result = $conn->query($query);
                while ($row = $result->fetch_assoc()) {
                    $date = DateTime::createFromFormat('Y-m-d', $row['date']);
                    $date_start = $date->format("d-m-y"); ?>
                    <form class="form-horizontal" role="form" data-toggle="validator" id="form">
                        <fieldset>
                            <div class="form-group">
                                <label for="inputDate" class="col-lg-4 control-label">Дата заявки:</label>

                                <div class="col-lg-4 text-left">
                                    <p class="get"><?php echo $row['date'] ?></p>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="inputClient" class="col-lg-4 control-label">Имя:</label>

                                <div class="col-lg-4">
                                    <p class="get"><?php echo $row['first_name'] ?></p>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="inputClient" class="col-lg-4 control-label">Фамилия:</label>

                                <div class="col-lg-4">
                                    <p class="get"><?php echo $row['last_name'] ?></p>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="inputPhone" class="col-lg-4 control-label">Телефон:</label>

                                <div class="col-lg-4">
                                    <p class="get"><?php echo $row['phone'] ?></p>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="inputPlan" class="col-lg-4 control-label">План питания:</label>

                                <div class="col-lg-4">
                                    <p class="get"><?php echo $row['product_name'] ?></p>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="inputPlan" class="col-lg-4 control-label">Количество дней:</label>

                                <div class="col-lg-4">
                                    <p class="get"><?php echo $row['days'] ?></p>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="inputPlan" class="col-lg-4 control-label">Общая сумма:</label>

                                <div class="col-lg-4">
                                    <p class="get"><?php echo $row['price']*$row['days'] ?></p>
                                </div>
                            </div>

                            

                            <div class="form-group">
                                <label for="inputStatus" class="col-lg-4 control-label">Статус заявки:</label>

                                <div class="col-lg-4">
                                    <p class="get"><?php echo $row['status_name'] ?></p>
                                </div>
                            </div>

                            <div class="form-group text-center add">
                                <div class="col-lg-12">
                                    <button type="button" class="btn btn-default" data-dismiss="modal">Закрыть</button>
                                    <a class="btn btn-warning" href="editOrder.php?id=<?php echo $order_id ?>">Редактировать</a>
                                    <a class="btn btn-danger" onclick="
                                        if (confirm('Вы хотите удалить?')){
                                        getRequest('deleteOrder', <?php echo $order_id ?>)}"
                                       data-dismiss="modal">Удалить</a>
                                </div>
                            </div>
                        </fieldset>
                    </form>
                    <?php
                }
                $result->close();
            }
            break;
        case "deleteOrder":
            $order_id = filter("val");
            if (!empty($order_id)) {
                $query = $conn->prepare('DELETE FROM Requests WHERE id = ?');
                $query->bind_param('i', $order_id);
                $query->execute();
                if ($query) {
                    $result = $conn->prepare('DELETE FROM Request_Comments WHERE request_id = ?');
                    $result->bind_param('i', $order_id);
                    $result->execute();
                }
                $query->close();
            }
            break;
        case "editOrder":
            $order_id = filter("val");
            $status = filter("status");

            $query = $conn->query("set names utf8");
            $query = $conn->prepare("UPDATE Plans SET status='$status' WHERE id = ?");
            $query->bind_param('i', $order_id);
            $query->execute();
            echo $order_id;
            $query->close();
            break;
        case "getOrderRequest":
            $active_plan = active($id);
            $filter_date = filter("val");
            $s_filter = filter("s_filter");
            $date = DateTime::createFromFormat('d-m-Y', $filter_date);
            $date_request = $date->format("Y-m-d");
            if($status == 1) {
                if(empty($s_filter)) {
                    $query_reestr = $conn->prepare("SELECT p.id, u.first_name, u.last_name, sip.name, (SELECT pp.name FROM Program pp WHERE pp.id = (SELECT program_id FROM Product WHERE id = p.product_id)) as product_name, p.date, p.price, p.days, (SELECT name FROM Delivery_inPlans WHERE id = p.delivery) as delivery, p.status FROM Plans p JOIN Users u ON u.id = p.user_id JOIN Status_inPlans sip ON sip.id = p.status WHERE p.date = '$date_request' ORDER by date DESC");
                } else {
                    $query_reestr = $conn->prepare("SELECT p.id, u.first_name, u.last_name, sip.name, (SELECT pp.name FROM Program pp WHERE pp.id = (SELECT program_id FROM Product WHERE id = p.product_id)) as product_name, p.date, p.price, p.days, (SELECT name FROM Delivery_inPlans WHERE id = p.delivery) as delivery, p.status FROM Plans p JOIN Users u ON u.id = p.user_id JOIN Status_inPlans sip ON sip.id = p.status WHERE p.date = '$date_request' AND p.status = '$s_filter' ORDER by date DESC");
                }

            } else {
                if(empty($s_filter)) {
                    $query_reestr = $conn->prepare("SELECT p.id, u.first_name, u.last_name, sip.name, (SELECT pp.name FROM Program pp WHERE pp.id = (SELECT program_id FROM Product WHERE id = p.product_id)) as product_name, p.date, p.price, p.days, (SELECT name FROM Delivery_inPlans WHERE id = p.delivery) as delivery, p.status FROM Plans p JOIN Users u ON u.id = p.user_id JOIN Status_inPlans sip ON sip.id = p.status WHERE u.id_gym = '$gym_id' AND p.date = '$date_request' ORDER by date DESC");
                } else {
                    $query_reestr = $conn->prepare("SELECT p.id, u.first_name, u.last_name, sip.name, (SELECT pp.name FROM Program pp WHERE pp.id = (SELECT program_id FROM Product WHERE id = p.product_id)) as product_name, p.date, p.price, p.days, (SELECT name FROM Delivery_inPlans WHERE id = p.delivery) as delivery, p.status FROM Plans p JOIN Users u ON u.id = p.user_id JOIN Status_inPlans sip ON sip.id = p.status WHERE u.id_gym = '$gym_id' AND p.date = '$date_request' AND p.status = '$s_filter' ORDER by date DESC");
                }
            }
            $query_reestr->execute();
            $query_reestr->store_result();
            if ($query_reestr->num_rows > 0) {
                $query_reestr->bind_result($reestr_id,$f_name, $l_name, $status_name, $reestr_prod_name,$reestr_date,$reestr_price,$reestr_days,$reestr_dostavka,$reestr_status_id);
                while ($query_reestr->fetch()) {
                    if ($active_plan['id_plan'] == $reestr_id) {
                        $dney_proideno = $active_plan['days_off'];
                        $dney_ostalos = ($active_plan['days']-$active_plan['days_off']);
                        $data_start_eat = $active_plan['date_start_eat'];
                    } else {
                        $query_dayoff = $conn->prepare("SELECT count(id), min(date) FROM Calendars WHERE date <= DATE_ADD(CURDATE(),INTERVAL 1 DAY) and plan_id = ?");
                        $query_dayoff->bind_param('i', $reestr_id);
                        $query_dayoff->execute();
                        $query_dayoff->store_result();
                        if ($query_dayoff->num_rows > 0) {
                            $query_dayoff->bind_result($dney_proideno,$data_start_eat);
                            while ($query_dayoff->fetch()) {
                            }
                        }
                        $query_dayoff->close();
                        $dney_ostalos = $reestr_days-$dney_proideno;
                    }
                    if($reestr_status_id == 1) {
                        $css = 'style = "color: red"';
                    } elseif ($reestr_status_id == 2) {
                        $css = 'style = "color: green"';
                    } elseif ($reestr_status_id == 3) {
                        $css = 'style = "color: black"';
                    } elseif ($reestr_status_id == 4) {
                        $css = 'style = "color: blue"';
                    }
                    ?>
                        <tr data-toggle='modal' data-target='#myModal' style='cursor: pointer' onclick="getRequest('getOrder',<?php echo $reestr_id ?>)">
                            <td width="5%"><?php echo $reestr_id ?></td>
                            <td><?php echo $f_name." ".$l_name ?></td>
                            <td><?php echo $reestr_prod_name ?></td>
                            <td><?php echo $reestr_dostavka ?></td>
                            <td><?php echo $reestr_days ?></td>
                            <td><?php echo $data_start_eat ?></td>
                            <td><?php echo $reestr_price ?></td>
                            <td><?php echo $reestr_price*$reestr_days ?></td>
                            <td><?php echo $reestr_date ?></td>
                            <td><?php echo $dney_proideno ?></td>
                            <td><?php echo $dney_ostalos ?></td>
                            <td style="width: 30%">
                                <select class="form-control status" id="status_<?php echo $reestr_id ?>" onchange="getRequest('editOrder', <?php echo $reestr_id ?>, this.value)" <?php echo $css ?>>
                                    <?php
                                    $qSiP = "SELECT * FROM Status_inPlans";
                                    $rSiP = $conn->query($qSiP);
                                    while ($rowSiP = $rSiP->fetch_assoc()) { ?>
                                        <option value="<?php echo $rowSiP["id"]; ?>"<?php if($rowSiP["id"] == $reestr_status_id) echo 'selected' ?>><?php echo $rowSiP["name"]; ?></option>
                                    <?php } ?>
                                </select>

                            </td>
                        </tr>
                <?php }
            }
            $query_reestr->close();
            break;
        case "getOrderStatus":
            $active_plan = active($id);
            $value = filter("val");
            $d_filter = filter("d_filter");
            if(!empty($d_filter)) {
                $date = DateTime::createFromFormat('d-m-Y', $d_filter);
                $date_request = $date->format("Y-m-d");
            }

            if($user_status == 1) {
                if($value != "") {
                    if(empty($d_filter)) {
                        $query_reestr = $conn->prepare("SELECT p.id, u.first_name, u.last_name, sip.name, (SELECT pp.name FROM Program pp WHERE pp.id = (SELECT program_id FROM Product WHERE id = p.product_id)) as product_name, p.date, p.price, p.days, (SELECT name FROM Delivery_inPlans WHERE id = p.delivery) as delivery, p.status FROM Plans p JOIN Users u ON u.id = p.user_id JOIN Status_inPlans sip ON sip.id = p.status WHERE p.status = '$value' ORDER by date DESC");
                    } else {
                        $query_reestr = $conn->prepare("SELECT p.id, u.first_name, u.last_name, sip.name, (SELECT pp.name FROM Program pp WHERE pp.id = (SELECT program_id FROM Product WHERE id = p.product_id)) as product_name, p.date, p.price, p.days, (SELECT name FROM Delivery_inPlans WHERE id = p.delivery) as delivery, p.status FROM Plans p JOIN Users u ON u.id = p.user_id JOIN Status_inPlans sip ON sip.id = p.status WHERE p.status = '$value' AND p.date = '$date_request' ORDER by date DESC");
                    }
                } else {
                    $query_reestr = $conn->prepare("SELECT p.id, u.first_name, u.last_name, sip.name, (SELECT pp.name FROM Program pp WHERE pp.id = (SELECT program_id FROM Product WHERE id = p.product_id)) as product_name, p.date, p.price, p.days, (SELECT name FROM Delivery_inPlans WHERE id = p.delivery) as delivery, p.status FROM Plans p JOIN Users u ON u.id = p.user_id JOIN Status_inPlans sip ON sip.id = p.status ORDER by date DESC");
                }
            } else {
                if($value != "") {
                    if(empty($d_filter)) {
                        $query_reestr = $conn->prepare("SELECT p.id, u.first_name, u.last_name, sip.name, (SELECT pp.name FROM Program pp WHERE pp.id = (SELECT program_id FROM Product WHERE id = p.product_id)) as product_name, p.date, p.price, p.days, (SELECT name FROM Delivery_inPlans WHERE id = p.delivery) as delivery, p.status FROM Plans p JOIN Users u ON u.id = p.user_id JOIN Status_inPlans sip ON sip.id = p.status WHERE u.id_gym = '$gym_id' AND p.status = '$value' ORDER by date DESC");
                    } else {
                        $query_reestr = $conn->prepare("SELECT p.id, u.first_name, u.last_name, sip.name, (SELECT pp.name FROM Program pp WHERE pp.id = (SELECT program_id FROM Product WHERE id = p.product_id)) as product_name, p.date, p.price, p.days, (SELECT name FROM Delivery_inPlans WHERE id = p.delivery) as delivery, p.status FROM Plans p JOIN Users u ON u.id = p.user_id JOIN Status_inPlans sip ON sip.id = p.status WHERE u.id_gym = '$gym_id' AND p.status = '$value' AND p.date = '$date_request' ORDER by date DESC");
                    }
                } else {
                    $query_reestr = $conn->prepare("SELECT p.id, u.first_name, u.last_name, sip.name, (SELECT pp.name FROM Program pp WHERE pp.id = (SELECT program_id FROM Product WHERE id = p.product_id)) as product_name, p.date, p.price, p.days, (SELECT name FROM Delivery_inPlans WHERE id = p.delivery) as delivery, p.status FROM Plans p JOIN Users u ON u.id = p.user_id JOIN Status_inPlans sip ON sip.id = p.status WHERE u.id_gym = '$gym_id' ORDER by date DESC");
                }
            }
            $query_reestr->execute();
            $query_reestr->store_result();
            if ($query_reestr->num_rows > 0) {
                $query_reestr->bind_result($reestr_id,$f_name, $l_name, $status_name, $reestr_prod_name,$reestr_date,$reestr_price,$reestr_days,$reestr_dostavka,$reestr_status_id);
                while ($query_reestr->fetch()) {
                    if ($active_plan['id_plan'] == $reestr_id) {
                        $dney_proideno = $active_plan['days_off'];
                        $dney_ostalos = ($active_plan['days']-$active_plan['days_off']);
                        $data_start_eat = $active_plan['date_start_eat'];
                    } else {
                        $query_dayoff = $conn->prepare("SELECT count(id), min(date) FROM Calendars WHERE date <= DATE_ADD(CURDATE(),INTERVAL 1 DAY) and plan_id = ?");
                        $query_dayoff->bind_param('i', $reestr_id);
                        $query_dayoff->execute();
                        $query_dayoff->store_result();
                        if ($query_dayoff->num_rows > 0) {
                            $query_dayoff->bind_result($dney_proideno,$data_start_eat);
                            while ($query_dayoff->fetch()) {
                            }
                        }
                        $query_dayoff->close();
                        $dney_ostalos = $reestr_days-$dney_proideno;
                    }
                    if($reestr_status_id == 1) {
                        $css = 'style = "color: red"';
                    } elseif ($reestr_status_id == 2) {
                        $css = 'style = "color: green"';
                    } elseif ($reestr_status_id == 3) {
                        $css = 'style = "color: black"';
                    } elseif ($reestr_status_id == 4) {
                        $css = 'style = "color: blue"';
                    }
                    ?>
                        <tr data-toggle='modal' data-target='#myModal' style='cursor: pointer' onclick="getRequest('getOrder',<?php echo $reestr_id ?>)">
                            <td><?php echo $reestr_id ?></td>
                            <td><?php echo $f_name." ".$l_name ?></td>
                            <td><?php echo $reestr_prod_name ?></td>
                            <td><?php echo $reestr_dostavka ?></td>
                            <td><?php echo $reestr_days ?></td>
                            <td><?php echo $data_start_eat ?></td>
                            <td><?php echo $reestr_price ?></td>
                            <td><?php echo $reestr_price*$reestr_days ?></td>
                            <td><?php echo $reestr_date ?></td>
                            <td><?php echo $dney_proideno ?></td>
                            <td><?php echo $dney_ostalos ?></td>
                            <td style="width: 30%">
                                <select class="form-control status" id="status_<?php echo $reestr_id ?>" onchange="getRequest('editOrder', <?php echo $reestr_id ?>, this.value)" <?php echo $css ?>>
                                    <?php
                                    $qSiP = "SELECT * FROM Status_inPlans";
                                    $rSiP = $conn->query($qSiP);
                                    while ($rowSiP = $rSiP->fetch_assoc()) { ?>
                                        <option value="<?php echo $rowSiP["id"]; ?>"<?php if($rowSiP["id"] == $reestr_status_id) echo 'selected' ?>><?php echo $rowSiP["name"]; ?></option>
                                    <?php } ?>
                                </select>

                            </td>
                        </tr>
                <?php }
            }
            $query_reestr->close();
            break;

        case "getClientGym":
            $gym = filter("val");
            $status = filter ("status");
            $resultClient = $conn->query("set names utf8");

            if ($gym == "") {
                $sqlClient = "SELECT u.id,(SELECT name FROM Gyms WHERE id = u.id_gym) as gym,u.first_name,u.last_name,u.phone FROM Users u";
            } elseif ($gym == '0') {
                $sqlClient = "SELECT u.id,(SELECT name FROM Gyms WHERE id = u.id_gym) as gym,u.first_name,u.last_name,u.phone FROM Users u WHERE u.id_gym='$gym'";
            } elseif ($gym != "") {
                $sqlClient = "SELECT u.id,(SELECT name FROM Gyms WHERE id = u.id_gym) as gym,u.first_name,u.last_name,u.phone FROM Users u WHERE u.id_gym='$gym'";
            }

            $resultClient = $conn->query($sqlClient);
            while ($rowClient = $resultClient->fetch_assoc()) {
                $active = active($rowClient['id']);
                $balance = balance($rowClient['id']);
                if (preg_match('/-/', $balance)){
                    $css = 'style = "color: red"';
                } else {
                    $css = 'style = "color: black"';
                }
                ?>
                <tr style="cursor: pointer" onclick="actions(<?php echo $rowClient['id'] ?>)">
                    <td><?php echo $rowClient['id'] ?></td>
                    <td><?php echo $rowClient['gym'] ?></td>
                    <td><?php echo $rowClient['first_name'] . " " . $rowClient['last_name'] ?></td>
                    <td><?php echo $rowClient['phone'] ?></td>
                    <td><?php echo $active['name_product'] ?></td>
                    <td><?php echo ($active['days']-$active['days_off']); ?></td>
                    <td <?php echo $css ?>><?php echo $balance ?></td>
                    <td><?php echo $rowClient['comment'] ?></td>
                </tr>
            <?php }
            $resultClient->close();
            break;

        case "getClientSubscribe":
            $val = filter("val");
            $resultClient = $conn->query("set names utf8");
             if($user_status == 2){
            if ($val == "") {
                $sqlClient = "SELECT u.id,(SELECT name FROM Gyms WHERE id = u.id_gym) as gym,u.first_name,u.last_name,u.phone FROM Users u where u.id_gym = '$gym_id'";
            } elseif ($val == '0') {
                $sqlClient = "SELECT u.id,(SELECT name FROM Gyms WHERE id = u.id_gym) as gym,u.first_name,u.last_name,u.phone FROM Users u WHERE u.id NOT IN (SELECT user_id FROM Plans) and u.id_gym = '$gym_id'";
            } elseif ($val != "") {
                $sqlClient = "SELECT u.id,(SELECT name FROM Gyms WHERE id = u.id_gym) as gym,u.first_name,u.last_name,u.phone FROM Users u WHERE u.id IN (SELECT user_id FROM Plans) and u.id_gym = '$gym_id'";
            }
            }
            else {
            if ($val == "") {
                $sqlClient = "SELECT u.id,(SELECT name FROM Gyms WHERE id = u.id_gym) as gym,u.first_name,u.last_name,u.phone FROM Users u ";
            } elseif ($val == '0') {
                $sqlClient = "SELECT u.id,(SELECT name FROM Gyms WHERE id = u.id_gym) as gym,u.first_name,u.last_name,u.phone FROM Users u WHERE u.id NOT IN (SELECT DISTINCT user_id FROM Plans p JOIN Calendars c ON c.plan_id = p.id WHERE c.date >= CURDATE())";
            } elseif ($val != "") {
                $sqlClient = "SELECT u.id,(SELECT name FROM Gyms WHERE id = u.id_gym) as gym,u.first_name,u.last_name,u.phone FROM Users u WHERE u.id IN (SELECT DISTINCT user_id FROM Plans p JOIN Calendars c ON c.plan_id = p.id WHERE c.date >= CURDATE())";
            }
            }
            $resultClient = $conn->query($sqlClient);
            while ($rowClient = $resultClient->fetch_assoc()) {
                $active = active($rowClient['id']);
                $balance = balance($rowClient['id']);
                if (preg_match('/-/', $balance)){
                    $css = 'style = "color: red"';
                } else {
                    $css = 'style = "color: black"';
                }
                ?>
                <tr style="cursor: pointer" onclick="actions(<?php echo $rowClient['id'] ?>)">
                    <td><?php echo $rowClient['id'] ?></td>
                    <td><?php echo $rowClient['gym'] ?></td>
                    <td><?php echo $rowClient['first_name'] . " " . $rowClient['last_name'] ?></td>
                    <td><?php echo $rowClient['phone'] ?></td>
                    <td><?php echo $active['name_product'] ?></td>
                    <td><?php echo ($active['days']-$active['days_off']); ?></td>
                    <td <?php echo $css ?>><?php echo $balance ?></td>
                    <td><?php echo $rowClient['comment'] ?></td>
                </tr>
            <?php }
            $resultClient->close();
            break;

        case "getMenuProgram":
            $program = filter("menu_id");
            $get_type = filter("get_type");
            $resultMenu = $conn->query("set names utf8");
            if($program == "") {
                $sqlMenu = "SELECT id, (SELECT name FROM Program WHERE id = program_id) as program, menu_number,date_start,kcal,protein,fat,carbo FROM Menu ORDER BY date_start";
            } else{
                $sqlMenu = "SELECT id, (SELECT name FROM Program WHERE id = program_id) as program, menu_number,date_start,kcal,protein,fat,carbo FROM Menu WHERE program_id = '$program' ORDER BY date_start";
            }
            $resultMenu = $conn->query($sqlMenu);
            $count = 0;
            while ($rowMenu = $resultMenu->fetch_assoc()) {
                $menu_id = $rowMenu['id'];

                $result = $conn->query("set names utf8");
                $sql = "SELECT DISTINCT food_type_id, (SELECT type_name FROM Food_Type WHERE id=food_type_id) as name FROM Menu_Foods m JOIN Food_Type ft ON ft.id=m.food_type_id WHERE menu_id = '$menu_id' ORDER BY ft.sort";
                $result = $conn->query($sql);
                if ($result->num_rows > 0 && $result->num_rows == $get_type){

                    if ($count == 0) {
                        ?>

                        <thead>
                        <tr>
                            <th class='th_name' style="width: 5%">№</th>
                            <th width="10%">Дата недели</th>
                            <?php
                            while ($row = $result->fetch_assoc()) {
                                ?>
                                <!--SELECT DISTINCT `food_type_id` FROM `Menu_Foods`
                                WHERE `menu_id` in (SELECT id FROM Menu WHERE date_start = "2017-01-09") ORDER by `food_type_id`
                                запомни в переменную число количество -->
                                <th><?php echo $row['name'] ?></th>
                            <?php } ?>
                            <th>Ккал</th>
                            <th>Белок</th>
                            <th>Жир</th>
                            <th>Угл</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
                        $count++;
                    }
                    $date = DateTime::createFromFormat('Y-m-d', $rowMenu['date_start']);
                    $date_start = $date->format("d-m-y"); ?>
                <tr data-toggle="modal" data-target="#myModal" style="cursor: pointer"
                    onclick="actions('getMenu',<?php echo $rowMenu['id'] ?>)">
                    <td><?php echo $rowMenu['id'] ?></td>
                    <td width="20%"><?php echo $date_start ?><br>
                        <?php $day = date('l', strtotime($rowMenu['date_start']));
                        if ($day == "Monday") {
                            $day = "Понедельник";
                        } else if ($day == "Tuesday") {
                            $day = "Вторник";
                        } else if ($day == "Wednesday") {
                            $day = "Среда";
                        } else if ($day == "Thursday") {
                            $day = "Четверг";
                        } else if ($day == "Friday") {
                            $day = "Пятница";
                        } else if ($day == "Saturday") {
                            $day = "Суббота";
                        } else if ($day == "Sunday") {
                            $day = "Воскресенье";
                        }
                        echo $day;?><br>
                        <?php echo $rowMenu['program'] ?></td>
                    <?php
                    $resultType = $conn->query("set names utf8");
                    $sqlType = "SELECT DISTINCT food_type_id
                    FROM Menu_Foods m JOIN Food_Type ft ON ft.id=m.food_type_id WHERE menu_id = '$menu_id' ORDER by ft.sort";

                    $resultType = $conn->query($sqlType);
                    if ($resultType->num_rows > 0){
                        while ($rowType = $resultType->fetch_assoc()) {
                            //здесь сравнить переменную с размером массива
                            echo '<td>';
                            $type_id = $rowType['food_type_id'];
                            $resultFood = $conn->query("set names utf8");
                            $sqlFood = "SELECT f.id, f.name, m.portion,TRUNCATE((f.kcal*m.portion/100),2) as calcKcal, TRUNCATE((f.protein*m.portion/100),2) as calcPro,
                        TRUNCATE((f.fat*m.portion/100),2) as calcFat, TRUNCATE((f.carbohydrate*m.portion/100),2) as calcCarbo
                        FROM Menu_Foods m JOIN Foods f ON f.id = m.food_id
                        WHERE m.menu_id = '$menu_id' and m.food_type_id = '$type_id'";
                            $resultFood = $conn->query($sqlFood);

                            while ($rowFood = $resultFood->fetch_assoc()) {
                                ?>
                                <div class="col-md-12"
                                     style="margin-bottom: 10px;padding-left: 0;"><?php echo $rowFood['name'] ?></div>
                            <?php }
                            echo "</td>";
                        } ?>
                        <td class="kcal"><?php echo $rowMenu['kcal'] ?></td>
                        <td class="protein"><?php echo $rowMenu['protein'] ?></td>
                        <td class="fat"><?php echo $rowMenu['fat'] ?></td>
                        <td class="carbo"><?php echo $rowMenu['carbo'] ?></td>
                        </tr>
                    <?php }
                }
            }
            echo '</tbody>';
            break;
        case "getFood":
            $food_id = filter("food_id");
            if (!empty($food_id)) {
                $resultFood = $conn->query("set names utf8");
                $sqlFood = "SELECT * FROM Foods WHERE id = '$food_id'";
                $resultFood = $conn->query($sqlFood);
                while ($rowFood = $resultFood->fetch_assoc()) {
                    ?>
                    <form class="form-horizontal" role="form" data-toggle="validator" id="form">
                        <fieldset>
                            <div class="form-group">
                                <label for="inputDate" class="col-lg-4 control-label">Фото:</label>

                                <div class="col-lg-4 text-left">
                                    <img class="get" src="<?php echo $rowFood['photo'] ?>"/>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="inputTime" class="col-lg-4 control-label">Название:</label>

                                <div class="col-lg-4">
                                    <p class="get"><?php echo $rowFood['name'] ?></p>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="inputClient" class="col-lg-4 control-label">Описание:</label>

                                <div class="col-lg-4">
                                    <p class="get"><?php echo $rowFood['description'] ?></p>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="inputPhone" class="col-lg-4 control-label">Ккалория:</label>

                                <div class="col-lg-4">
                                    <p class="get"><?php echo $rowFood['kcal'] ?></p>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="inputPlan" class="col-lg-4 control-label">Белок:</label>

                                <div class="col-lg-4">
                                    <p class="get"><?php echo $rowFood['protein'] ?></p>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="inputPlace" class="col-lg-4 control-label">Жир:</label>

                                <div class="col-lg-4">
                                    <p class="get"><?php echo $rowFood['fat'] ?></p>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="inputAddress" class="col-lg-4 control-label">Углеводы:</label>

                                <div class="col-lg-4">
                                    <p class="get"><?php echo $rowFood['carbohydrate'] ?></p>
                                </div>
                            </div>
                            <div class="form-group text-center add">
                                <div class="col-lg-12">
                                    <button type="button" class="btn btn-default" data-dismiss="modal">Закрыть</button>
                                    <?php if ($rowFood['isCheck'] == 0 || ($status == 1 && $rowFood['isCheck'] == 1)) { ?>
                                        <a class="btn btn-warning" href="editFood.php?id=<?php echo $rowFood['id'] ?>">Редактировать</a>
                                        <a class="btn btn-danger" onclick="
                                            if (confirm('Вы хотите удалить?')){
                                            actions('deleteFood', <?php echo $rowFood['id'] ?>)}" data-dismiss="modal">Удалить</a>
                                    <?php } ?>
                                </div>
                            </div>
                        </fieldset>
                    </form>
                    <?php
                }
                $resultFood->close();
            }
            break;
        case "addGym":
            $gym_name = filter("gym_name");
            $gym_address = filter("gym_address");
            $insert_row = $conn->query("set names utf8");
            $insert_row = $conn->prepare('INSERT INTO Gyms (name, address) VALUES (?,?)');
            $insert_row->bind_param('ss', $gym_name, $gym_address);
            $insert_row->execute();
            $insert_row->close();
            break;
        case "deleteGym":
            $gym_id = filter("gym_id");
            if (!empty($gym_id)) {
                $query = $conn->prepare('DELETE FROM Gyms WHERE id = ?');
                $query->bind_param('i', $gym_id);
                $query->execute();
                if ($conn->errno) {
                    die('Select Error (' . $conn->errno . ') ' . $conn->error);
                }
                $query->close();
            }
            break;
        case "editGym":
            $gym_id = filter("gym_id");
            $gym_name = filter("gym_name");
            $gym_address = filter("gym_address");
            $query = $conn->query("set names utf8");
            $query = $conn->prepare("UPDATE Gyms SET name = '$gym_name', address = '$gym_address' WHERE id = ?");
            $query->bind_param('i', $gym_id);
            $query->execute();
            if ($conn->errno) {
                die('Select Error (' . $conn->errno . ') ' . $conn->error);
            }
            $query->close();
            break;
        case "getMenu":
            $menu_id = filter("menu_id");

            $resultMenu = $conn->query("set names utf8");
            $sqlMenu = "SELECT id, (SELECT name FROM Program WHERE id=program_id) as program,date_start, day_of_the_week,(SELECT first_name FROM Users WHERE id=user_id) as author
            FROM Menu WHERE id = '$menu_id'";
            $resultMenu = $conn->query($sqlMenu);
            while ($rowMenu = $resultMenu->fetch_assoc()) {
                $menuid = $rowMenu['id'];
                $date = DateTime::createFromFormat('Y-m-d', $rowMenu['date_start']);
                $date_start = $date->format("d-m-y"); ?>
                <form class="form-horizontal" role="form" data-toggle="validator" id="form">
                    <fieldset>
                        <div class="form-group">
                            <label class="col-lg-4 control-label">Автор:</label>

                            <div class="col-lg-4 text-left">
                                <p class="get"><?php echo $rowMenu['author'] ?></p>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="inputDate" class="col-lg-4 control-label">Программа:</label>

                            <div class="col-lg-4 text-left">
                                <p class="get"><?php echo $rowMenu['program'] ?></p>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="inputTime" class="col-lg-4 control-label">Дата меню:</label>

                            <div class="col-lg-4">
                                <p class="get"><?php echo $date_start ?></p>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="inputPlan" class="col-lg-4 control-label">День недели:</label>

                            <div class="col-lg-4">
                                <p class="get"><?php
                                    $day = date('l', strtotime($rowMenu['date_start']));
                                    if ($day == "Monday") {
                                        $day = "Понедельник";
                                    } else if ($day == "Tuesday") {
                                        $day = "Вторник";
                                    } else if ($day == "Wednesday") {
                                        $day = "Среда";
                                    } else if ($day == "Thursday") {
                                        $day = "Четверг";
                                    } else if ($day == "Friday") {
                                        $day = "Пятница";
                                    } else if ($day == "Saturday") {
                                        $day = "Суббота";
                                    } else if ($day == "Sunday") {
                                        $day = "Воскресенье";
                                    }
                                    echo $day;
                                    ?></p>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-lg-10 col-md-offset-1">
                                <table class="table" style="width: 100%">
                                    <?php
                                    $resultType = $conn->query("set names utf8");
                                    $sqlType = "SELECT DISTINCT m.food_type_id,f.type_name
                                FROM Menu_Foods m JOIN Food_Type f ON f.id = m.food_type_id WHERE m.menu_id = '$menuid' ORDER by f.sort";
                                    $resultType = $conn->query($sqlType);
                                    while ($rowType = $resultType->fetch_assoc()) {
                                        $type_id = $rowType['food_type_id'];
                                        $type_name = $rowType['type_name'];
                                        ?>
                                        <tbody class="body_<?php echo $type_id ?>">
                                        <tr>
                                            <th><?php echo $type_name ?></th>
                                            <th>Выход</th>
                                            <th>Ккал</th>
                                            <th>Белок</th>
                                            <th>Жир</th>
                                            <th>Углеводы</th>
                                        </tr>
                                        <?php
                                        $resultFood = $conn->query("set names utf8");
                                        $sqlFood = "SELECT f.id, m.id,f.name, m.portion,TRUNCATE((f.kcal*m.portion/100),2) as calcKcal, TRUNCATE((f.protein*m.portion/100),2) as calcPro, TRUNCATE((f.fat*m.portion/100),2) as calcFat, TRUNCATE((f.carbohydrate*m.portion/100),2) as calcCarbo
                                FROM Menu_Foods m JOIN Foods f ON f.id = m.food_id
                                WHERE m.menu_id = '$menuid' and m.food_type_id = '$type_id'";
                                        $resultFood = $conn->query($sqlFood);

                                        while ($rowFood = $resultFood->fetch_assoc()) {
                                            $food_id = $rowFood['id']; ?>
                                            <tr class="type_<?php echo $type_id ?>">
                                                <td><?php echo $rowFood["name"]; ?></td>
                                                <td><?php echo $rowFood['portion'] ?></td>
                                                <td class="kcal"><?php echo $rowFood['calcKcal'] ?></td>
                                                <td class="protein"><?php echo $rowFood['calcPro'] ?></td>
                                                <td class="fat"><?php echo $rowFood['calcFat'] ?></td>
                                                <td class="carbo"><?php echo $rowFood['calcCarbo'] ?></td>
                                            </tr>
                                            <?php
                                        }
                                        ?>
                                        </tbody>
                                        <tr class="calcFood" style="background-color: #c8c8c8">
                                            <td width="25%"></td>
                                            <td>Калории <?php echo $type_name ?></td>
                                            <td class="sumFKcal_<?php echo $type_id ?> typeKcal"></td>
                                            <td class="sumFPro_<?php echo $type_id ?> typePro"></td>
                                            <td class="sumFFat_<?php echo $type_id ?> typeFat"></td>
                                            <td class="sumFCarbo_<?php echo $type_id ?> typeCarbo"></td>
                                        </tr>
                                    <?php }
                                    $resultSum = $conn->query("set names utf8");
                                    $sqlSum = "SELECT f.id, SUM(TRUNCATE((f.kcal*m.portion/100),2)) as sumKcal, SUM(TRUNCATE((f.protein*m.portion/100),2)) as sumPro,
                            SUM(TRUNCATE((f.fat*m.portion/100),2)) as sumFat, SUM(TRUNCATE((f.carbohydrate*m.portion/100),2)) as sumCarbo
                            FROM Foods f JOIN Menu_Foods m ON f.id = m.food_id
                            WHERE f.id in (SELECT food_id FROM Menu_Foods WHERE menu_id = '$menuid') GROUP by f.id";
                                    $resultSum = $conn->query($sqlSum);
                                    $rowSum = $resultSum->fetch_assoc()
                                    ?>
                                    <tr style="background-color: #1dc116">
                                        <th WIDTH="25%"></th>
                                        <th>Всего</th>
                                        <th class="sumKcal"><?php echo $rowSum['sumKcal'] ?></th>
                                        <th class="sumPro"><?php echo $rowSum['sumPro'] ?></th>
                                        <th class="sumFat"><?php echo $rowSum['sumFat'] ?></th>
                                        <th class="sumCarbo"><?php echo $rowSum['sumCarbo'] ?></th>
                                    </tr>

                                </table>
                            </div>
                        </div>

                        <div class="form-group text-center add">
                            <div class="col-lg-12">
                                <button type="button" class="btn btn-default" data-dismiss="modal">Закрыть</button>
                                <a class="btn btn-danger" onclick="
                                    if (confirm('Вы хотите удалить?')){
                                    actions('deleteMenu', <?php echo $rowMenu['id'] ?>)}"
                                   data-dismiss="modal">Удалить</a>
                                <a href="../actions/mpdf/menuToPDF.php?id=<?php echo $rowMenu['id'] ?>" target="_blank" class="btn btn-success">Экспортировать в PDF</a>
                            </div>
                        </div>
                    </fieldset>
                </form>
            <?php }
            break;
        case "editUserInfo":
            $user_id = filter("id");
            $first_name = filter("first_name");
            $last_name = filter("last_name");
            $phone = filter("phone");
            $email = filter("email");
            $db = filter("db");
            $user_status = filter("user_status");
            $query = $conn->query("set names utf8");
            $query = $conn->prepare("UPDATE Users SET first_name='$first_name', last_name='$last_name', email='$email', phone='$phone', dateOfBirthday='$db', user_status='$user_status' WHERE id = ?");
            $query->bind_param('i', $user_id);
            $query->execute();
            if ($conn->errno) {
                die('Select Error (' . $conn->errno . ') ' . $conn->error);
            }
            $query->close();
            break;
        case "editUserGym":
            $user_id = filter("id");
            $gym = filter("gym");
            $query = $conn->query("set names utf8");
            $query = $conn->prepare("UPDATE Users SET id_gym = '$gym' WHERE id = ?");
            $query->bind_param('i', $user_id);
            $query->execute();
            if ($conn->errno) {
                die('Select Error (' . $conn->errno . ') ' . $conn->error);
            }
            $query->close();
            break;
        case "editUserAddress":
            $user_id = filter("id");
            $address = filter("custom");
            $address1 = filter("custom1");
            $address2 = filter("custom2");
            $check = filter("check");
            $gym = filter("gym");

            $query = $conn->query("set names utf8");
            $query = $conn->prepare("UPDATE Users SET custom_address = '$address', address_1 = '$address1', address_2 = '$address2', address_boolean = '$check', id_gym = '$gym' WHERE id = ?");
            $query->bind_param('i', $user_id);
            $query->execute();
            if ($conn->errno) {
                die('Select Error (' . $conn->errno . ') ' . $conn->error);
            }
            $query->close();
            break;
        case "addUserBalance":
            $client_id = filter("id");
            $sum = filter("admin_sum");
            $date_payment = filter("admin_date");
            if (empty($date_payment)) {
                $date_payment = date("Y-m-d");
            }
            $result = $conn->query("set names utf8");
            $result = $conn->prepare('INSERT INTO HistoryOfPayment (user_id,lastPayment,dateOfPayment,paymentMethod,transaction,comment) VALUES (?,?,?,1,NULL,NULL)');
            $result->bind_param('iis', $client_id, $sum,$date_payment);
            $result->execute();
            $result->close();
            break;
        case "deleteClient":
            $client_id = filter("client_id");
            if (!empty($client_id)) {
                $query = $conn->prepare('DELETE FROM Users WHERE id = ?');
                $query->bind_param('i', $client_id);
                $query->execute();
                if ($query) {
                    $result = $conn->prepare('DELETE FROM HistoryOfPayment WHERE user_id = ?');
                    $result->bind_param('i', $client_id);
                    $result->execute();
                }
                $query->close();
            }
            break;
        case "addUserInfo":
            $first_name = filter("first_name");
            $last_name = filter("last_name");
            $phone = filter("phone");
            $email = filter("email");
            $db = filter("db");
            if($status == 1) {
            $id_gym = 0;
            } else {
            $id_gym = filter("id_gym");
            }
            $user_status = filter("user_status");
            $p = md5(md5("12345" . md5(sha1("12345"))));
            $qCheck = $conn->query("set names utf8");
            $qCheck = $conn->query("SELECT phone FROM Users WHERE phone = '$phone'");
            if ($qCheck->num_rows > 0) {
                echo "0";

            } else {
                $insert_row = $conn->query("set names utf8");
                $insert_row = $conn->prepare('INSERT INTO Users (first_name,last_name,phone,email,dateOfBirthday,password,id_gym,user_status) VALUES (?,?,?,?,?,?,?,?)');
                $insert_row->bind_param('ssssssii', $first_name, $last_name, $phone, $email, $db, $p, $id_gym, $user_status);
                $insert_row->execute();
                $user_id = $insert_row->insert_id;
                if ($insert_row) {
                    echo $user_id;
                }
                $insert_row->close();
            }
            break;
        case "editUserPassword":
            $user_id = filter("id");
            $pass1 = filter("pass1");
            $pass2 = filter("pass2");
            if($pass1 != $pass2) {
            echo 0;
            } else {
            $password = md5(md5($pass2 . md5(sha1($pass2))));
            $query = $conn->query("set names utf8");
            $query = $conn->prepare("UPDATE Users SET password = '$password' WHERE id = ?");
            $query->bind_param('i', $user_id);
            $query->execute();
                if($query) {
                    echo 1;
                }
            }
        break;
        case "getDescriptions":
            $description = filter ("program_id");
            if (!empty($description))
            {
                $result = $conn->query("set names utf8");
                $query = "SELECT  photo,description, name FROM Program WHERE id = '$description'";
                $result = $conn->query($query);
                while ($row = $result->fetch_assoc()) { ?>
                <div class="form-group" style="margin-top: -20px;">
                       <h3><?php echo $row["name"]?> </h3>

                        <div class="col-lg-8 " style = "margin-left: 60px;">
                            <img src="<?php echo $row["photo"] ?>" width="300px"; height="200px"  >
                        </div>

                    <br>
                    <div class="form-group">

                        <div class="col-lg-8 " style = "margin-left: 60px; margin-top:60px;">
                          <textarea rows="10" cols="40" name="text" style="color:black; resize: none;" disabled><?php echo $row["description"] ?></textarea>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-lg-8 " style = "margin-left: 60px;">
                          <div style="text-align: center;"> <button type="submit" class="btn btn-warning sendzakaz" style = "">Заказать</button></div>
                       </div>
                     </div>
                    <?php
                }

                $result->close();

            }
            break;
        case "getPrice":
            $description = filter ("program_id");
            $value = filter("value");
            if (!empty($description) && $value == 0)
            {
                $result = $conn->query("set names utf8");
                $query = "SELECT  photo,description, Price, name FROM Program WHERE id = '$description' and type = '$value'";
                $result = $conn->query($query);
                while ($row = $result->fetch_assoc()) {
                    echo $row["Price"];

                }
            }
            if(!empty($description) && $value == 1)
                {
                     $result = $conn->query("set names utf8");
                $query = "SELECT  photo,description, name FROM Program WHERE id = '$description' and type = $value";
                $result = $conn->query($query);
                while ($row = $result->fetch_assoc()) { ?>
                                     <?php
                }
                $result->close();
                }
            break;
        case "getDeliveryDate":
            $filter_date = filter("val");
            $id_gym = filter("id");
            $s_filter = filter("s_filter");
            $date = DateTime::createFromFormat('d-m-Y', $filter_date);
            $date_request = $date->format("Y-m-d");
            $result = $conn->query("set names utf8");

            if($user_status == 2){
                
                $query = "SELECT c.id, u.custom_address,(SELECT id FROM Gyms WHERE id = u.id_gym) as 'id_gym',(SELECT address FROM Gyms WHERE id = u.id_gym) as 'gym',
            u.first_name, u.last_name, u.phone, (SELECT (SELECT name FROM Program WHERE id = program_id) as 'name' FROM Product WHERE id = (SELECT product_id FROM Plans WHERE id = c.plan_id)) as 'plan',
            (SELECT quantity FROM Delivery WHERE calendar_id = c.id) as 'quantity', (SELECT admin_comment FROM Delivery WHERE calendar_id = c.id) as 'comment',
            (SELECT date_time FROM Delivery WHERE calendar_id = c.id) as 'time', (SELECT status FROM Delivery WHERE calendar_id = c.id) as 'status',
            (SELECT fact_time FROM Delivery WHERE calendar_id = c.id) as 'fact_time', (SELECT first_name FROM Users WHERE id in (SELECT courier FROM Delivery WHERE calendar_id = c.id)) as 'courier_name', (SELECT last_name FROM Users WHERE id in (SELECT courier FROM Delivery WHERE calendar_id = c.id)) as 'courier_lname'
            FROM Calendars c JOIN Users u ON u.id = (SELECT user_id FROM Plans WHERE id = c.plan_id) WHERE c.date = '$date_request' AND id_gym = '$id_gym'";
            }
            else {
                $query = "SELECT c.id, u.custom_address,(SELECT id FROM Gyms WHERE id = u.id_gym) as 'id_gym',(SELECT address FROM Gyms WHERE id = u.id_gym) as 'gym',
            u.first_name, u.last_name, u.phone, (SELECT (SELECT name FROM Program WHERE id = program_id) as 'name' FROM Product WHERE id = (SELECT product_id FROM Plans WHERE id = c.plan_id)) as 'plan',
            (SELECT quantity FROM Delivery WHERE calendar_id = c.id) as 'quantity', (SELECT admin_comment FROM Delivery WHERE calendar_id = c.id) as 'comment',
            (SELECT date_time FROM Delivery WHERE calendar_id = c.id) as 'time', (SELECT status FROM Delivery WHERE calendar_id = c.id) as 'status',
            (SELECT fact_time FROM Delivery WHERE calendar_id = c.id) as 'fact_time', (SELECT first_name FROM Users WHERE id in (SELECT courier FROM Delivery WHERE calendar_id = c.id)) as 'courier_name', (SELECT last_name FROM Users WHERE id in (SELECT courier FROM Delivery WHERE calendar_id = c.id)) as 'courier_lname'
            FROM Calendars c JOIN Users u ON u.id = (SELECT user_id FROM Plans WHERE id = c.plan_id) WHERE c.date = '$date_request' ORDER BY time ASC";
            }
            $result = $conn->query($query);
            while ($row = $result->fetch_assoc()) {
                $custom = $row['custom_address'];
                if($row['status'] == 0) {
                    $css = 'style = "color: red"';
                } elseif ($row['status'] == 1) {
                    $css = 'style = "color: green"';
                }
                ?>
                <tr data-toggle="modal" data-target="#myModal" style="cursor: pointer"
                    onclick="getDelivery('getDelivery',<?php echo $row['id'] ?>)">
                    <td><?php echo $row['id'] ?></td>
                    <td><?php if($custom!=""){echo "Cвой адрес<br>";} echo $row['custom_address']; if($row['custom_address']=="") echo "Спортзал<br>".$row['gym'] ?></td>
                    <td><?php echo $row['first_name']." ".$row['last_name']."<br>".$row['phone'] ?></td>
                    <td><?php echo $row['plan'] ?></td>
                    <td style="text-align: center"><?php echo $row['quantity']; if(!$row['quantity']) echo 1 ?></td>
                    <td><?php echo $row['comment'] ?></td>
                    <td><?php echo $row['courier_name'].' '.$row['courier_lname'] ?></td>
                    <td><?php echo $row['time'] ?></td>
                    <td <?php echo $css ?>><?php if($row['status'] == 0) {echo 'Не доставлено';} else {echo 'Доставлено';}  ?></td>
                    <td><?php echo $row['fact_time'] ?></td>
                </tr>
                <?php
            }
            $result->close();
            break;
        case "getDelivery":
            $c_id = filter("val");
            $result = $conn->query($query);
            if (!empty($c_id)) {
                $result = $conn->query("set names utf8");
                $query = "SELECT c.id, c.date, u.custom_address,u.address_1,u.address_2, (SELECT name FROM Gyms WHERE id = u.id_gym) as 'gym_name',(SELECT address FROM Gyms WHERE id = u.id_gym) as 'gym',
u.id as 'user_id',u.first_name, u.last_name, u.phone, u.id_gym, (SELECT (SELECT name FROM Program WHERE id = program_id) as 'name' FROM Product WHERE id = (SELECT product_id FROM Plans WHERE id = c.plan_id)) as 'plan',
(SELECT quantity FROM Delivery WHERE calendar_id = c.id) as 'quantity', (SELECT comment FROM Delivery WHERE calendar_id = c.id) as 'comment',
(SELECT partner_comment FROM Delivery WHERE calendar_id = c.id) as 'pcomment',(SELECT admin_comment FROM Delivery WHERE calendar_id = c.id) as 'acomment',
(SELECT date_time FROM Delivery WHERE calendar_id = c.id) as 'time', (SELECT status FROM Delivery WHERE calendar_id = c.id) as 'status',
(SELECT courier FROM Delivery WHERE calendar_id = c.id) as 'courier', (SELECT fact_time FROM Delivery WHERE calendar_id = c.id) as 'fact_time'
FROM Calendars c JOIN Users u ON u.id = (SELECT user_id FROM Plans WHERE id = c.plan_id) WHERE c.id = '$c_id'";
                $result = $conn->query($query);
                while ($row = $result->fetch_assoc()) {
                    $address = $row["custom_address"];
                    if($row["custom_address"] == ""){
                        $address = $row["gym"];
                    }
                    $date = DateTime::createFromFormat('Y-m-d', $row["date"]);
                    $date_request = $date->format("d-m-Y");
                    ?>
                <form class="form-horizontal" data-toggle="validator" id="form">
                <fieldset>

                    <input type="hidden" id="status" value="<?php echo $status ?>">
                    <div class="form-group">
                        <label for="inputClient" class="col-lg-4 control-label">Клиент:</label>
                        <div class="col-lg-4">
                            <a href="../profile.php?id=<?php echo $row['user_id'] ?>"><p class="get"><?php echo $row['first_name']." ".$row['last_name'] ?></p></a>
                            <input type="hidden" id="user_id" value="<?php echo $row['user_id'] ?>">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="inputPhone" class="col-lg-4 control-label">Телефон:</label>
                        <div class="col-lg-4 text-left">
                            <?php echo "<p class='get'>" . $row['phone'] . "</p>";?>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="inputPlan" class="col-lg-4 control-label">План питания:</label>
                        <div class="col-lg-4">
                            <?php echo "<p class='get'>" . $row['plan'] . "</p>";?>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="inputTime" class="col-lg-4 control-label">Кол-во:</label>
                        <div class="col-lg-4">
                            <input class="form-control quantity" style="margin-top: 0" id="quantity" placeholder="Количество" type="text" value="<?php if($row['quantity'] != '0'){echo $row['quantity'];} else{echo '1';} if(!isset($row['quantity'])){echo '1';} ?>">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="inputPlace" class="col-lg-4 control-label">Место доставки:</label>
                        <div class="col-lg-4">
                            <?php if($status == 1){?>
                                <select class="form-control" style="margin-top: 0" id="place" onchange="toggleAddress('getAddress',this.value)">
                                    <option value="">--Свой адрес--</option>
                                    <?php
                                    $queryGym = "SELECT * FROM Gyms";
                                    $resultGym = $conn->query($queryGym);
                                    while ($rowGym = $resultGym->fetch_assoc()) { ?>
                                        <option value="<?php echo $rowGym["id"]; ?>"<?php if($rowGym["id"] == $row['id_gym']) echo 'selected' ?>><?php echo $rowGym["name"]; ?></option>
                                    <?php } ?>
                                </select>
                            <?php }else{ ?>
                                <?php echo "<p class='get'>" . $row["gym_name"]. "</p>";?>
                            <?php } ?>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="inputAddress" class="col-lg-4 control-label">Адрес доставки:</label>
                        <div class="col-lg-4 addr">
                            <?php if($status == 1) {
                                if (empty($row['address_1']) && empty($row['address_2'])) { ?>
                                    <input class="form-control address" style="margin-top: 0" id="address" placeholder="Адрес доставки" type="text" value="<?php echo $row['gym'];if ($row['id_gym'] == 0) echo $row['custom_address'] ?>">
                                <?php } else {
                                    ?>
                                    <select class="form-control" style="margin-top: 0" id="address_val">
                                        <option value="">--Адресы--</option>
                                        <option value="1"><?php echo $row["custom_address"] ?></option>
                                        <?php if(!empty($row["address_1"])){ ?><option value="2"><?php echo $row["address_1"] ?></option><?php } ?>
                                        <?php if(!empty($row["address_2"])){ ?><option value="3"><?php echo $row["address_2"] ?></option><?php } ?>
                                    </select>
                                <?php }
                            }
                            else{ ?>
                                <?php echo "<p class='get'>" . $row["gym"]. "</p>";if($row['id_gym'] == 0) {echo "<p class='get'>" . $row["custom_address"]. "</p>";}?>
                            <?php } ?>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="inputTime" class="col-lg-4 control-label">Курьер:</label>
                        <div class="col-lg-4">
                            <?php if($status == 1){?>
                                <select class="form-control" id="courier" style="margin-top: 0">
                                    <option value="">--Курьер--</option>
                                    <?php
                                    $queryCourier = "SELECT * FROM Users WHERE user_status=3";
                                    $resultCourier = $conn->query($queryCourier);
                                    while ($rowCourier = $resultCourier->fetch_assoc()) { ?>
                                        <option value="<?php echo $rowCourier["id"]; ?>"<?php if($rowCourier["id"] == $row['courier']) echo 'selected' ?>><?php echo $rowCourier["first_name"]." ".$rowCourier["last_name"]; ?></option>
                                    <?php } ?>
                                </select>
                            <?php }else{ ?>
                                <?php echo "<p class='get'>" . $rowCourier["first_name"]." ".$rowCourier["last_name"] . "</p>";?>
                            <?php } ?>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="inputTime" class="col-lg-4 control-label">Время план:</label>
                        <?php if($status == 1){
                            $e = explode(" - ", $row['time']); ?>
                            <div class="col-lg-3">
                                <input class="form-control time" style="margin-top: 0" id="time1" placeholder="Время" type="text" value="<?php echo $e[0] ?>">
                            </div>

                            <div class="col-lg-3">
                                <input class="form-control time" style="margin-top: 0" id="time2" placeholder="Время" type="text" value="<?php echo $e[1] ?>">
                            </div>
                        <?php } else {?>
                            <div class="col-lg-4">
                                <?php echo "<p id='plan_time' class='get'>" . $row['time'] . "</p>";?>

                            </div>
                        <?php } ?>

                    </div>
                    <div class="form-group">
                        <label for="inputDate" class="col-lg-4 control-label">Дата доставки:</label>
                        <div class="col-lg-4">
                            <?php
                            echo "<p class='get'>" . $date_request . "</p>";?>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="inputTime" class="col-lg-4 control-label">Номер наряда:</label>
                        <div class="col-lg-4">
                            <?php echo "<p id='calendar' class='get'>" . $c_id . "</p>";?>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="inputStatus" class="col-lg-4 control-label">Статус доставки:</label>
                        <div class="col-lg-4">
                            <select class="form-control" style="margin-top: 0" id="statusDelivery">
                                <option value="">--Статус наряда--</option>
                                <option value="1"<?php if($row['status'] == 1) echo 'selected' ?>>Доставлено</option>
                                <option value="0"<?php if($row['status'] == 0) echo 'selected' ?>>Не доставлено</option>
                            </select>
                        </div>
                    </div>
                    <?php if($status == 1) {?>
                        <p style="font-size: 17px"><b>Отметки администратора Dostyk Catering</b></p>

                        <div class="form-group">
                            <label for="inputTime" class="col-lg-4 control-label">Время факт:</label>

                            <div class="col-lg-4">
                                <?php if($status == 1){?>
                                    <input class="form-control time" style="margin-top: 0" id="time3" placeholder="Время факт" type="text" value="<?php echo $row['fact_time'] ?>">
                                <?php }else{ ?>
                                    <?php echo "<p class='get'>" . $row['fact_time'] . "</p>";?>
                                <?php } ?>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="inputComment" class="col-lg-4 control-label">Комментарий:</label>
                            <div class="col-lg-4">
                                <textarea class="form-control acomment" style="margin-top: 0" id="acomment"><?php echo $row['acomment'] ?></textarea>
                            </div>
                        </div>
                    <?php } ?>
                    <p style="font-size: 17px"><b>Отметки администратора Партнера</b></p>

                    <div class="form-group">
                        <label for="inputComment" class="col-lg-4 control-label">Комментарий:</label>
                        <div class="col-lg-4">
                            <?php if($status == 2){?>
                                <textarea class="form-control pcomment" style="margin-top: 0" id="pcomment"><?php echo $row["pcomment"]; ?></textarea>
                            <?php }else{ ?>
                                <?php echo "<p class='get'>" . $row["pcomment"]. "</p>";?>
                            <?php } ?>
                        </div>
                    </div>

                    <div class="form-group text-center add">
                        <div class="col-lg-12">
                            <button type="submit" class="btn btn-success submit" onclick="actions('editDelivery',<?php echo $row['id'] ?>)">Сохранить</button>
                            <button type="button" class="btn btn-default" data-dismiss="modal">Закрыть</button>
                        </div>
                    </div>
                    <script type="text/javascript" src="../js/jquery-ui-timepicker-addon.js"></script>
                    <script type="text/javascript" src="../js/jquery-ui-timepicker-addon-i18n.min.js"></script>
                    <script> $(".time").timepicker($.timepicker.regional['ru']);</script>
                </fieldset>
            </form>
                    <?php }
                $result->close();
            }
            break;
        case "editDelivery":
            $calendar = filter("calendar");
            $user_id = filter("user_id");
            $time = filter("date_time");
            $fact_time = filter("fact_time");
            $quantity = filter("quantity");
            if(empty($quantity)) {
                $quantity = 1;
            }
            $comment = filter("comment");
            $pcomment = filter("pcomment");
            $acomment = filter("acomment");
            $status_name = filter("status_name");
            $place = filter("place");
            $address = filter("address");
            $courier = filter("courier");
            $address_val = filter("address_val");
            $sql = "SELECT calendar_id FROM Delivery WHERE calendar_id = '$calendar'";
            $sql_query = $conn->query($sql);
            if ($sql_query->num_rows == 0) {
                $insert_row = $conn->query("set names utf8");
                if($status == 1){
                    $insert_row = $conn->prepare('INSERT INTO Delivery (calendar_id, user_id, date_time, fact_time, quantity, comment, admin_comment, status, courier, address_val) VALUES (?,?,?,?,?,?,?,?,?,?)');
                    $insert_row->bind_param('iississiii', $calendar, $user_id, $time, $fact_time, $quantity, $comment, $acomment, $status_name, $courier, $address_val);

                } else {
                    $insert_row = $conn->prepare('INSERT INTO Delivery (calendar_id, user_id, quantity, partner_comment, status) VALUES (?,?,?,?,?)');
                    $insert_row->bind_param('iiisi', $calendar, $user_id, $quantity, $pcomment, $status_name);
                }
                $insert_row->execute();
            } else {
                $result = $conn->query("set names utf8");
                if($status == 1){
                    $result = $conn->prepare("UPDATE Delivery SET date_time ='$time',fact_time='$fact_time',quantity = '$quantity',comment = '$comment',admin_comment = '$acomment',status = '$status_name',courier = '$courier',address_val = '$address_val' WHERE calendar_id = ?");
                } else{
                    $result = $conn->prepare("UPDATE Delivery SET quantity = '$quantity',partner_comment = '$pcomment',status = '$status_name' WHERE calendar_id = ?");
                }
                $result->bind_param('i', $calendar);
                $result->execute();
            }
            if($status == 1){
                if($place == "" && $address_val == "") {
                    if($address != "") {
                        $result = $conn->query("set names utf8");
                        $result = $conn->prepare("UPDATE Users SET custom_address='$address',address_boolean=0, id_gym='$place' WHERE id = ?");
                        $result->bind_param('i', $user_id);
                        $result->execute();
                    }
                }
                elseif($place != "" && $address_val == "") {
                    $result = $conn->query("set names utf8");
                    $result = $conn->prepare("UPDATE Users SET custom_address='',address_1='',address_2='',address_boolean=1, id_gym='$place' WHERE id = ?");
                    $result->bind_param('i', $user_id);
                    $result->execute();
                }
            }

            $sql_query->close();
            break;

        case "editCalendarDelivery":
            $calendar = filter("calendar");
            $user_id = filter("user_id");
            $status_name = filter("status_name");
            $status_news = "Ваш статус по заявкам был изменена";
            $date_today = date("m.d.y");
            $quantity = 1;
            $sql = "SELECT calendar_id FROM Delivery WHERE calendar_id = '$calendar'";
            $sql_query = $conn->query($sql);
            if ($sql_query->num_rows == 0) {
                $insert_row = $conn->query("set names utf8");
                $insert_row = $conn->prepare('INSERT INTO Delivery (calendar_id, user_id, quantity, status) VALUES (?,?,?,?)');
                $insert_row->bind_param('iiii', $calendar, $user_id, $quantity, $status_name);
                $insert_row->execute();

            } else {
                $result = $conn->query("set names utf8");
                $result = $conn->prepare("UPDATE Delivery SET status = '$status_name' WHERE calendar_id = ?");
                $result->bind_param('i', $calendar);
                $result->execute();

            }

                //Добавлят новости в таблицу news Gani
                $insert_row1 = $conn->query("set names utf8");
                $insert_row1 = $conn->prepare('INSERT INTO News (user_id, news, plan_id, date_now) VALUES (?,?,1,NOW())');
                $insert_row1->bind_param('is',  $user_id, $status_news);
                $insert_row1->execute();
            echo $calendar;
            break;
        case "getDeliveryStatus":
            $status = filter("val");
            $id_gym = filter("id");
            $queryCourier = "SELECT first_name, last_name FROM Users WHERE id in (SELECT courier FROM Delivery)";
            $resultCourier = $conn->query($queryCourier);
            $rowCourier = $resultCourier->fetch_assoc();
            $result = $conn->query("set names utf8");
            if ($status != "") {
                if($user_status == 2){
                    $query = "SELECT c.id, u.custom_address,(SELECT id FROM Gyms WHERE id = u.id_gym) as 'id_gym',(SELECT address FROM Gyms WHERE id = u.id_gym) as 'gym',
            u.first_name, u.last_name, u.phone, (SELECT (SELECT name FROM Program WHERE id = program_id) as 'name' FROM Product WHERE id = (SELECT product_id FROM Plans WHERE id = c.plan_id)) as 'plan',
            (SELECT quantity FROM Delivery WHERE calendar_id = c.id) as 'quantity', (SELECT admin_comment FROM Delivery WHERE calendar_id = c.id) as 'comment',
            (SELECT date_time FROM Delivery WHERE calendar_id = c.id) as 'time', (SELECT status FROM Delivery WHERE calendar_id = c.id) as 'status',
            (SELECT fact_time FROM Delivery WHERE calendar_id = c.id) as 'fact_time'
            FROM Calendars c JOIN Users u ON u.id = (SELECT user_id FROM Plans WHERE id = c.plan_id) WHERE (SELECT status FROM Delivery WHERE calendar_id = c.id) = '$status' AND id_gym = '$id_gym'";
                } else {
                    $query = "SELECT c.id, u.custom_address,(SELECT id FROM Gyms WHERE id = u.id_gym) as 'id_gym',(SELECT address FROM Gyms WHERE id = u.id_gym) as 'gym',
            u.first_name, u.last_name, u.phone, (SELECT (SELECT name FROM Program WHERE id = program_id) as 'name' FROM Product WHERE id = (SELECT product_id FROM Plans WHERE id = c.plan_id)) as 'plan',
            (SELECT quantity FROM Delivery WHERE calendar_id = c.id) as 'quantity', (SELECT admin_comment FROM Delivery WHERE calendar_id = c.id) as 'comment',
            (SELECT date_time FROM Delivery WHERE calendar_id = c.id) as 'time', (SELECT status FROM Delivery WHERE calendar_id = c.id) as 'status',
            (SELECT fact_time FROM Delivery WHERE calendar_id = c.id) as 'fact_time'
            FROM Calendars c JOIN Users u ON u.id = (SELECT user_id FROM Plans WHERE id = c.plan_id) WHERE (SELECT status FROM Delivery WHERE calendar_id = c.id) = '$status'";
                }

            } else {
                $query = "SELECT c.id, u.custom_address, (SELECT address FROM Gyms WHERE id = u.id_gym) as 'gym',
                u.first_name, u.last_name, u.phone, (SELECT name FROM Product WHERE id = (SELECT product_id FROM Plans WHERE id = c.plan_id)) as 'plan',
                (SELECT quantity FROM Delivery WHERE calendar_id = c.id) as 'quantity', (SELECT admin_comment FROM Delivery WHERE calendar_id = c.id) as 'comment',
                (SELECT date_time FROM Delivery WHERE calendar_id = c.id) as 'time'
                FROM Calendars c JOIN Users u ON u.id = (SELECT user_id FROM Plans WHERE id = c.plan_id)";
            }
            $result = $conn->query($query);
            while ($row = $result->fetch_assoc()) {
                if($row['status'] == 0) {
                    $css = 'style = "color: red"';
                } elseif ($row['status'] == 1) {
                    $css = 'style = "color: green"';
                }
                ?>
                <tr data-toggle="modal" data-target="#myModal" style="cursor: pointer"
                    onclick="getDelivery('getDelivery',<?php echo $row['id'] ?>)">
                    <td><?php echo $row['id'] ?></td>
                    <td><?php echo $row['custom_address']; if($row['custom_address']=="") echo $row['gym'] ?></td>
                    <td><?php echo $row['first_name']." ".$row['last_name']."<br>".$row['phone'] ?></td>
                    <td><?php echo $row['plan'] ?></td>
                    <td style="text-align: center"><?php echo $row['quantity']; if(!$row['quantity']) echo 1 ?></td>
                    <td><?php echo $row['comment'] ?></td>
                    <td><?php echo $rowCourier['first_name'].' '.$rowCourier['last_name'] ?></td>
                    <td><?php echo $row['time'] ?></td>
                    <td <?php echo $css ?>><?php if($row['status'] == 0) {echo 'Не доставлено';} else {echo 'Доставлено';}  ?></td>
                    <td><?php echo $row['fact_time'] ?></td>
                </tr>
                <?php
            }
            $result->close();
            break;
        case "deletePrice":
            $price_id = filter("price_id");
            if (!empty($price_id)) {
                $query = $conn->prepare('DELETE FROM Product WHERE id = ?');
                $query->bind_param('i', $price_id);
                $query->execute();

                $query->close();
            }
            break;
        case "editPrice":
            $price_id = filter("price_id");
            $program = filter("program");
            $photo = filter("photo");
            $product_name = filter("product_name");
            $type = filter("price_type");
            $kcal = filter("kcal");
            $price = filter("price");
            $amount = filter("amount");
            $description = filter("description");
            $freezing = filter("freezing");
            $commission = filter("commission");
            $query = $conn->query("set names utf8");
            $query = $conn->prepare("UPDATE Program SET name='$product_name',kcal='$kcal',description='$description',photo='$photo' WHERE id = ?");
            $query->bind_param('i', $program);
            $query->execute();
            if($query) {
                $q = $conn->prepare("UPDATE Product SET price='$price',amount_days='$amount',freezing='$freezing',commission='$commission',type='$type' WHERE id = ?");
                $q->bind_param('i', $price_id);
                $q->execute();
            }
            $query->close();
            break;
        case "addPrice":
            $program = filter("program");
            $type = filter("price_type");
            $price = filter("price");
            $amount = filter("amount");
            $freezing = filter("freezing");
            $commission = filter("commission");

            $query = $conn->query("set names utf8");
            $query = $conn->prepare("INSERT INTO Product (program_id, price, amount_days, freezing, commission, type) VALUES(?,?,?,?,?,?)");
            $query->bind_param('iiiiii', $program, $price, $amount, $freezing, $commission, $type);
            $query->execute();
            $query->close();
            break;
        case "getProduct":
        $val = filter("value");
        $result = $conn->query("set names utf8");
        $query = "SELECT p.id, pr.kcal, p.type, p.amount_days, pr.name, p.price FROM Program pr JOIN Product p ON p.program_id = pr.id WHERE p.type = '$val' ORDER by p.id";
        $result = $conn->query($query);
        while ($row = $result->fetch_assoc()) {
            ?>
            <option value="<?php echo $row["id"]; ?>"><?php echo $row["name"]." ".$row["kcal"]." - ".$row["amount_days"]." дней - ".$row["price"]."тг"; ?></option>
            <?php
        }
        $result->close();
        break;
        case "getPriceType":
            $type = filter("val");
            $program = filter("program");
            $get_product = filter("get_product");
            $result = $conn->query("set names utf8");
            if ($type != "") {
                if($program != ""){
                    $query = "SELECT id,(SELECT id FROM Program WHERE id=program_id) as 'program',(SELECT photo FROM Program WHERE id=program_id) as 'photo',(SELECT name FROM Program WHERE id=program_id) as 'name',(SELECT kcal FROM Program WHERE id=program_id) as 'kcal',price,amount_days,(SELECT description FROM Program WHERE id=program_id) as 'description',freezing,commission,type FROM Product WHERE type='$type' AND program_id='$program'";
                } else {
                    $query = "SELECT id,(SELECT id FROM Program WHERE id=program_id) as 'program',(SELECT photo FROM Program WHERE id=program_id) as 'photo',(SELECT name FROM Program WHERE id=program_id) as 'name',(SELECT kcal FROM Program WHERE id=program_id) as 'kcal',price,amount_days,(SELECT description FROM Program WHERE id=program_id) as 'description',freezing,commission,type FROM Product WHERE type='$type'";
                }
            } else {
                $query = "SELECT id,(SELECT id FROM Program WHERE id=program_id) as 'program',(SELECT photo FROM Program WHERE id=program_id) as 'photo',(SELECT name FROM Program WHERE id=program_id) as 'name',(SELECT kcal FROM Program WHERE id=program_id) as 'kcal',price,amount_days,(SELECT description FROM Program WHERE id=program_id) as 'description',freezing,commission,type FROM Product";
            }
            $result = $conn->query($query);
            while ($row = $result->fetch_assoc()) {?>
                <tr>
                    <td><?php echo $row['id'] ?></td>
                    <td><?php echo $row['name'] ?></td>
                    <td><?php echo $row['kcal'] ?></td>
                    <td><?php echo $row['price'] ?></td>
                    <td><?php echo $row['amount_days'] ?></td>
                    <td><?php echo $row['freezing'] ?></td>
                    <td><img src="<?php echo $row['photo'] ?>" width="75px" height="75px">
                    </td>
                    <td><?php echo $row['description'] ?></td>
                    <td><?php echo $row['commission'] ?></td>
                    <td><?php if($row['type'] == 1) {echo 'По адресу';} else if($row['type'] == 2) {echo 'В спортзал';} else {echo 'Особые условия';}  ?></td>
                    <?php if($status == 1) { ?>
                    <td>
                        <a style="margin-right: 15px" href="editPrice.php?id=<?php echo $row['id'] ?>"><i class="glyphicon glyphicon-pencil"></i></a>
                        <a href="" onclick="actions('deletePrice', <?php echo $row['id'] ?>)"><i class="glyphicon glyphicon-trash"></i></a>
                    </td>
                    <?php } ?>
                </tr>
                <?php
            }
            $result->close();
            break;
        case "getOrderUserName":
        $val = filter("val");
        $result = $conn->query("set names utf8");
        $sql = "SELECT * FROM Users WHERE first_name like '$val%' OR last_name like '$val%' ORDER BY first_name LIMIT 0,6";
        $result = $conn->query($sql);
        echo '<ul id="user_list">';
            while($row = $result->fetch_assoc()) {
                if(!empty($result)) {?>
                    <li onclick="getName('<?php echo $row["first_name"].' '.$row["last_name"]; ?>', '<?php echo $row["phone"]; ?>');"><?php echo $row["first_name"]." ".$row["last_name"]; ?></li>
                <?php }} if($result->num_rows == 0) {?>
                    <li>Не найдено. <a href="addClient.php?from=request">Создать клиента<a/></li>
                    <?php }
        echo '</ul>';
        break;
        case "getPriceTypeProduct":
            $program = filter("val");
            $type = filter("price_type");
            $result = $conn->query("set names utf8");
            if ($program != "") {
                if($type != ""){
                    $query = "SELECT id,(SELECT id FROM Program WHERE id=program_id) as 'program',(SELECT photo FROM Program WHERE id=program_id) as 'photo',(SELECT name FROM Program WHERE id=program_id) as 'name',(SELECT kcal FROM Program WHERE id=program_id) as 'kcal',price,amount_days,(SELECT description FROM Program WHERE id=program_id) as 'description',freezing,commission,type FROM Product WHERE program_id=' $program' AND type='$type'";
                } else {
                    $query = "SELECT id,(SELECT id FROM Program WHERE id=program_id) as 'program',(SELECT photo FROM Program WHERE id=program_id) as 'photo',(SELECT name FROM Program WHERE id=program_id) as 'name',(SELECT kcal FROM Program WHERE id=program_id) as 'kcal',price,amount_days,(SELECT description FROM Program WHERE id=program_id) as 'description',freezing,commission,type FROM Product WHERE program_id=' $program'";
                }
            } else {
                $query = "SELECT id,(SELECT id FROM Program WHERE id=program_id) as 'program',(SELECT photo FROM Program WHERE id=program_id) as 'photo',(SELECT name FROM Program WHERE id=program_id) as 'name',(SELECT kcal FROM Program WHERE id=program_id) as 'kcal',price,amount_days,(SELECT description FROM Program WHERE id=program_id) as 'description',freezing,commission,type FROM Product";
            }
            $result = $conn->query($query);
            while ($row = $result->fetch_assoc()) {?>
                <tr>
                    <td><?php echo $row['id'] ?></td>
                    <td><?php echo $row['name'] ?></td>
                    <td><?php echo $row['kcal'] ?></td>
                    <td><?php echo $row['price'] ?></td>
                    <td><?php echo $row['amount_days'] ?></td>
                    <td><?php echo $row['freezing'] ?></td>
                    <td><img src="<?php echo $row['photo'] ?>" width="75px" height="75px">
                    </td>
                    <td><?php echo $row['description'] ?></td>
                    <td><?php echo $row['commission'] ?></td>
                    <td><?php if($row['type'] == 1) {echo 'По адресу';} else if($row['type'] == 2) {echo 'В спортзал';} else {echo 'Особые условия';}  ?></td>
                    <?php if($status == 1) { ?>
                    <td>
                        <a style="margin-right: 15px" href="editPrice.php?id=<?php echo $row['id'] ?>"><i class="glyphicon glyphicon-pencil"></i></a>
                        <a href="" onclick="actions('deletePrice', <?php echo $row['id'] ?>)"><i class="glyphicon glyphicon-trash"></i></a>
                    </td>
                    <?php } ?>
                </tr>
                <?php
            }
            $result->close();
            break;
        case "getDeliverySalesDate":
            $filter_date = filter("val");
            $id_gym = filter("id");
            $date = DateTime::createFromFormat('d-m-Y', $filter_date);
            $date_request = $date->format("Y-m-d");
            $gym = filter("gym");
            $result = $conn->query("set names utf8");
            if($user_status == 2){
                $query = "SELECT c.id, c.date, u.first_name, u.last_name,(SELECT name FROM Gyms WHERE id = u.id_gym) as 'gym_name',(SELECT (SELECT name FROM Program WHERE id = program_id) as 'name' FROM Product WHERE id = (SELECT product_id FROM Plans WHERE id = c.plan_id)) as 'plan', d.quantity,
            (SELECT price*d.quantity FROM Product WHERE id = (SELECT product_id FROM Plans WHERE id = c.plan_id)) as 'price', (SELECT commission*d.quantity FROM Product WHERE id = (SELECT product_id FROM Plans WHERE id = c.plan_id)) as 'commission',
            (SELECT type FROM Product WHERE id = (SELECT product_id FROM Plans WHERE id = c.plan_id)) as 'type'
            FROM Calendars c JOIN Users u ON u.id = (SELECT user_id FROM Plans WHERE id = c.plan_id) JOIN Delivery d ON d.calendar_id = c.id
            WHERE d.status = 1 AND u.id_gym = '$id_gym' AND c.date = '$date_request'";
            }
            else {
                if(empty($gym)) {
                    $query = "SELECT c.id, c.date, u.first_name, u.last_name,(SELECT name FROM Gyms WHERE id = u.id_gym) as 'gym_name',(SELECT (SELECT name FROM Program WHERE id = program_id) as 'name' FROM Product WHERE id = (SELECT product_id FROM Plans WHERE id = c.plan_id)) as 'plan', d.quantity,
            (SELECT price*d.quantity FROM Product WHERE id = (SELECT product_id FROM Plans WHERE id = c.plan_id)) as 'price', (SELECT commission*d.quantity FROM Product WHERE id = (SELECT product_id FROM Plans WHERE id = c.plan_id)) as 'commission',
            (SELECT type FROM Product WHERE id = (SELECT product_id FROM Plans WHERE id = c.plan_id)) as 'type'
            FROM Calendars c JOIN Users u ON u.id = (SELECT user_id FROM Plans WHERE id = c.plan_id) JOIN Delivery d ON d.calendar_id = c.id
            WHERE d.status = 1 AND c.date = '$date_request'";
                } else {
                    $query = "SELECT c.id, c.date, u.first_name, u.last_name,(SELECT name FROM Gyms WHERE id = u.id_gym) as 'gym_name',(SELECT (SELECT name FROM Program WHERE id = program_id) as 'name' FROM Product WHERE id = (SELECT product_id FROM Plans WHERE id = c.plan_id)) as 'plan', d.quantity,
            (SELECT price*d.quantity FROM Product WHERE id = (SELECT product_id FROM Plans WHERE id = c.plan_id)) as 'price', (SELECT commission*d.quantity FROM Product WHERE id = (SELECT product_id FROM Plans WHERE id = c.plan_id)) as 'commission',
            (SELECT type FROM Product WHERE id = (SELECT product_id FROM Plans WHERE id = c.plan_id)) as 'type'
            FROM Calendars c JOIN Users u ON u.id = (SELECT user_id FROM Plans WHERE id = c.plan_id) JOIN Delivery d ON d.calendar_id = c.id
            WHERE d.status = 1 AND c.date = '$date_request' AND u.id_gym = '$gym'";
                }

            }
            $result = $conn->query($query);
            while ($row = $result->fetch_assoc()) {
                $type = $row['type'];
            ?>
                <tr data-toggle="modal" data-target="#myModal" style="cursor: pointer"
                    onclick="getDelivery('getDelivery',<?php echo $row['id'] ?>)">
                    <td><?php echo $row['id'] ?></td>
                    <td><?php echo $filter_date ?></td>
                    <td><?php echo $row['first_name']." ".$row['last_name'] ?></td>
                    <td><?php echo $row['gym_name'] ?></td>
                    <td><?php echo $row['plan'] ?></td>
                    <td><?php echo $row['quantity'] ?></td>
                    <td><?php echo $row['price'] ?></td>
                    <td><?php echo $row['commission']; ?></td>
                    <td><?php if($type == 0){echo 'По адресу';} elseif($type == 1){echo 'В спортзал';} else{echo 'Особые условия';}  ?></td>
                </tr>
                <?php
            }
            $result->close();
            break;

        case "getDeliverySalesGym":
            $val = filter("val");
            $filter_date = filter("filter_date");
            $f_date = filter("newDate");

            $result = $conn->query("set names utf8");
            if(empty($filter_date)) {
                $query = "SELECT c.id, c.date, u.first_name, u.last_name,(SELECT name FROM Gyms WHERE id = u.id_gym) as 'gym_name',(SELECT (SELECT name FROM Program WHERE id = program_id) as 'name' FROM Product WHERE id = (SELECT product_id FROM Plans WHERE id = c.plan_id)) as 'plan', d.quantity,
            (SELECT price*d.quantity FROM Product WHERE id = (SELECT product_id FROM Plans WHERE id = c.plan_id)) as 'price', (SELECT commission*d.quantity FROM Product WHERE id = (SELECT product_id FROM Plans WHERE id = c.plan_id)) as 'commission',
            (SELECT type FROM Product WHERE id = (SELECT product_id FROM Plans WHERE id = c.plan_id)) as 'type'
            FROM Calendars c JOIN Users u ON u.id = (SELECT user_id FROM Plans WHERE id = c.plan_id) JOIN Delivery d ON d.calendar_id = c.id
            WHERE d.status = 1 AND u.id_gym = '$val'";
            } else {
                $query = "SELECT c.id, c.date, u.first_name, u.last_name,(SELECT name FROM Gyms WHERE id = u.id_gym) as 'gym_name',(SELECT (SELECT name FROM Program WHERE id = program_id) as 'name' FROM Product WHERE id = (SELECT product_id FROM Plans WHERE id = c.plan_id)) as 'plan', d.quantity,
            (SELECT price*d.quantity FROM Product WHERE id = (SELECT product_id FROM Plans WHERE id = c.plan_id)) as 'price', (SELECT commission*d.quantity FROM Product WHERE id = (SELECT product_id FROM Plans WHERE id = c.plan_id)) as 'commission',
            (SELECT type FROM Product WHERE id = (SELECT product_id FROM Plans WHERE id = c.plan_id)) as 'type'
            FROM Calendars c JOIN Users u ON u.id = (SELECT user_id FROM Plans WHERE id = c.plan_id) JOIN Delivery d ON d.calendar_id = c.id
            WHERE d.status = 1 AND u.id_gym = '$val' AND c.date = '$f_date'";
            }

            $result = $conn->query($query);
            while ($row = $result->fetch_assoc()) {
                $date = DateTime::createFromFormat('Y-m-d', $row['date']);
                $date_d = $date->format("d-m-Y");
                $type = $row['type'];
                ?>
                <tr data-toggle="modal" data-target="#myModal" style="cursor: pointer"
                    onclick="getDelivery('getDelivery',<?php echo $row['id'] ?>)">
                    <td><?php echo $row['id'] ?></td>
                    <td><?php echo $date_d ?></td>
                    <td><?php echo $row['first_name']." ".$row['last_name'] ?></td>
                    <td><?php echo $row['gym_name'] ?></td>
                    <td><?php echo $row['plan'] ?></td>
                    <td><?php echo $row['quantity'] ?></td>
                    <td><?php echo $row['price'] ?></td>
                    <td><?php echo $row['commission']; ?></td>
                    <td><?php if($type == 0){echo 'По адресу';} elseif($type == 1){echo 'В спортзал';} else{echo 'Особые условия';}  ?></td>
                </tr>
                <?php
            }
            $result->close();
            break;

        case "getDeliverySalesRange":
            $id_gym = $_SESSION['gym_id'];
            $f_val = filter("val");
            $s_val = filter("id");
            $date_1 = DateTime::createFromFormat('d-m-Y', $f_val);
            $f_range = $date_1->format("Y-m-d");
            $date_2 = DateTime::createFromFormat('d-m-Y', $s_val);
            $s_range = $date_2->format("Y-m-d");
            $result = $conn->query("set names utf8");
            if($user_status == 2){
                $query = "SELECT c.id, c.date, u.first_name, u.last_name,(SELECT name FROM Gyms WHERE id = u.id_gym) as 'gym_name',(SELECT (SELECT name FROM Program WHERE id = program_id) as 'name' FROM Product WHERE id = (SELECT product_id FROM Plans WHERE id = c.plan_id)) as 'plan', d.quantity,
            (SELECT price*d.quantity FROM Product WHERE id = (SELECT product_id FROM Plans WHERE id = c.plan_id)) as 'price', (SELECT commission*d.quantity FROM Product WHERE id = (SELECT product_id FROM Plans WHERE id = c.plan_id)) as 'commission',
            (SELECT type FROM Product WHERE id = (SELECT product_id FROM Plans WHERE id = c.plan_id)) as 'type'
            FROM Calendars c JOIN Users u ON u.id = (SELECT user_id FROM Plans WHERE id = c.plan_id) JOIN Delivery d ON d.calendar_id = c.id
            WHERE d.status = 1 AND u.id_gym = '$id_gym' AND c.date BETWEEN '$f_range' AND '$s_range'";
            }
            else {
                $query = "SELECT c.id, c.date, u.first_name, u.last_name,(SELECT name FROM Gyms WHERE id = u.id_gym) as 'gym_name',(SELECT (SELECT name FROM Program WHERE id = program_id) as 'name' FROM Product WHERE id = (SELECT product_id FROM Plans WHERE id = c.plan_id)) as 'plan', d.quantity,
            (SELECT price*d.quantity FROM Product WHERE id = (SELECT product_id FROM Plans WHERE id = c.plan_id)) as 'price', (SELECT commission*d.quantity FROM Product WHERE id = (SELECT product_id FROM Plans WHERE id = c.plan_id)) as 'commission',
            (SELECT type FROM Product WHERE id = (SELECT product_id FROM Plans WHERE id = c.plan_id)) as 'type'
            FROM Calendars c JOIN Users u ON u.id = (SELECT user_id FROM Plans WHERE id = c.plan_id) JOIN Delivery d ON d.calendar_id = c.id
            WHERE d.status = 1 AND c.date BETWEEN '$f_range' AND '$s_range'";
            }
            $result = $conn->query($query);
            while ($row = $result->fetch_assoc()) {
                $type = $row['type'];
            ?>
                <tr data-toggle="modal" data-target="#myModal" style="cursor: pointer"
                    onclick="getDelivery('getDelivery',<?php echo $row['id'] ?>)">
                    <td><?php echo $row['id'] ?></td>
                    <td><?php echo $row['date'] ?></td>
                    <td><?php echo $row['first_name']." ".$row['last_name'] ?></td>
                    <td><?php echo $row['gym_name'] ?></td>
                    <td><?php echo $row['plan'] ?></td>
                    <td><?php echo $row['quantity'] ?></td>
                    <td><?php echo $row['price'] ?></td>
                    <td><?php echo $row['commission'] ?></td>
                    <td><?php if($type == 0){echo 'По адресу';} elseif($type == 1){echo 'В спортзал';} else{echo 'Особые условия';}  ?></td>
                </tr>
                <?php
            }
            $result->close();
            break;
    }
}
?>