<?php
header('Content-type: text/html; charset=utf8');
session_start();
$status = $_SESSION['status'];
$gym_id = $_SESSION['gym_id'];
include("../bd.php");
include('../actions/functions.php');

?>

<!DOCTYPE html>
<html lang="zxx">
<head>
    <!-- TITLE OF SITE -->
    <title>Все клиенты</title>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0" />
    <!--[if IE]><meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1'><![endif]-->
    <meta name="author" content="bierx_87" />
    <meta name="description" content="" />

    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <link rel="stylesheet/less" type="text/css" href="../css/main.less">
    <script type="text/javascript" src="../js/less.min.js"></script>
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">

    <noscript>
        <strong>Warning!</strong>
        Your browser does not support HTML5 so some elements on this page are simulated using JScript. Unfortunately your browser has JScript disabled. Please enable it in order to display this page.
    </noscript>
    <style>
        .get{
            margin-top: 10px;
        }
        .form-control{
            display: inline-block;
            max-width: 250px;
            margin-top: 20px;;
        }
    </style>

</head>

<body>

<?php
include("menuTemp.php");
?>
<!-- HEADER END -->
<div class="container block_menu text-center">

    <div id="myTabContent" class="tab-content">
        <a href="addClient.php"><button class="btn btn-success">Создать клиента</button></a>

        <div class="panel-title" style="font-size: 20px;text-align: center;margin-top: 15px;"><span>Клиенты</span></div>
        <?php if($status == 1){ ?>
        <select class="form-control" id="statusFilter" onchange="getRequest('getClientGym',this.value)">
            <option value="">--Все спортзалы--</option>
            <option value="0">Не спортзал</option>
            <?php
            $query = "SELECT * FROM Gyms";
            $results = $conn->query($query);
            while ($row = $results->fetch_assoc()) { ?>
                <option value="<?php echo $row["id"]; ?>"><?php echo $row["name"]; ?></option>
            <?php } ?>
        </select>
        <?php } ?>

        <select class="form-control" id="isSubscribe" onchange="getRequest('getClientSubscribe',this.value)">
            <option value="">Все клиенты</option>
            <option value="1" selected>Активные</option>
            <option value="0">Не активные</option>
        </select>
        <input type="text" class="form-control" id="filter" value="" placeholder="Имя клиента">

        <div class="tab-pane fade active in">
            <table class="table table-hover " id="tablesorted" style="width: 100%">
                <thead>
                <tr>
                    <th style="width: 5%">№</th>
                    <th>Спортзал</th>
                    <th>Клиент (имя, фамилия)</th>
                    <th>Телефон</th>
                    <th>План питания</th>
                    <th>Дней осталось</th>
                    <th>Баланс</th>
                </tr>
                </thead>
                <tbody>
                <?php
                $resultClient = $conn->query("set names utf8");
                if($status == 2){
                    $sqlClient = "SELECT u.id,(SELECT name FROM Gyms WHERE id = u.id_gym) as gym,u.first_name,u.last_name,u.phone FROM Users u WHERE u.id_gym = '$gym_id' ORDER BY u.id DESC";
                } else {
                    $sqlClient = "SELECT u.id,(SELECT name FROM Gyms WHERE id = u.id_gym) as gym,u.first_name,u.last_name,u.phone FROM Users u ORDER BY u.id DESC";
                }
                $resultClient = $conn->query($sqlClient);
                 while ($rowClient = $resultClient->fetch_assoc()) {
                     $active = active($rowClient['id']);
                     $balance = balance($rowClient['id']);

                     if (preg_match('/[^a-zA-Z]+/', $balance))
                     {
                         $css = 'style = "color: red"';
                     }
                    ?>
                    <tr style="cursor: pointer" onclick="actions(<?php echo $rowClient['id'] ?>)">
                        <td><?php echo $rowClient['id'] ?></td>
                        <td><?php echo $rowClient['gym'] ?></td>
                        <td><?php echo $rowClient['first_name']." ".$rowClient['last_name'] ?></td>
                        <td width="15%"><?php echo $rowClient['phone'] ?></td>
                        <td><?php echo $active['name_program'] ?></td>
                        <td style="text-align: center"> <?php echo ($active['days']-$active['days_off']); ?></td>
                        <td <?php echo $css ?>><?php echo $balance ?></td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<!-- CONTACT END -->

<!-- SCRIPTS -->
<script src="../js/jquery-1.11.3.min.js" type="text/javascript"></script>
<script src="../js/bootstrap.min.js" type="text/javascript"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/js/bootstrap-datepicker.min.js"></script>
<script src="../js/jquery.validate.min.js" type="text/javascript"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script>

    $(document).ready(function(){
        $("#filter").keyup(function(){

            // Retrieve the input field text and reset the count to zero
            var filter = $(this).val(), count = 0;

            // Loop through the comment list
            $(".table tr").each(function(){

                // If the list item does not contain the text phrase fade it out
                if ($(this).text().search(new RegExp(filter, "i")) < 0) {
                    $(this).fadeOut();

                    // Show the list item if the phrase matches and increase the count by 1
                } else {
                    $(this).show();
                    count++;
                }
            });
        });
        var a = $("#isSubscribe").val();
        getRequest('getClientSubscribe',a)
    });

    function getRequest(action,val) {
        var status = $("#statusFilter").val();
        $.ajax({
            type: "POST",
            url: "actions.php",
            data: {action:action,val:val,status:status},
            success: function(data){
                switch (action) {
                    case "getClientGym":
                        $("table.table tbody").html(data);
                        break;
                    case "getClientSubscribe":
                        $("table.table tbody").html(data);
                        break;
                }

            }
        });
    }
    function actions(id){
        window.location = "../profile.php?id="+id;
    }
</script>
</body>
</html>
