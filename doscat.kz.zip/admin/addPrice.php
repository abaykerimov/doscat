<?php
header('Content-type: text/html; charset=utf8');
session_start();
$id = $_SESSION["user_id"];
?>

<!DOCTYPE html>
<html lang="zxx">
<head>

    <!-- TITLE OF SITE -->
    <title>Создать прайс-лист</title>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0" />
    <!--[if IE]><meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1'><![endif]-->
    <meta name="author" content="bierx_87" />
    <meta name="description" content="" />

    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <link rel="stylesheet/less" type="text/css" href="../css/main.less">
    <script type="text/javascript" src="../js/less.min.js"></script>
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <link rel="stylesheet" media="all" type="text/css" href="../css/jquery-ui-timepicker-addon.css" />


    <noscript>
        <strong>Warning!</strong>
        Your browser does not support HTML5 so some elements on this page are simulated using JScript. Unfortunately your browser has JScript disabled. Please enable it in order to display this page.
    </noscript>
    <style>
        .file-upload input[type="file"]{
            display: none;/* скрываем input file */
        }
        /* задаем стили кнопки выбора файла*/

        .file-upload {
            position: relative;
            overflow: hidden;
            width: 150px;
            height: 50px;
            background: transparent;
            color: #fff;
            text-align: center;
            border: 4px double #1c1c1c;
        }

        .file-upload:hover {
            background: #c8c8c8;
        }

        /* Растягиваем label на всю область блока .file-upload */

        .file-upload label {
            display: block;
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            cursor: pointer;
        }

        /* стиль текста на кнопке*/
        .file-upload span {
            line-height: 40px;
            font-size: 14px;
            color: #000;
        }

        .form-group {
            width: 50%;
            margin-left: 25%;
        }
        .table tr td {
            margin-right: 10px;
        }
    </style>
</head>

<body>

<!-- HEADER -->
<?php
include("menuTemp.php");
?>
<!-- HEADER END -->
<div class="container block_menu text-center">
    <div id="myTabContent" class="col-md-12">
        <div class="form">
            <p style="font-size: 17px"><b>Прайс-лист</b></p>
            <hr>

            <div class="form-group">
                <select class="form-control" id="program">
                    <option value="">--Выберите программу--</option>
                    <?php
                    $result = $conn->query("set names utf8");
                    $sql = "SELECT * FROM Program";
                    $result = $conn->query($sql);
                    while($row = $result->fetch_assoc()){
                        ?>
                        <option value="<?php echo $row['id'] ?>"><?php echo $row['name'] ?></option>
                    <?php } ?>
                </select>
            </div>

            <div class="form-group">
                <select class="form-control" id="type">
                    <option value="">--Выберите тип прайс-листа--</option>
                    <?php
                    $resultType = $conn->query("set names utf8");
                    $sqlType = "SELECT * FROM Delivery_inPlans";
                    $resultType = $conn->query($sqlType);
                    while($rowType = $resultType->fetch_assoc()){
                        ?>
                        <option value="<?php echo $rowType['id'] ?>"><?php echo $rowType['name'] ?></option>
                    <?php } ?>
                </select>
            </div>

            <div class="col-md-12">
                <table class="table">
                    <tbody>
                    <tr class="price">
                        <td><input class="form-control price" type="number" placeholder="Стоимость в день"></td>
                        <td><input class="form-control amount" type="number" placeholder="Количество дней"></td>
                        <td><input class="form-control commission" type="number" placeholder="Агентская комиссия"></td>
                        <td><input class="form-control freezing" type="number" placeholder="Кол-во дней заморозки"></td>
                    </tr>
                    <tr class="price">
                        <td><input class="form-control price" type="number" placeholder="Стоимость в день"></td>
                        <td><input class="form-control amount" type="number" placeholder="Количество дней"></td>
                        <td><input class="form-control commission" type="number" placeholder="Агентская комиссия"></td>
                        <td><input class="form-control freezing" type="number" placeholder="Кол-во дней заморозки"></td>
                    </tr>
                    <tr class="price">
                        <td><input class="form-control price" type="number" placeholder="Стоимость в день"></td>
                        <td><input class="form-control amount" type="number" placeholder="Количество дней"></td>
                        <td><input class="form-control commission" type="number" placeholder="Агентская комиссия"></td>
                        <td><input class="form-control freezing" type="number" placeholder="Кол-во дней заморозки"></td>
                    </tr>
                    <tr class="price">
                        <td><input class="form-control price" type="number" placeholder="Стоимость в день"></td>
                        <td><input class="form-control amount" type="number" placeholder="Количество дней"></td>
                        <td><input class="form-control commission" type="number" placeholder="Агентская комиссия"></td>
                        <td><input class="form-control freezing" type="number" placeholder="Кол-во дней заморозки"></td>
                    </tr>
                    </tbody>
                </table>
            </div>

            <div class="form-group text-center add">
                <div class="col-lg-12">
                    <button type="submit" class="btn btn-success submit" onclick="actions('addPrice');">Сохранить</button>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- CONTACT END -->

<!-- SCRIPTS -->
<script src="../js/jquery-1.11.3.min.js" type="text/javascript"></script>
<script src="../js/bootstrap.min.js" type="text/javascript"></script>
<script src="../js/jquery.validate.min.js" type="text/javascript"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script type="text/javascript" src="../js/jquery-ui-timepicker-addon.js"></script>
<script type="text/javascript" src="../js/jquery-ui-timepicker-addon-i18n.min.js"></script>
<script type="text/javascript" src="../js/jquery.maskedinput.js"></script>

<script>

    function actions(action){
        $(".price").each(function(){
            var program = $("#program").val();
            var type = $("#type").val();
            var price = $(this).find(".form-control.price").val();
            var amount = $(this).find(".form-control.amount").val();
            var commission = $(this).find(".form-control.commission").val();
            var freezing = $(this).find(".form-control.freezing").val();
            if(price!=null && amount!=null && commission!=null && freezing!=null) {
                $.ajax({
                    url: "actions.php",
                    data: {action: action,program:program,price_type:type,price: price, amount: amount, commission: commission, freezing:freezing},
                    type: "POST",
                    success: function () {
                        switch (action) {
                            case "addPrice":
                                $(".add").append("<div id='suggnot' class='alert-box success'>Прайс-лист успешно создан</div>");
                                $( "div#suggnot" ).fadeIn( 300 ).delay( 1500 ).fadeOut( 400 );
                                setTimeout(function(){
                                    window.location = "price.php";
                                }, 500);
                                break;
                        }
                    }
                })
            }
        });
    }

    function getFileName() {
        $(".btn.btn-success.btnSubmit").css("margin-top", "25px");
        var filename = $('input[type=file]').val().replace(/C:\\fakepath\\/i, '');
        $('.showname').html(filename);
    }

    $(document).ready(function (e) {
        $("#uploadForm").on('submit',(function(e) {
            e.preventDefault();
            $.ajax({
                url: "../actions/upload.php",
                type: "POST",
                data:  new FormData(this),
                contentType: false,
                cache: false,
                processData:false,
                success: function(data)
                {
                    $("#targetLayer").html(data);
                },
                error: function() {}
            });
        }));
    });
</script>
</body>
</html>
