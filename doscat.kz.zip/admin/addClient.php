<?php
//ini_set('error_reporting', E_ALL);
//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);
header('Content-type: text/html; charset=utf8');
session_start();
$status = $_SESSION['status'];
$gym_id = $_SESSION['gym_id'];
include("../bd.php");

require_once '../actions/functions.php';
require_once '../actions/filter.php';

//получим массив по плану
$id = $_SESSION["user_id"];
if (!isset($id) and !is_numeric($id)) {
    header("Location: login.php");
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name=viewport content="width=device-width, initial-scale=1">
    <meta http-equiv="content-type" content="text/html; charset=UTF-8"/>

    <title>Создать профиль</title>
    <link rel="canonical" href=""/>
    <meta name="robots" content="index, follow"/>
    <meta name="keywords" content=""/>
    <meta name="description" content=""/>

    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <link rel="stylesheet/less" type="text/css" href="../css/main.less">
    <script type="text/javascript" src="../js/less.min.js"></script>

    <!-- Include Bootstrap Datepicker -->
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/css/datepicker.min.css"/>
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/css/datepicker3.min.css"/>

</head>
<body>
<?php
include("menuTemp.php");
?>
<div class="container block_cabinet text-center" id="menu">
    <div id="myTabContent" class="col-lg-12">
        <form class="form-horizontal text-center" onsubmit="return false;">
            <fieldset>
                <p style="font-size: 17px"><b>Личный кабинет</b></p>
                <div class="form-group">
                    <label for="inputName" class="col-lg-4 control-label">Имя:</label>
                    <div class="col-lg-4 text-left">
                        <input class="form-control user_name" id="user_fname" placeholder="Имя" type="text">
                    </div>
                </div>
                <div class="form-group">
                    <label for="inputLastname" class="col-lg-4 control-label">Фамилия:</label>
                    <div class="col-lg-4 text-left">
                        <input class="form-control user_lastname" id="user_lname" placeholder="Фамилия" type="text">
                    </div>
                </div>
                <div class="form-group">
                    <label for="inputPhone" class="col-lg-4 control-label">Телефон:</label>
                    <div class="col-lg-4 text-left">
                        <input class="form-control user_phone phone" id="user_phone" placeholder="Телефон" type="tel">
                    </div>
                </div>
                <div class="form-group">
                    <label for="inputEmail" class="col-lg-4 control-label">Почта:</label>
                    <div class="col-lg-4 text-left">
                        <input class="form-control user_email" id="user_email" placeholder="Почта" type="text">
                    </div>
                </div>
                <div class="form-group">
                    <label for="inputDbirthday" class="col-lg-4 control-label">Дата рождения:</label>
                    <div class="col-lg-4 text-left">
                        <input class="form-control user_dbirthday date" id="user_db" placeholder="Дата рождения" type="text">
                    </div>
                </div>
                <?php if($status == 1) { ?>
                <div class="form-group">
                    <label for="inputDbirthday" class="col-lg-4 control-label">Статус пользователя:</label>
                    <div class="col-lg-4 text-left">
                        <select class="form-control" id="user_status" required>
                            <option value="0">Клиент</option>
                            <option value="1">Админ</option>
                            <option value="2">Партнер</option>
                            <option value="3">Курьер</option>
                        </select>
                    </div>
                </div>
                <?php } ?>
                <div class="form-group">
                    <div class="col-lg-12">
                        <button type="submit" class="btn btn-warning addInfo" onclick="add_user('addUserInfo');">Сохранить</button>
                    </div>
                </div>
                <div class="col-lg-offset-4 col-lg-4 alert1"></div>
            </fieldset>
        </form>
    </div>
</div>

</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://bootswatch.com/bower_components/bootstrap/dist/js/bootstrap.min.js" type="text/javascript"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/js/bootstrap-datepicker.min.js"></script>
<script type="text/javascript" src="../js/owl.carousel.min.js"></script>
<script type="text/javascript" src="../js/jquery.scrollTo.min.js"></script>
<script type="text/javascript" src="../js/jquery.inputmask.bundle.js"></script>
<script type="text/javascript" src="../js/sweetalert.min.js"></script>
<script type="text/javascript" src="../js/js.js"></script>
<script>

    !function(a){a.fn.datepicker.dates.ru={days:["Воскресенье","Понедельник","Вторник","Среда","Четверг","Пятница","Суббота"],daysShort:["Вск","Пнд","Втр","Срд","Чтв","Птн","Суб"],daysMin:["Вс","Пн","Вт","Ср","Чт","Пт","Сб"],months:["Январь","Февраль","Март","Апрель","Май","Июнь","Июль","Август","Сентябрь","Октябрь","Ноябрь","Декабрь"],monthsShort:["Янв","Фев","Мар","Апр","Май","Июн","Июл","Авг","Сен","Окт","Ноя","Дек"],today:"Сегодня",clear:"Очистить",format:"dd.mm.yyyy",weekStart:1}}(jQuery);

    $('.date').datepicker({
        autoclose: true,
        format: 'yyyy-mm-dd',
        language: 'ru',
        todayHighlight: true
    });

    function add_user(action) {
        var first_name = $('#user_fname').val();
        var last_name = $('#user_lname').val();
        var phone = $('#user_phone').val();
        var email = $('#user_email').val();
        var db = $('#user_db').val();
        var user_status = $("#user_status").val();
        var id_gym = <?php echo $gym_id ?>;
        var f = "<?php echo $_GET['from'] ?>";
        $.ajax({
            url: "actions.php",
            data: {action: action, first_name: first_name, last_name: last_name, phone: phone, email: email, db: db, id_gym:id_gym,user_status:user_status},
            type: "POST",
            success: function (data) {
                switch (action) {
                    case "addUserInfo":
                        if(data == "0") {
                            $(".alert1").html("<div id='alert0' class='alert alert-danger'>Пользователь с таким телефоном уже существует!</div>");
                            $("#alert0").fadeIn( 300 ).delay( 1500 ).fadeOut( 400);
                        } else {
                            $(".alert1").html("<div id='alert1' class='alert alert-success'>Профиль создан</div>");
                            $("#alert1").fadeIn( 300 ).delay( 1500 ).fadeOut( 400);
                            if(f == "request") {
                                window.location = "addOrder.php";
                            } else {
                                window.location = "../profile.php?id="+data;
                            }
                        }
                        break;
                }
            }
        });
        $("#alert1").remove();
    }
</script>
</html>