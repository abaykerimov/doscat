<?php
header('Content-type: text/html; charset=utf8');
session_start();
include("../bd.php");
$id = $_SESSION["user_id"];
?>

<!DOCTYPE html>
<html lang="zxx">
<head>

    <!-- TITLE OF SITE -->
    <title>Список спортзалов</title>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0" />
    <!--[if IE]><meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1'><![endif]-->
    <meta name="author" content="bierx_87" />
    <meta name="description" content="" />
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <link rel="stylesheet/less" type="text/css" href="../css/main.less">
    <script type="text/javascript" src="../js/less.min.js"></script>
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <link rel="stylesheet" type="text/css" href="../css/font-awesome.min.css">

    <noscript>
        <strong>Warning!</strong>
        Your browser does not support HTML5 so some elements on this page are simulated using JScript. Unfortunately your browser has JScript disabled. Please enable it in order to display this page.
    </noscript>
    <style>
        .get{
            margin-top: 10px;
        }
    </style>
</head>

<body>

<!-- HEADER -->
<?php
include("menuTemp.php");
?>
<!-- HEADER END -->
<div class="container block_menu text-center">
    <div id="myTabContent" class="tab-content">
        <a href="addGym.php"><button class="btn btn-success">Добавить спортзал</button></a>

        <table class="table table-striped table-hover " id="tablesorted" style="width: 100%">
            <thead>
            <tr>
                <th class='th_name'>№</th>
                <th>Название</th>
                <th>Адрес</th>
                <th>Действие</th>
                <th>Особые</th>
            </tr>
            </thead>
            <tbody>
            <?php
            $result = $conn->query("set names utf8");
            $sql = "SELECT * FROM Gyms ORDER BY name";
            $result = $conn->query($sql);

            while ($row = $result->fetch_assoc()) { ?>
                <tr>
                    <td><?php echo $row['id'] ?></td>
                    <td><?php echo $row['name'] ?></td>
                    <td><?php echo $row['address'] ?></td>
                    <td>
                        <a style="margin-right: 15px" href="editGym.php?id=<?php echo $row['id'] ?>"><i class="glyphicon glyphicon-pencil"></i></a>
                        <a href="" onclick="actions('deleteGym', <?php echo $row['id'] ?>)"><i class="glyphicon glyphicon-trash"></i></a>
                    </td>
                    <td><?php if($row['special'] == 1) echo '<span class="glyphicon glyphicon-ok"></span>' ?></td>
                </tr>
            <?php } ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Спортзал</h4>
            </div>
            <div class="modal-body">

            </div>
        </div>

    </div>
</div>
<!-- SCRIPTS -->
<script src="../js/jquery-1.11.3.min.js" type="text/javascript"></script>
<script src="../js/bootstrap.min.js" type="text/javascript"></script>
<script src="../js/jquery.validate.min.js" type="text/javascript"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script>

    function actions(action, id) {
        $.ajax({
            url: "actions.php",
            data: {action:action, gym_id:id},
            type: "POST",
            success: function (data) {
                switch (action) {
                    /*case "getGym":
                        $(".modal-body").html(data);
                        break;*/
                    case "deleteGym":
                        location.reload();
                        break;
                }
            }
        });
    }

    $(".glyphicon-trash").click(function(){
        if(!confirm("Вы хотите удалить?"))
            return false;
    });

</script>

</body>
</html>
