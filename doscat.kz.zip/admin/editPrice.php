<?php
header('Content-type: text/html; charset=utf8');
session_start();
$id = $_SESSION["user_id"];
$price_id = $_GET['id'];
include("../bd.php");
$result = $conn->query("set names utf8");
$sql = "SELECT id,(SELECT id FROM Program WHERE id=program_id) as 'program',(SELECT photo FROM Program WHERE id=program_id) as 'photo',(SELECT name FROM Program WHERE id=program_id) as 'name',(SELECT kcal FROM Program WHERE id=program_id) as 'kcal',price,amount_days,(SELECT description FROM Program WHERE id=program_id) as 'description',freezing,commission,type FROM Product WHERE id = '$price_id'";
$result = $conn->query($sql);
$row = $result->fetch_assoc();

//ini_set('error_reporting', E_ALL);
//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);
?>

<!DOCTYPE html>
<html lang="zxx">
<head>

    <!-- TITLE OF SITE -->
    <title>Редактировать прайс-лист</title>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0" />
    <!--[if IE]><meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1'><![endif]-->
    <meta name="author" content="bierx_87" />
    <meta name="description" content="" />

    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <link rel="stylesheet/less" type="text/css" href="../css/main.less">
    <script type="text/javascript" src="../js/less.min.js"></script>
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <link rel="stylesheet" media="all" type="text/css" href="../css/jquery-ui-timepicker-addon.css" />


    <noscript>
        <strong>Warning!</strong>
        Your browser does not support HTML5 so some elements on this page are simulated using JScript. Unfortunately your browser has JScript disabled. Please enable it in order to display this page.
    </noscript>
    <style>
        .file-upload input[type="file"]{
            display: none;/* скрываем input file */
        }
        /* задаем стили кнопки выбора файла*/

        .file-upload {
            position: relative;
            overflow: hidden;
            width: 150px;
            height: 50px;
            background: transparent;
            color: #fff;
            text-align: center;
            border: 4px double #1c1c1c;
        }

        .file-upload:hover {
            background: #c8c8c8;
        }

        /* Растягиваем label на всю область блока .file-upload */

        .file-upload label {
            display: block;
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            cursor: pointer;
        }

        /* стиль текста на кнопке*/
        .file-upload span {
            line-height: 40px;
            font-size: 14px;
            color: #000;
        }

        .form-group {
            width: 50%;
            margin-left: 25%;
        }
    </style>
</head>

<body>

<!-- HEADER -->
<?php
include("menuTemp.php");
?>

<div class="container block_menu text-center">
    <div id="myTabContent" class="col-md-12">
        <div class="form">
            <p style="font-size: 17px"><b>Прайс-лист</b></p>
            <hr>

            <div class="form-group">
                <form id="uploadForm" method="post" action="../actions/upload.php">
                    <div id="targetLayer" style="float: left">
                        <img src="<?php echo $row['photo'] ?>" width="300px" height="300px" id="avatar">
                    </div>
                    <div id="uploadFormLayer" style="float: right;margin-bottom:15px">
                        <div class="file-upload">
                            <label>
                                <input type="file" name="file" id="upload-file" onchange="getFileName();">
                                <span>Выберите фото</span>
                            </label>

                        </div>
                        <span class="showname" style="position: absolute;float: right; font-size: 14px;"></span>
                        <button style="width: 100%;font-size: 14px;float: right" type="submit" class="btn btn-success btnSubmit">Загрузить</button>
                    </div>
                </form>
            </div>

            <div class="form-group">
                <input class="form-control" id="product_name" type="text" placeholder="Название плана" value="<?php echo $row['name'] ?>">
            </div>

            <div class="form-group">
                <input class="form-control" id="kcal" type="text" placeholder="Количество калорий" value="<?php echo $row['kcal'] ?>">
            </div>

            <div class="form-group">
                <input class="form-control" id="description" type="text" placeholder="Описание" value="<?php echo $row['description'] ?>">
            </div>

            <div class="form-group">
                <select class="form-control" id="type">
                    <option value="">--Выберите тип прайс-листа--</option>
                    <?php
                    $resultType = $conn->query("set names utf8");
                    $sqlType = "SELECT * FROM Delivery_inPlans";
                    $resultType = $conn->query($sqlType);
                    while($rowType = $resultType->fetch_assoc()){
                        ?>
                        <option value="<?php echo $rowType['id'] ?>" <?php if($rowType['id'] == $row['type']) echo 'selected' ?>><?php echo $rowType['name'] ?></option>
                    <?php } ?>
                </select>
            </div>

            <div class="form-group">
                <input class="form-control" id="price" type="number" placeholder="Стоимость в день" value="<?php echo $row['price'] ?>">
            </div>

            <div class="form-group">
                <input class="form-control" id="amount" type="number" placeholder="Количество дней" value="<?php echo $row['amount_days'] ?>">
            </div>

            <div class="form-group">
                <input class="form-control" id="commission" type="number" placeholder="Агентская комиссия" value="<?php echo $row['commission'] ?>">
            </div>

            <div class="form-group">
                <input class="form-control" id="freezing" type="number" placeholder="Кол-во дней заморозки" value="<?php echo $row['freezing'] ?>">
            </div>

            <div class="form-group text-center add">
                <div class="col-lg-12">
                    <button type="submit" class="btn btn-success submit" onclick="actions('editPrice', <?php echo $price_id ?>, <?php echo $row['program'] ?>)">Сохранить</button>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- CONTACT END -->

<!-- SCRIPTS -->
<script src="../js/jquery-1.11.3.min.js" type="text/javascript"></script>
<script src="../js/bootstrap.min.js" type="text/javascript"></script>
<script src="../js/jquery.validate.min.js" type="text/javascript"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script type="text/javascript" src="../js/jquery-ui-timepicker-addon.js"></script>
<script type="text/javascript" src="../js/jquery-ui-timepicker-addon-i18n.min.js"></script>
<script type="text/javascript" src="../js/jquery.maskedinput.js"></script>

<script>

    function actions(action, id, p_id){
        var photo = $('#avatar').attr("src");
        var product_name = $("#product_name").val();
        var type = $("#type").val();
        var kcal = $("#kcal").val();
        var price = $("#price").val();
        var amount = $("#amount").val();
        var description = $("#description").val();
        var freezing = $("#freezing").val();
        var commission = $("#commission").val();

        $.ajax({
            url: "actions.php",
            data: {action: action,price_id:id,program:p_id, photo:photo,product_name:product_name,price_type:type,kcal:kcal,price: price,amount:amount,description:description,freezing:freezing,commission:commission},
            type: "POST",
            success: function (data) {
                switch (action) {
                    case "editPrice":
                        $(".add").append("<div id='suggnot' class='alert-box success'>План успешно отредактирован</div>");
                        $( "div#suggnot" ).fadeIn( 300 ).delay( 1500 ).fadeOut( 400 );
                        window.location = "price.php";
                        break;
                }
            }
        })
    }

    function getFileName() {
        $(".btn.btn-success.btnSubmit").css("margin-top", "25px");
        var filename = $('input[type=file]').val().replace(/C:\\fakepath\\/i, '');
        $('.showname').html(filename);
    }

    $(document).ready(function (e) {
        $("#uploadForm").on('submit',(function(e) {
            e.preventDefault();
            $.ajax({
                url: "../actions/upload.php",
                type: "POST",
                data:  new FormData(this),
                contentType: false,
                cache: false,
                processData:false,
                success: function(data)
                {
                    $("#targetLayer").html(data);
                },
                error: function() {}
            });
        }));
    });
</script>
</body>
</html>
