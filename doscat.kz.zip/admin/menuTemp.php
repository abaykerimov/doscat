<?php
//ini_set('error_reporting', E_ALL);
//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);
if ($_SESSION["admin_id"] > 0) {
    $_SESSION["user_id"] = $_SESSION["admin_id"];
    $_SESSION['admin_id'] = 0;
}
$id = $_SESSION["user_id"];
include("../bd.php");
$resultUser = $conn->query("set names utf8");
$sqlUser = "SELECT email,id_gym,user_status,(SELECT name FROM Gyms WHERE id = id_gym) as 'gym_name' FROM Users WHERE id = '$id'";
$resultUser = $conn->query($sqlUser);
$rowUser = $resultUser->fetch_assoc();
$user_status = $rowUser['user_status'];
$id_gym = $rowUser['id_gym'];
if(!$id) {
    header("Location: ../login.php");
}
else if($user_status != 1 && $user_status != 2) {
    header("Location: ../index.php");
}
else if($user_status == 1 || $user_status == 2) {
?>
    <nav class="navbar navbar-default navbar-fixed-top" style="min-height: 81px">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php"><img src="../img/logo.png" alt="Dostyk Catering - правильное питание с доставкой по Алматы"></a>
            </div>

            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li><a href=""><?php echo $rowUser['email'] ?></a></li>
                    <li><a href="../profile.php"><?php if($user_status==1){echo 'Админ';}
                            elseif($user_status==2){
                                echo 'Партнер<br>'. $rowUser['gym_name'];
                            }
                            elseif($user_status==3){echo 'Курьер';} else{echo 'Клиент';} ?>
                        </a>
                    </li>
                    <?php $rCount1 = $conn->query("set names utf8");
                    $sqlCount1 = "SELECT COUNT(DISTINCT user_id) as 'count' FROM Plans WHERE user_id in (SELECT id FROM Users WHERE id_gym = '$id_gym')";
                    $rCount1 = $conn->query($sqlCount1);
                    $rowCount1 = $rCount1->fetch_assoc(); ?>
                    <li><a>Активных клиентов: <?php echo $rowCount1['count']; ?>
                            <?php $rCount2 = $conn->query("set names utf8");
                            $sqlCount2 = "SELECT COUNT(id) as 'count' FROM Users WHERE id_gym = '$id_gym'";
                            $rCount2 = $conn->query($sqlCount2);
                            $rowCount2 = $rCount2->fetch_assoc(); ?>
                            <br>Всего клиентов: <?php echo $rowCount2['count']; ?></a></li>
                    <li><a href="../logout.php">Выйти</a></li>
                </ul>
            </div>
        </div>
    </nav>
    <?php if($user_status == 1) { ?>
        <nav class="navbar navbar-inverse" style="margin-bottom: 0;margin-top: 80px;">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-2">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                </div>
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-2">

                    <ul class="nav navbar-nav">

                        <li class="dropdown">
                            <a class="dropdown-toggle" data-toggle="dropdown" style="cursor: pointer">Меню
                                <span class="caret"></span></a>
                            <ul class="dropdown-menu">
                                <li><a href="menu.php?type=3">Меню 3x</a></li>
                                <li><a href="menu.php?type=5">Меню 5x</a></li>
                                <li><a href="foods.php?type=0">Блюда</a></li>
                                <li><a href="foods.php?type=1">Десерты</a></li>
                            </ul>

                        </li>
                        <li><a href="payments.php">Платежи</a></li>
                        <li><a href="">Учет денег</a></li>
                        <li><a href="price.php">Прайс-лист</a></li>

                        <li class="dropdown">
                            <a class="dropdown-toggle" data-toggle="dropdown" style="cursor: pointer">Отчеты
                                <span class="caret"></span></a>
                            <ul class="dropdown-menu">
                                <li><a href="reports.php">Статистика клиентов</a></li>
                                <li><a href="foodstats.php">Статистика блюд</a></li>
                            </ul>
                        </li>

                        <li><a href="">Жалобы</a></li>
                        <li class="dropdown">
                            <a class="dropdown-toggle" data-toggle="dropdown" style="cursor: pointer">Справочники
                                <span class="caret"></span></a>
                            <ul class="dropdown-menu">
                                <li><a href="gyms.php">Спортзалы</a></li>
                                <li><a href="couriers.php">Курьеры</a></li>
                            </ul>
                        </li>
                        <li><a href="">Настройки</a></li>
                    </ul>
                </div>
            </div>
        </nav>
    <?php } if($user_status == 1 || $user_status == 2) {
        if($user_status == 2){
            $style = 'style="margin-top: 80px;background-color: rgba(255, 255, 115, 0.5);"';
        } else {
            $style = 'style="margin-top: 0;background-color: rgba(255, 255, 115, 0.5);"';
        }
        ?>
        <nav class="navbar navbar-inverse" <?php echo $style ?>>
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-2">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                </div>
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-2">
                    <ul class="nav navbar-nav">
                        <li><a href="index.php">Заявки</a></li>
                        <li><a href="delivery.php">Наряды</a></li>
                        <li><a href="clients.php">Клиенты</a></li>
                        <li><a href="sales.php">Продажи спортзала</a></li>
                        <li><a href="">Справочники</a></li>
                    </ul>
                </div>
            </div>
        </nav>
    <?php } ?>
<?php
}
?>
