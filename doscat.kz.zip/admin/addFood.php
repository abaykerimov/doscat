<?php
header('Content-type: text/html; charset=utf8');
session_start();
include("../bd.php");

$id = $_SESSION["user_id"];
$type = $_GET['type'];
?>

<!DOCTYPE html>
<html lang="zxx">
<head>

    <!-- TITLE OF SITE -->
    <title>Добавить еду</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0" />
    <!--[if IE]><meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1'><![endif]-->
    <meta name="author" content="bierx_87" />
    <meta name="description" content="" />
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <link rel="stylesheet/less" type="text/css" href="../css/main.less">
    <script type="text/javascript" src="../js/less.min.js"></script>
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">

    <noscript>
        <strong>Warning!</strong>
        Your browser does not support HTML5 so some elements on this page are simulated using JScript. Unfortunately your browser has JScript disabled. Please enable it in order to display this page.
    </noscript>

    <style>
        .file-upload input[type="file"]{
            display: none;/* скрываем input file */
        }
        /* задаем стили кнопки выбора файла*/

        .file-upload {
            position: relative;
            overflow: hidden;
            width: 150px;
            height: 50px;
            background: transparent;
            color: #fff;
            text-align: center;
            border: 4px double #1c1c1c;
        }

        .file-upload:hover {
            background: #c8c8c8;
        }

        /* Растягиваем label на всю область блока .file-upload */

        .file-upload label {
            display: block;
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            cursor: pointer;
        }

        /* стиль текста на кнопке*/
        .file-upload span {
            line-height: 40px;
            font-size: 14px;
            color: #000;
        }
    </style>
</head>

<body>

<?php
include("menuTemp.php");
?>
<!-- HEADER END -->

<div class="container block_menu text-center">
    <div id="myTabContent" class="col-md-6 col-md-offset-3">
        <div class="form-group">
            <form id="uploadForm" method="post" action="../actions/upload.php">
                <div id="targetLayer" style="float: left">
                </div>
                <div id="uploadFormLayer" style="float: right;margin-bottom:15px">
                    <div class="file-upload">
                        <label>
                            <input type="file" name="file" id="upload-file" onchange="getFileName();">
                            <span>Выберите фото</span>
                        </label>

                    </div>
                    <span class="showname" style="position: absolute;float: right; font-size: 14px;"></span>
                    <button style="width: 100%;font-size: 14px;float: right" type="submit" class="btn btn-success btnSubmit">Загрузить</button>
                </div>
            </form>
        </div>
        <div class="form-group">
            <input type="text" class="form-control name" placeholder="Название" required />
        </div>
        <div class="form-group">
            <textarea class="form-control description" placeholder="Описание" required></textarea>
        </div>
        <div class="form-group">
            <input type="number" class="form-control kcal" placeholder="Ккалория" required />
        </div>
        <div class="form-group">
            <input type="number" class="form-control protein" placeholder="Белок" required />
        </div>

        <div class="form-group">
            <input type="number" class="form-control fat" placeholder="Жир" required />
        </div>
        <div class="form-group">
            <input type="number" class="form-control carbo" placeholder="Углеводы" required />
        </div>

        <?php if($type == 1) { ?>
            <div class="form-group">
                <input type="number" class="form-control unit" placeholder="Ед. изм" required />
            </div>
            <div class="form-group">
                <input type="number" class="form-control price" placeholder="Цена" required />
            </div>
        <?php } ?>

        <div class="form-group add">
            <input class="btn btn-success" type="submit" value="Сохранить" onclick="actions('addFood');">
        </div>
    </div>
</div>

<!-- SCRIPTS -->
<script src="../js/jquery-1.11.3.min.js" type="text/javascript"></script>
<script src="../js/bootstrap.min.js" type="text/javascript"></script>
<script src="../js/jquery.validate.min.js" type="text/javascript"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script>
    $("#addForm").validate();

    $.urlParam = function(name){
        var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(window.location.href);
        if (results==null){
            return null;
        }
        else{
            return results[1] || 0;
        }
    };

    function actions(action){
        var get_type = $.urlParam('type');
        var photo = $('#avatar').attr("src");
        var name = $('.form-control.name').val();
        var description = $('.form-control.description').val();
        var kcal = $('.form-control.kcal').val();
        var protein = $(".form-control.protein").val();
        var fat = $(".form-control.fat").val();
        var carbo = $(".form-control.carbo").val();
        var unit = $(".form-control.unit").val();
        var price = $(".form-control.price").val();
        $.ajax({
            url: "actions.php",
            data: {
                action: action, get_type:get_type,photo: photo, name: name, description: description, kcal: kcal, protein: protein, fat: fat, carbo: carbo, unit:unit, price:price
            },
            type: "POST",
            success: function (data) {
                switch (action) {
                    case "addFood":
                        $(".form-group.add").append("<div id='suggnot' class='alert-box success'>Рецепт успешно добавлен</div>");
                        $("div#suggnot").fadeIn(300).delay(1500).fadeOut(400);
                        if($.urlParam('type') == 1) {
                            window.location = "foods.php?type=1";
                        } else {
                            window.location = "foods.php?type=0";
                        }
                        break;
                }
            }
        });
    }

    function getFileName() {
        $(".btn.btn-success.btnSubmit").css("margin-top", "25px");
        var filename = $('input[type=file]').val().replace(/C:\\fakepath\\/i, '');
        $('.showname').html(filename);
    }

    $(document).ready(function (e) {
        $("#uploadForm").on('submit',(function(e) {
            e.preventDefault();
            $.ajax({
                url: "../actions/upload.php",
                type: "POST",
                data:  new FormData(this),
                contentType: false,
                cache: false,
                processData:false,
                success: function(data)
                {
                    $("#targetLayer").html(data);
                },
                error: function() {}
            });
        }));
    });
</script>

</body>
</html>
