<?php
header('Content-type: text/html; charset=utf8');
session_start();
$status = $_SESSION['status'];
include("../bd.php");

?>

<!DOCTYPE html>
<html lang="zxx">
<head>

    <!-- TITLE OF SITE -->
    <title>Все наряды</title>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0" />
    <!--[if IE]><meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1'><![endif]-->
    <meta name="author" content="bierx_87" />
    <meta name="description" content="" />

    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <link rel="stylesheet/less" type="text/css" href="../css/main.less">
    <script type="text/javascript" src="../js/less.min.js"></script>
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">

    <noscript>
        <strong>Warning!</strong>
        Your browser does not support HTML5 so some elements on this page are simulated using JScript. Unfortunately your browser has JScript disabled. Please enable it in order to display this page.
    </noscript>
    <style>
        .get{
            margin-top: 10px;
        }

        .form-control{
            display: inline-block;
            max-width: 250px;
            margin-top: 20px;;
        }
        .row-all-project {
            margin: 0;
            padding: 0;
            vertical-align: top;
            background-color: white!important;
            border: none!important;
        }
        .row-all-project h4 {
            border-bottom: 2px solid #dddddd;
            padding: 10px 15px;
            margin: 0;
            color: black;
        }
        .row-all-project a {
            border-bottom: 1px solid #dddddd;
            padding: 7px 10px;
            margin: 0;
            display: block;
            text-shadow: none;
        }
        .block_menu .nav-tabs li {
            display: block;
            max-width: 50%;
            margin-left: 0;
        }
    </style>
</head>

<body>

<?php
include("menuTemp.php");
?>
<!-- HEADER END -->
<div class="container block_menu text-center">
    <div id="myTabContent" class="tab-content">

        <div class="panel-title" style="font-size: 20px;text-align: center;margin-top: 15px;"><span>Наряды</span></div>
        <input class="form-control" id="dateFilter" placeholder="Дата" type="text" value="<?php echo date('d-m-Y') ?>">
        <select class="form-control" id="statusFilter" onchange="getDelivery('getDeliveryStatus',this.value,<?php echo $rowUser['id_gym'] ?>)">
            <option value="">--Статус наряда--</option>
            <option value="1">Доставлено</option>
            <option value="0">Не доставлено</option>
        </select>
        <button class="btn btn-success export">Экспорт в PDF</button>

        <table class="table table-hover " id="tablesorted" style="width: 100%">
            <thead>
            <tr>
                <th width="7%">№</th>
                <th width="15%">Адрес доставки</th>
                <th>Получатель</th>
                <th width="10%">План питания</th>
                <th>Кол</th>
                <th width="15%" style="text-align: center">Комментарий</th>
                <th>Курьер</th>
                <th width="10%">Время план</th>
                <th width="12%">Статус доставки</th>
                <th>Время факт</th>
            </tr>
            </thead>
            <tbody>

            </tbody>
        </table>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Наряд</h4>
            </div>
            <div class="modal-body">

            </div>
        </div>
    </div>
</div>

<!-- CONTACT END -->
<!-- SCRIPTS -->
<script src="../js/jquery-1.11.3.min.js" type="text/javascript"></script>
<script src="../js/bootstrap.min.js" type="text/javascript"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/js/bootstrap-datepicker.min.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script src="../js/jquery.validate.min.js" type="text/javascript"></script>
<script type="text/javascript" src="../js/sweetalert.min.js"></script>

<script>
    $(document).ready(function(){
        var date = $("#dateFilter").val();
        getDelivery('getDeliveryDate',date,<?php echo $_SESSION['gym_id'] ?>);
    });
    $(function () {
        $('#dateFilter').datepicker({
            autoclose: true,
            dateFormat: 'dd-mm-yy',
            language: 'ru',
            todayHighlight: true,
            onSelect: function() {
                var date = $("#dateFilter").val();
                getDelivery('getDeliveryDate',date,<?php echo $_SESSION['gym_id'] ?>);
            }
        });
        $.datepicker.regional['ru'] = {clearStatus: '',
            monthNames: ['Январь','Февраль','Март','Апрель','Май','Июнь',
                'Июль','Август','Сентябрь','Октябрь','Ноябрь','Декабрь'],
            monthNamesShort: ['Янв','Фев','Мар','Апр','Май','Июн',
                'Июл','Авг','Сен','Окт','Ноя','Дек'],
            dayNames: ['Воскресенье','Понедельник','Вторник','Среда','Четверг','Пятница','Суббота'],
            dayNamesShort: ['Вс','Пн','Вт','Ср','Чт','Пт','Сб'],
            dayNamesMin: ['Вс','Пн','Вт','Ср','Чт','Пт','Сб'],
            firstDay: 1 };
        $.datepicker.setDefaults($.datepicker.regional['ru']);
    });

    $(".export").click(function () {
        var date = $("#dateFilter").val();
        window.open("../actions/mpdf/deliverToPDF.php?date="+date);

    });

    function getDelivery(action,val,id) {
        var s_filter = $("#statusFilter").val();
        var d_filter = $("#dateFilter").val();
        $.ajax({
            type: "POST",
            url: "actions.php",
            data: {action:action,val:val,id:id, s_filter:s_filter, d_filter:d_filter},
            success: function(data){
                switch (action) {
                    case "getDelivery":
                        $(".modal-body").html(data);
                        break;
                    case "getDeliveryDate":
                        $("table.table tbody").html(data);
                        break;
                    case "getDeliveryStatus":
                        $("table.table tbody").html(data);
                        break;
                }

            }
        });
    }


    function toggleAddress(action, val) {

        $.ajax({
            url: "actions.php",
            data: {action:action,gym_id:val},
            type: "POST",
            success: function (data) {
                switch (action) {
                    case "getAddress":
                        if(data == "") {
                            var addr = $('.addr');
                            $(addr).html('<input class="form-control address" style="margin-top: 0" type="text" id="address"/>');
                        } else {
                            $(".addr").html(data).css("margin-top", "10px");
                        }
                        break;
                }
            }
        })
    }

    $('#address').on('input', function() {
        $("#place").val("");
    });

    function actions(action, val){
        var time1 = $("#time1").val();
        var time2 = $("#time2").val();
        var date_time = time1 + " - " +time2;
        var fact_time = $("#time3").val();
        var user_id = $("#user_id").val();
        var quantity = $("#quantity").val();
        var comment = $("#comment").val();
        var pcomment = $("#pcomment").val();
        var acomment = $("#acomment").val();
        var status = $("#statusDelivery").val();
        var place = $("#place").val();
        var address = $("#address").val();
        var address_val = $("#address_val").val();
        var courier = $("#courier").val();
        $.ajax({
            url: "actions.php",
            data: {action: action,date_time:date_time,fact_time:fact_time,user_id:user_id,calendar:val,quantity:quantity,comment:comment,pcomment:pcomment,acomment:acomment,
                status_name:status,place:place,address:address,courier:courier,address_val:address_val},
            type: "POST",
            success: function () {
                swal("Наряд успешно отредактирован", "","success");
                setTimeout(function () {
                    location.reload();
                }, 1500);
            },
            error: function () {
                swal("Наряд успешно отредактирован", "","success");
                setTimeout(function () {
                    location.reload();
                }, 1500);
            }
        })
    }

</script>
</body>
</html>
