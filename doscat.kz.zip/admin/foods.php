<?php
header('Content-type: text/html; charset=utf8');
session_start();
include("../bd.php");
$id = $_SESSION["user_id"];
$type = $_GET['type'];
?>

<!DOCTYPE html>
<html lang="zxx">
<head>

    <!-- TITLE OF SITE -->
    <title>Список рецептов</title>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0" />
    <!--[if IE]><meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1'><![endif]-->
    <meta name="author" content="bierx_87" />
    <meta name="description" content="" />
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <link rel="stylesheet/less" type="text/css" href="../css/main.less">
    <script type="text/javascript" src="../js/less.min.js"></script>
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <link rel="stylesheet" type="text/css" href="../css/font-awesome.min.css">

    <noscript>
        <strong>Warning!</strong>
        Your browser does not support HTML5 so some elements on this page are simulated using JScript. Unfortunately your browser has JScript disabled. Please enable it in order to display this page.
    </noscript>
    <style>
        .get{
            margin-top: 10px;
        }
        td span {
            margin-left: 15px;
        }
    </style>
    <link rel="stylesheet" type="text/css" href="../css/dataTable.css">
</head>
<body>

<?php
include("menuTemp.php");
?>
<!-- HEADER END -->
<div class="container block_menu text-center">
    <div id="myTabContent" class="tab-content">
        <div class="tab-pane fade active in" id="yesterday">
            <?php if($type == 1) { ?>
                <a href="addFood.php?type=1"><button class="btn btn-success">Добавить десерт</button></a>
            <?php } else { ?>
                <a href="addFood.php?type=0"><button class="btn btn-success">Добавить рецепт</button></a>
            <?php } ?>

            <table class="table table-striped table-hover " id="tablesorted" style="width: 100%">
                <thead>
                <tr>
                    <th class='th_name'>№</th>
                    <th>Фото</th>
                    <th>Название</th>
                    <?php if($type == 1) { ?>
                        <th>Ед. изм</th>
                        <th>Цена</th>
                    <?php } ?>
                    <th>Ккал</th>
                    <th>Белок</th>
                    <th>Жир</th>
                    <th>Углеводы</th>
                    <th>Замок</th>
                </tr>
                </thead>
                <tbody>
                <?php
                $resultFood = $conn->query("set names utf8");
                $sqlFood = "SELECT * FROM Foods WHERE isDessert = '$type' ORDER BY name";
                $resultFood = $conn->query($sqlFood);

                while ($rowFood = $resultFood->fetch_assoc()) { ?>
                    <tr data-toggle="modal" data-target="#myModal" style="cursor: pointer" onclick="actions('getFood',<?php echo $rowFood['id'] ?>)">
                        <input type="hidden" value="<?php echo $rowFood['id'] ?>" class="hidden" name="hidden">
                        <td><?php echo $rowFood['id'] ?></td>
                        <td><img src="<?php echo $rowFood['photo'] ?>" width="75px" height="75px"></td>
                        <td><?php echo $rowFood['name'] ?></td>
                        <?php if($type == 1) { ?>
                            <td><?php echo $rowFood['unit'] ?></td>
                            <td><?php echo $rowFood['price'] ?></td>
                        <?php } ?>
                        <td><?php echo $rowFood['kcal'] ?></td>
                        <td><?php echo $rowFood['protein'] ?></td>
                        <td><?php echo $rowFood['fat'] ?></td>
                        <td><?php echo $rowFood['carbohydrate'] ?></td>
                        <td><?php if($rowFood['isCheck'] == 1) echo '<span class="glyphicon glyphicon-lock"></span>' ?></td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <?php if($type == 1) { ?>
                    <h4 class="modal-title">Десерт</h4>
                <?php } else { ?>
                    <h4 class="modal-title">Блюдо</h4>
                <?php } ?>
            </div>
            <div class="modal-body">

            </div>
        </div>

    </div>
</div>
<!-- SCRIPTS -->
<script src="../js/jquery-1.11.3.min.js" type="text/javascript"></script>
<script src="../js/bootstrap.min.js" type="text/javascript"></script>
<script src="../js/jquery.validate.min.js" type="text/javascript"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script src="../js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.11/js/dataTables.bootstrap.min.js"></script>
<script>

    $(function(){
        $("#tablesorted").dataTable({
            "bPaginate": false,
            "bLengthChange": false
        });
    });
    function actions(action, id) {
        $.ajax({
            url: "actions.php",
            data: {action:action, food_id:id},
            type: "POST",
            success: function (data) {
                switch (action) {
                    case "getFood":
                        $(".modal-body").html(data);
                        break;
                    case "deleteFood":
                        location.reload();
                        break;

                }
            }
        });
        $("div#suggnot").remove();
    }

</script>

</body>
</html>
