<?php
header('Content-type: text/html; charset=utf8');
session_start();
include("../bd.php");

$id = $_SESSION["user_id"];
$menu_id = $_GET['id'];

?>

<!DOCTYPE html>
<html lang="zxx">
<head>

    <!-- TITLE OF SITE -->
    <title>Редактирование меню</title>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0" />
    <!--[if IE]><meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1'><![endif]-->
    <meta name="author" content="bierx_87" />
    <meta name="description" content="" />
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <link rel="stylesheet/less" type="text/css" href="../css/main.less">
    <script type="text/javascript" src="../js/less.min.js"></script>
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <noscript>
        <strong>Warning!</strong>
        Your browser does not support HTML5 so some elements on this page are simulated using JScript. Unfortunately your browser has JScript disabled. Please enable it in order to display this page.
    </noscript>

</head>
<body>

<?php
include("menuTemp.php");
?>
<!-- HEADER END -->

<div class="container block_menu text-center">
    <div id="myTabContent" class="col-md-12">
    <?php
    $resultMenu = $conn->query("set names utf8");
    $sqlMenu = "SELECT id, program_id,date_start, day_of_the_week FROM Menu WHERE id = '$menu_id'";
    $resultMenu = $conn->query($sqlMenu);

    if ($resultMenu->num_rows > 0) {
        while ($rowMenu = $resultMenu->fetch_assoc()) {
            $menuid = $rowMenu['id'];
            ?>
            <div class="col-md-4 col-md-offset-4">
                <div class="form-group">
                    <select id="program" class="form-control" required>
                        <option value="">--Выберите программу--</option>
                        <?php
                        $queryProgram = "SELECT * FROM Program";
                        $resultProgram = $conn->query($queryProgram);
                        while ($rowProgram = $resultProgram->fetch_assoc()) {
                            ?>
                            <option value="<?php echo $rowProgram["id"]; ?>" <?php if($rowMenu['program_id'] == $rowProgram["id"]) echo 'selected' ?>><?php echo $rowProgram["name"]; ?></option>
                            <?php
                        }
                        $resultProgram->close();
                        ?>
                    </select>
                </div>
            </div>
            <div class="col-md-4 col-md-offset-4">
                <div class="form-group">
                    <input value="<?php echo $rowMenu['date_start'] ?>" id="date" class="form-control" type="text" placeholder="Дата начала меню" required>
                </div>
            </div>
            <div class="col-md-4 col-md-offset-4">
                <div class="form-group">
                    <select id="day" name="day" class="form-control" required>
                        <option value="">--Выберите день недели--</option>
                        <option value="Понедельник" <?php if($rowMenu['day_of_the_week'] == 'Понедельник') echo 'selected' ?>>Понедельник</option>
                        <option value="Вторник" <?php if($rowMenu['day_of_the_week'] == 'Вторник') echo 'selected' ?>>Вторник</option>
                        <option value="Среда" <?php if($rowMenu['day_of_the_week'] == 'Среда') echo 'selected' ?>>Среда</option>
                        <option value="Четверг" <?php if($rowMenu['day_of_the_week'] == 'Четверг') echo 'selected' ?>>Четверг</option>
                        <option value="Пятница" <?php if($rowMenu['day_of_the_week'] == 'Пятница') echo 'selected' ?>>Пятница</option>
                        <option value="Суббота" <?php if($rowMenu['day_of_the_week'] == 'Суббота') echo 'selected' ?>>Суббота</option>
                        <option value="Воскресенье" <?php if($rowMenu['day_of_the_week'] == 'Воскресенье') echo 'selected' ?>>Воскресенье</option>
                    </select>
                </div>
            </div>
        <div class="col-md-8 col-md-offset-2">
            <div class="form-group">
                <table class="table" style="width: 100%">
            <?php
            $resultType = $conn->query("set names utf8");
            $sqlType = "SELECT DISTINCT m.food_type_id,f.type_name
            FROM Menu_Foods m JOIN Food_Type f ON f.id = m.food_type_id WHERE m.menu_id = '$menuid' ORDER by m.food_type_id";
            $resultType = $conn->query($sqlType);
            while($rowType = $resultType->fetch_assoc()){
                $type_id = $rowType['food_type_id'];
                $type_name = $rowType['type_name'];
                ?>
                <tbody class="body_<?php echo $type_id ?>">
                <tr>
                    <th><?php echo $type_name ?></th>
                    <th>Выход</th>
                    <th>Ккал</th>
                    <th>Белок</th>
                    <th>Жир</th>
                    <th>Углеводы</th>
                </tr>
                <?php
                $resultFood = $conn->query("set names utf8");
                $sqlFood = "SELECT f.id, m.id as mf_id,f.name, m.portion,TRUNCATE((f.kcal*m.portion/100),2) as calcKcal, TRUNCATE((f.protein*m.portion/100),2) as calcPro, TRUNCATE((f.fat*m.portion/100),2) as calcFat, TRUNCATE((f.carbohydrate*m.portion/100),2) as calcCarbo
                FROM Foods f JOIN Menu_Foods m ON f.id = m.food_id
                WHERE f.id in (SELECT food_id FROM Menu_Foods WHERE menu_id = '$menuid' and food_type_id = '$type_id') GROUP by f.id";
                $resultFood = $conn->query($sqlFood);

                while($rowFood = $resultFood->fetch_assoc()){
                    $food_id = $rowFood['id'];?>
                    <tr class="trGet trFood_<?php echo $food_id ?> type_<?php echo $type_id ?>" data-id="<?php echo $rowFood['mf_id'] ?>">
                        <input class="htype" type="hidden" value="<?php echo $type_id ?>">
                        <td>
                            <select id="sfood_<?php echo $food_id ?>" class="form-control food" required onchange="calc('get_<?php echo $food_id ?>', this.value)">
                                <?php
                                $resultSelectFood = $conn->query("set names utf8");
                                $querySelectFood = "SELECT * FROM Foods";
                                $resultSelectFood = $conn->query($querySelectFood);
                                while ($rowSelectFood = $resultSelectFood->fetch_assoc()) {
                                    ?>
                                    <option value="<?php echo $rowSelectFood["id"]; ?>" <?php if($food_id == $rowSelectFood["id"]) echo 'selected' ?>><?php echo $rowSelectFood["name"]; ?></option>
                                    <?php
                                }
                                $resultSelectFood->close();
                                ?>
                            </select>
                        </td>
                        <td><input value="<?php echo $rowFood['portion'] ?>" id="result_<?php echo $food_id ?>" class="form-control portion" type="number" placeholder="Выход" required></td>
                        <td class="ing_<?php echo $food_id ?> kcal"><?php echo $rowFood['calcKcal'] ?></td>
                        <td class="ing_<?php echo $food_id ?> protein"><?php echo $rowFood['calcPro'] ?></td>
                        <td class="ing_<?php echo $food_id ?> fat"><?php echo $rowFood['calcFat'] ?></td>
                        <td class="ing_<?php echo $food_id ?> carbo"><?php echo $rowFood['calcCarbo'] ?></td>
                    </tr>
                    <?php
                }
                ?>
                </tbody>
                <tr class="calcFood">
                    <td><span class="glyphicon glyphicon-plus plus_<?php echo $type_id ?>"></span></td>
                    <td>Калории <?php echo $type_name ?></td>
                    <td class="sumFKcal_<?php echo $type_id ?>"></td>
                    <td class="sumFPro_<?php echo $type_id ?>"></td>
                    <td class="sumFFat_<?php echo $type_id ?>"></td>
                    <td class="sumFCarbo_<?php echo $type_id ?>"></td>
                </tr>
                <?php }}} ?>
            <tr>
                <th WIDTH="25%"></th>
                <th>Всего</th>
                <th class="sumKcal"></th>
                <th class="sumPro"></th>
                <th class="sumFat"></th>
                <th class="sumCarbo"></th>
            </tr>

            </table>
        </div>
    </div>
    <div class="col-md-4 col-md-offset-4 add">
        <div class="form-group">
            <button class="btn btn-success" onclick="actions('editMenu', <?php echo $menu_id ?>);editMenu('editFoods', <?php echo $menu_id ?>)">Сохранить</button>
        </div>
    </div>
    </div>
</div>

<!-- SCRIPTS -->
<script src="../js/jquery-1.11.3.min.js" type="text/javascript"></script>
<script src="../js/bootstrap.min.js" type="text/javascript"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/js/bootstrap-datepicker.min.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script>
    $(function () {
        $('#date')
            .datepicker({
                autoclose: true,
                dateFormat: 'dd-mm-yy',
                language: 'ru',
                todayHighlight: true
            });
        $.datepicker.regional['ru'] = {clearText: 'Effacer', clearStatus: '',
            monthNames: ['Январь','Февраль','Март','Апрель','Май','Июнь',
                'Июль','Август','Сентябрь','Октябрь','Ноябрь','Декабрь'],
            monthNamesShort: ['Янв','Фев','Мар','Апр','Май','Июн',
                'Июл','Авг','Сен','Окт','Ноя','Дек'],
            dayNames: ['Воскресенье','Понедельник','Вторник','Среда','Четверг','Пятница','Суббота'],
            dayNamesShort: ['Вс','Пн','Вт','Ср','Чт','Пт','Сб'],
            dayNamesMin: ['Вс','Пн','Вт','Ср','Чт','Пт','Сб'],
            firstDay: 1 };
        $.datepicker.setDefaults($.datepicker.regional['ru']);
    });

    $(".plus_1").click(function () {
       $(".table").append(
           '<tr><td><select class="form-control food"><option>--Выберите блюдо--</option></select></td>' +
           '<td><input class="form-control portion" type="number" placeholder="Выход" required></td>' +
           '</tr>');
        getFood();
    });

    function getFood() {
        $.ajax({
            type: "GET",
            url: "../actions/getFoodsList.php",
            success: function(response){
                $(".form-control.food").append(response);
            }
        });
    }
    function actions(action, id) {
        var program = $('#program').val();
        var date = $("#date").val();
        var day = $("#day").val();

        $.ajax({
            url: "actions.php",
            data: {action: action, id:id,program: program, date: date, day: day},
            type: "POST",
            success: function (data) {
                switch (action) {
                    case "editMenu":
                        $(".col-md-4.col-md-offset-4.add").append("<div id='suggnot' class='alert-box success'>Меню успешно отредактирован</div>");
                        $( "div#suggnot" ).fadeIn( 300 ).delay( 1500 ).fadeOut( 400 );
                        break;
                }
            }
        })
    }

    function editMenu(action, id){
        $(".trGet").each(function(){
            var data_id = $(this).attr("data-id");
            var foods = $(this).find(".form-control.food").val();
            var portion = $(this).find(".form-control.portion").val();
            var food_types = $(this).find(".htype").val();
                $.ajax({
                    url: "actions.php",
                    data: {action: action,id:id,data_id:data_id,foods: foods, food_types: food_types, portion: portion},
                    type: "POST",
                    success: function () {
                        switch (action) {
                            case "editFoods":
                                break;
                        }
                    }
                })

        });
    }

    function sumFood(selector, text) {
        var sum = 0;

        $(selector).each(function() {
            sum += Number($(this).text());
        });
        return $(text).text(sum.toFixed(2));
    }

    function sumIngredients(){
        sumFood('.type_1 .kcal', '.sumFKcal_1');
        sumFood('.type_1 .protein', '.sumFPro_1');
        sumFood('.type_1 .fat', '.sumFFat_1');
        sumFood('.type_1 .carbo', '.sumFCarbo_1');
        sumFood('.type_2 .kcal', '.sumFKcal_2');
        sumFood('.type_2 .protein', '.sumFPro_2');
        sumFood('.type_2 .fat', '.sumFFat_2');
        sumFood('.type_2 .carbo', '.sumFCarbo_2');
        sumFood('.type_3 .kcal', '.sumFKcal_3');
        sumFood('.type_3 .protein', '.sumFPro_3');
        sumFood('.type_3 .fat', '.sumFFat_3');
        sumFood('.type_3 .carbo', '.sumFCarbo_3');

        sumFood('.kcal', '.sumKcal');
        sumFood('.protein', '.sumPro');
        sumFood('.fat', '.sumFat');
        sumFood('.carbo', '.sumCarbo');
    }
    $(document).ready(function () {
        sumIngredients();
    });

    function calc(action, value) {
        $("tr.trFood_"+value).each(function(){
            $.ajax({
                url: "actions.php",
                data: {action:action,food_value:value},
                type: "POST",
                success: function (data) {
                    switch (action) {
                        case "get_"+value:
                        $("tr.trFood_"+value).append(data);
                        if($("tr.trFood_"+value+" td").length > 6)
                            $("tr.trFood_"+value).find("td:eq(2),td:eq(3),td:eq(4),td:eq(5)").remove();
                        break;

                    }
                    //sumIngredients();
                }
            })
        });
    }

</script>

</body>
</html>
