<?php
header('Content-type: text/html; charset=utf8');
session_start();
include("../bd.php");
include("../actions/filter.php");
$id = $_SESSION["user_id"];
$type = filter("type");
?>

<!DOCTYPE html>
<html lang="zxx">
<head>

    <!-- TITLE OF SITE -->
    <title>Добавить меню</title>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0" />
    <!--[if IE]><meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1'><![endif]-->
    <meta name="author" content="bierx_87" />
    <meta name="description" content="" />
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <link rel="stylesheet/less" type="text/css" href="../css/main.less">
    <script type="text/javascript" src="../js/less.min.js"></script>
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <noscript>
        <strong>Warning!</strong>
        Your browser does not support HTML5 so some elements on this page are simulated using JScript. Unfortunately your browser has JScript disabled. Please enable it in order to display this page.
    </noscript>

</head>

<body>

<?php
include("menuTemp.php");
?>
<!-- HEADER END -->

<div class="container block_menu text-center">
    <div id="myTabContent" class="col-md-12">
        <div class="col-md-4 col-md-offset-4">
            <div class="form-group">
                <select id="program" class="form-control" required>
                    <option value="">--Выберите план питания--</option>
                    <?php
                    $queryProgram = "SELECT id, name, kcal FROM Program";
                    $resultProgram = $conn->query($queryProgram);
                    while ($rowProgram = $resultProgram->fetch_assoc()) {
                        ?>
                        <option
                            value="<?php echo $rowProgram["id"]; ?>"><?php echo $rowProgram["name"]." - ".$rowProgram["kcal"]; ?></option>
                        <?php
                    }
                    $resultProgram->close();
                    ?>
                </select>
            </div>
        </div>
        <div class="col-md-4 col-md-offset-4">
            <div class="form-group">
                <input id="date" class="form-control" type="text" placeholder="Дата меню" required>
            </div>
        </div>
        
        <?php if($type == 5) { ?>
        <div class="col-md-8 col-md-offset-2">
            <div class="form-group">
                <table id="fbreak" class="table" style="width: 100%">
                    <thead>
                    <tr>
                        <th>Завтрак</th>
                        <th>Выход</th>
                        <th>Ккал</th>
                        <th>Белок</th>
                        <th>Жир</th>
                        <th>Углеводы</th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr class="trGet trFFBreak">
                        <input class="htype" type="hidden" value="4">
                        <td>
                            <select class="form-control food" required onchange="calc('get_8', this.value)">
                                <option value="">--Выберите завтрак--</option>
                            </select>
                        </td>
                        <td><input id="fFBResult" class="form-control ration fbreak" type="number" placeholder="Выход" required></td>

                    </tr>
                    <tr class="trGet trSFBreak">
                        <input class="htype" type="hidden" value="4">
                        <td>
                            <select class="form-control food" required onchange="calc('get_9', this.value)">
                                <option value="">--Выберите завтрак--</option>
                            </select>
                        </td>
                        <td><input id="sFBResult" class="form-control ration fbreak" type="number" placeholder="Выход" required></td>

                    </tr>
                    <tr class="calculateFBreak">
                        <td></td>
                        <td>Калории завтрака</td>
                        <td class="sumFBreakKcal"></td>
                        <td class="sumFBreakPro"></td>
                        <td class="sumFBreakFat"></td>
                        <td class="sumFBreakCarbo"></td>
                    </tr>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="col-md-8 col-md-offset-2">
            <div class="form-group">
                <table id="sbreak" class="table" style="width: 100%">
                    <thead>
                    <tr>
                        <th>Второй завтрак</th>
                        <th>Выход</th>
                        <th>Ккал</th>
                        <th>Белок</th>
                        <th>Жир</th>
                        <th>Углеводы</th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr class="trGet trFSBreak">
                        <input class="htype" type="hidden" value="5">
                        <td>
                            <select class="form-control food" required onchange="calc('get_10', this.value)">
                                <option value="">--Выберите завтрак--</option>
                            </select>
                        </td>
                        <td><input id="fSBResult" class="form-control ration sbreak" type="number" placeholder="Выход" required></td>

                    </tr>
                    <tr class="trGet trSSBreak">
                        <input class="htype" type="hidden" value="5">
                        <td>
                            <select class="form-control food" required onchange="calc('get_11', this.value)">
                                <option value="">--Выберите завтрак--</option>
                            </select>
                        </td>
                        <td><input id="sSBResult" class="form-control ration sbreak" type="number" placeholder="Выход" required></td>

                    </tr>
                    <tr class="calculateFBreak">
                        <td></td>
                        <td>Калории второго завтрака</td>
                        <td class="sumSBreakKcal"></td>
                        <td class="sumSBreakPro"></td>
                        <td class="sumSBreakFat"></td>
                        <td class="sumSBreakCarbo"></td>
                    </tr>
                    </tbody>
                </table>
            </div>
        </div>
        <?php } ?>
        <div class="col-md-8 col-md-offset-2">
            <div class="form-group">
                <table id="lunch" class="table" style="width: 100%">
                    <thead>
                        <tr>
                            <th>Обед</th>
                            <th>Выход</th>
                            <th>Ккал</th>
                            <th>Белок</th>
                            <th>Жир</th>
                            <th>Углеводы</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr class="trGet trFLunch">
                            <input class="htype" type="hidden" value="1">
                            <td>
                                <select id="fLunch" class="form-control food" required onchange="calc('get_1', this.value)">
                                    <option value="">--Выберите блюдо--</option>

                                </select>
                            </td>
                            <td><input id="fLResult" class="form-control ration lunch" type="number" placeholder="Выход" required></td>
                        </tr>

                        <tr class="trGet trSLunch">
                            <input class="htype" type="hidden" value="1">
                            <td>
                                <select id="sLunch" class="form-control food" required onchange="calc('get_2', this.value)">
                                    <option value="">--Выберите блюдо--</option>

                                </select>
                            </td>
                            <td><input id="sLResult" class="form-control ration lunch" type="number" placeholder="Выход" required></td>
                        </tr>

                        <tr class="trGet trTLunch">
                            <input class="htype" type="hidden" value="1">
                            <td>
                                <select id="tLunch" class="form-control food" required onchange="calc('get_3', this.value)">
                                    <option value="">--Выберите блюдо--</option>

                                </select>
                            </td>
                            <td><input id="tLResult" class="form-control ration lunch" type="number" placeholder="Выход" required></td>
                        </tr>
                        <tr class="trGet trFrLunch">
                            <input class="htype" type="hidden" value="1">
                            <td>
                                <select id="frLunch" class="form-control food" required onchange="calc('get_12', this.value)">
                                    <option value="">--Выберите блюдо--</option>

                                </select>
                            </td>
                            <td><input id="frLResult" class="form-control ration lunch" type="number" placeholder="Выход" required></td>
                        </tr>

                        <tr class="calculateLunch">
                            <td></td>
                            <td>Калории обеда</td>
                            <td class="sumLunchKcal"></td>
                            <td class="sumLunchPro"></td>
                            <td class="sumLunchFat"></td>
                            <td class="sumLunchCarbo"></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="col-md-8 col-md-offset-2">
            <div class="form-group">
                <table id="snack" class="table" style="width: 100%">
                    <thead>
                    <tr>
                        <th>Полдник</th>
                        <th>Выход</th>
                        <th>Ккал</th>
                        <th>Белок</th>
                        <th>Жир</th>
                        <th>Углеводы</th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr class="trGet trFSnack">
                        <input class="htype" type="hidden" value="2">
                        <td>
                            <select id="fSnack" class="form-control food" required onchange="calc('get_4', this.value)">
                                <option value="">--Выберите полдник--</option>

                            </select>
                        </td>
                        <td><input id="fSResult" class="form-control ration snack" type="number" placeholder="Выход" required></td>

                    </tr>
                    <tr class="trGet trSSnack">
                        <input class="htype" type="hidden" value="2">
                        <td>
                            <select id="sSnack" class="form-control food" required onchange="calc('get_5', this.value)">
                                <option value="">--Выберите полдник--</option>

                            </select>
                        </td>
                        <td><input id="sSResult" class="form-control ration snack" type="number" placeholder="Выход" required></td>

                    </tr>
                    <tr class="calculateSnack">
                        <td></td>
                        <td>Калории полдника</td>
                        <td class="sumSnackKcal"></td>
                        <td class="sumSnackPro"></td>
                        <td class="sumSnackFat"></td>
                        <td class="sumSnackCarbo"></td>
                    </tr>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="col-md-8 col-md-offset-2">
            <div class="form-group">
                <table id="dinner" class="table" style="width: 100%">
                    <thead>
                    <tr>
                        <th>Ужин</th>
                        <th>Выход</th>
                        <th>Ккал</th>
                        <th>Белок</th>
                        <th>Жир</th>
                        <th>Углеводы</th>
                    </tr>
                    </thead>
                    <tbody>
                        <tr class="trGet trFDinner">
                            <input class="htype" type="hidden" value="3">
                            <td>
                                <select id="fDinner" class="form-control food" required onchange="calc('get_6', this.value)">
                                    <option value="">--Выберите блюдо--</option>

                                </select>
                            </td>
                            <td><input id="fDResult" class="form-control ration dinner" type="number" placeholder="Выход" required></td>
                        </tr>

                        <tr class="trGet trSDinner">
                            <input class="htype" type="hidden" value="3">
                            <td>
                                <select id="sDinner" class="form-control food" required onchange="calc('get_7', this.value)">
                                    <option value="">--Выберите блюдо--</option>

                                </select>
                            </td>
                            <td><input id="sDResult" class="form-control ration dinner" type="number" placeholder="Выход" required></td>
                        </tr>

                        <tr class="trGet trTDinner">
                            <input class="htype" type="hidden" value="3">
                            <td>
                                <select id="tDinner" class="form-control food" required onchange="calc('get_13', this.value)">
                                    <option value="">--Выберите блюдо--</option>

                                </select>
                            </td>
                            <td><input id="tDResult" class="form-control ration dinner" type="number" placeholder="Выход" required></td>
                        </tr>
                        <tr class="calculateDinner">
                            <td></td>
                            <td>Калории ужина</td>
                            <td class="sumDinnerKcal"></td>
                            <td class="sumDinnerPro"></td>
                            <td class="sumDinnerFat"></td>
                            <td class="sumDinnerCarbo"></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="col-md-8 col-md-offset-2">
            <div class="form-group">
                <table class="table" style="width: 100%">
                    <thead>
                    <tr>
                        <th WIDTH="25%"></th>
                        <th>Всего</th>
                        <th WIDTH="25%"></th>
                        <th class="sumKcal"></th>
                        <th class="sumPro"></th>
                        <th class="sumFat"></th>
                        <th class="sumCarbo"></th>
                    </tr>
                    </thead>
                </table>
            </div>
        </div>
        <div class="col-md-4 col-md-offset-4 add">
            <div class="form-group">
                <button class="btn btn-success" onclick="actions('addMenu');addFoods('addFoods');">Сохранить</button>
                <button class="btn btn-default">Отмена</button>
            </div>
        </div>
    </div>
</div>

<!-- SCRIPTS -->
<script src="../js/jquery-1.11.3.min.js" type="text/javascript"></script>
<script src="../js/bootstrap.min.js" type="text/javascript"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/js/bootstrap-datepicker.min.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script>
    $(function () {
        $('#date').datepicker({
            autoclose: true,
            dateFormat: 'dd-mm-yy',
            language: 'ru',
            todayHighlight: true
        });
        $.datepicker.regional['ru'] = {clearStatus: '',
            monthNames: ['Январь','Февраль','Март','Апрель','Май','Июнь',
                'Июль','Август','Сентябрь','Октябрь','Ноябрь','Декабрь'],
            monthNamesShort: ['Янв','Фев','Мар','Апр','Май','Июн',
                'Июл','Авг','Сен','Окт','Ноя','Дек'],
            dayNames: ['Воскресенье','Понедельник','Вторник','Среда','Четверг','Пятница','Суббота'],
            dayNamesShort: ['Вс','Пн','Вт','Ср','Чт','Пт','Сб'],
            dayNamesMin: ['Вс','Пн','Вт','Ср','Чт','Пт','Сб'],
            firstDay: 1 };
        $.datepicker.setDefaults($.datepicker.regional['ru']);
        getFood();
    });

    function getFood() {
        $.ajax({
            type: "GET",
            url: "../actions/getFoodsList.php",
            success: function(response){
                $(".form-control.food").append(response);
            }
        });
    }

    $.urlParam = function(name){
        var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(window.location.href);
        if (results==null){
            return null;
        }
        else{
            return results[1] || 0;
        }
    };

    $(".btn-default").click(function(){
        if($.urlParam('type') == 3) {
            window.location = "menu.php?type=3";
        } else {
            window.location = "menu.php?type=5";
        }
    });

    
    function actions(action) {
        var program = $('#program').val();
        var date = $("#date").val();
        var numKcal = $("#numKcal").val();
        var kcal  = $(".sumKcal").text();
        var pro  = $(".sumPro").text();
        var fat  = $(".sumFat").text();
        var carbo  = $(".sumCarbo").text();
        var type = $.urlParam('type');
        if(program == "") {
            alert("Выберите программу");
        } else if (date == "") {
            alert("Выберите дату");
        } else {
            $.ajax({
                url: "actions.php",
                data: {
                    action: action,
                    program: program,
                    date: date,
                    numKcal: numKcal,
                    kcal: kcal,
                    pro: pro,
                    fat: fat,
                    carbo: carbo,
                    menu_type: type
                },
                type: "POST",
                success: function (data) {
                    switch (action) {
                        case "addMenu":
                            $(".col-md-4.col-md-offset-4.add").append("<div id='suggnot' class='alert-box success'>Меню успешно добавлен</div>");
                            $("div#suggnot").fadeIn(300).delay(1500).fadeOut(400);
                            $(".btn-success").button({disabled: true});
                            break;
                    }
                }
            })
        }
    }

    function addFoods(action){
        $(".trGet").each(function(){
            var foods = $(this).find(".form-control.food").val();
            var portion = $(this).find(".form-control.ration").val();
            var food_types = $(this).find(".htype").val();
            if(foods!='' && foods!=null && portion!=null && food_types!=null) {
                $.ajax({
                    url: "actions.php",
                    data: {action: action,foods: foods, food_types: food_types, portion: portion},
                    type: "POST",
                    success: function () {
                        setTimeout(function(){
                            if($.urlParam('type') == 3) {
                                window.location = "menu.php?type=3";
                            } else {
                                window.location = "menu.php?type=5";
                            }
                        }, 500);
                    }
                })
            }
        });
    }

    function calc(action, value) {
        $.ajax({
            url: "actions.php",
            data: {action:action,food_value:value},
            type: "POST",
            success: function (data) {
                switch (action) {
                    case "get_1":
                        $("tr.trFLunch").append(data);
                        if($("tr.trFLunch td").length > 6) {
                            $("tr.trFLunch").find("td:eq(2),td:eq(3),td:eq(4),td:eq(5)").remove();
                            $("tr.trFLunch").find("input:eq(2),input:eq(3),input:eq(4),input:eq(5)").remove();
                        }
                        break;
                    case "get_2":
                        $("tr.trSLunch").append(data);
                        if($("tr.trSLunch td").length > 6) {
                            $("tr.trSLunch").find("td:eq(2),td:eq(3),td:eq(4),td:eq(5)").remove();
                            $("tr.trSLunch").find("input:eq(2),input:eq(3),input:eq(4),input:eq(5)").remove();
                        }
                        break;
                    case "get_3":
                        $("tr.trTLunch").append(data);
                        if($("tr.trTLunch td").length > 6) {
                            $("tr.trTLunch").find("td:eq(2),td:eq(3),td:eq(4),td:eq(5)").remove();
                            $("tr.trTLunch").find("input:eq(2),input:eq(3),input:eq(4),input:eq(5)").remove();
                        }
                        break;
                    case "get_4":
                        $("tr.trFSnack").append(data);
                        if($("tr.trFSnack td").length > 6) {
                            $("tr.trFSnack").find("td:eq(2),td:eq(3),td:eq(4),td:eq(5)").remove();
                            $("tr.trFSnack").find("input:eq(2),input:eq(3),input:eq(4),input:eq(5)").remove();
                        }
                        break;
                    case "get_5":
                        $("tr.trSSnack").append(data);
                        if($("tr.trSSnack td").length > 6) {
                            $("tr.trSSnack").find("td:eq(2),td:eq(3),td:eq(4),td:eq(5)").remove();
                            $("tr.trSSnack").find("input:eq(2),input:eq(3),input:eq(4),input:eq(5)").remove();
                        }
                        break;
                    case "get_6":
                        $("tr.trFDinner").append(data);
                        if($("tr.trFDinner td").length > 6) {
                            $("tr.trFDinner").find("td:eq(2),td:eq(3),td:eq(4),td:eq(5)").remove();
                            $("tr.trFDinner").find("input:eq(2),input:eq(3),input:eq(4),input:eq(5)").remove();
                        }
                        break;
                    case "get_7":
                        $("tr.trSDinner").append(data);
                        if($("tr.trSDinner td").length > 6) {
                            $("tr.trSDinner").find("td:eq(2),td:eq(3),td:eq(4),td:eq(5)").remove();
                            $("tr.trSDinner").find("input:eq(2),input:eq(3),input:eq(4),input:eq(5)").remove();
                        }
                        break;
                    case "get_8":
                        $("tr.trFFBreak").append(data);
                        if($("tr.trFFBreak td").length > 6) {
                            $("tr.trFFBreak").find("td:eq(2),td:eq(3),td:eq(4),td:eq(5)").remove();
                            $("tr.trFFBreak").find("input:eq(2),input:eq(3),input:eq(4),input:eq(5)").remove();
                        }
                            break;
                    case "get_9":
                        $("tr.trSFBreak").append(data);
                        if($("tr.trSFBreak td").length > 6) {
                            $("tr.trSFBreak").find("td:eq(2),td:eq(3),td:eq(4),td:eq(5)").remove();
                            $("tr.trSFBreak").find("input:eq(2),input:eq(3),input:eq(4),input:eq(5)").remove();
                        }
                        break;
                    case "get_10":
                        $("tr.trFSBreak").append(data);
                        if($("tr.trFSBreak td").length > 6) {
                            $("tr.trFSBreak").find("td:eq(2),td:eq(3),td:eq(4),td:eq(5)").remove();
                            $("tr.trFSBreak").find("input:eq(2),input:eq(3),input:eq(4),input:eq(5)").remove();
                        }
                        break;
                    case "get_11":
                        $("tr.trSSBreak").append(data);
                        if($("tr.trSSBreak td").length > 6) {
                            $("tr.trSSBreak").find("td:eq(2),td:eq(3),td:eq(4),td:eq(5)").remove();
                            $("tr.trSSBreak").find("input:eq(2),input:eq(3),input:eq(4),input:eq(5)").remove();
                        }
                        break;
                    case "get_12":
                        $("tr.trFrLunch").append(data);
                        if($("tr.trFrLunch td").length > 6) {
                            $("tr.trFrLunch").find("td:eq(2),td:eq(3),td:eq(4),td:eq(5)").remove();
                            $("tr.trFrLunch").find("input:eq(2),input:eq(3),input:eq(4),input:eq(5)").remove();
                        }
                        break;
                    case "get_13":
                        $("tr.trTDinner").append(data);
                        if($("tr.trTDinner td").length > 6) {
                            $("tr.trTDinner").find("td:eq(2),td:eq(3),td:eq(4),td:eq(5)").remove();
                            $("tr.trTDinner").find("input:eq(2),input:eq(3),input:eq(4),input:eq(5)").remove();
                        }
                        break;
                    }

                function sumFood(weight,selector, text) {
                    $(weight).keyup(function() {
                        var sum = 0;

                        $(selector).each(function() {
                            sum += parseFloat($(this).text());
                        });
                        return $(text).text(sum.toFixed(2));
                    });
                }
                sumFood("input.fbreak",'#fbreak .kcal', '.sumFBreakKcal');
                sumFood("input.fbreak",'#fbreak .protein', '.sumFBreakPro');
                sumFood("input.fbreak",'#fbreak .fat', '.sumFBreakFat');
                sumFood("input.fbreak",'#fbreak .carbo', '.sumFBreakCarbo');
                sumFood("input.sbreak",'#sbreak .kcal', '.sumSBreakKcal');
                sumFood("input.sbreak",'#sbreak .protein', '.sumSBreakPro');
                sumFood("input.sbreak",'#sbreak .fat', '.sumSBreakFat');
                sumFood("input.sbreak",'#sbreak .carbo', '.sumSBreakCarbo');

                sumFood("input.lunch",'#lunch .kcal', '.sumLunchKcal');
                sumFood("input.lunch",'#lunch .protein', '.sumLunchPro');
                sumFood("input.lunch",'#lunch .fat', '.sumLunchFat');
                sumFood("input.lunch",'#lunch .carbo', '.sumLunchCarbo');
                sumFood("input.snack",'#snack .kcal', '.sumSnackKcal');
                sumFood("input.snack",'#snack .protein', '.sumSnackPro');
                sumFood("input.snack",'#snack .fat', '.sumSnackFat');
                sumFood("input.snack",'#snack .carbo', '.sumSnackCarbo');
                sumFood("input.dinner",'#dinner .kcal', '.sumDinnerKcal');
                sumFood("input.dinner",'#dinner .protein', '.sumDinnerPro');
                sumFood("input.dinner",'#dinner .fat', '.sumDinnerFat');
                sumFood("input.dinner",'#dinner .carbo', '.sumDinnerCarbo');

                sumFood('input','.kcal', '.sumKcal');
                sumFood('input','.protein', '.sumPro');
                sumFood('input','.fat', '.sumFat');
                sumFood('input','.carbo', '.sumCarbo');
            }
        })
    }

    function calcIngredient(weight, selector, weightVal, hiddenVal) {
        var calc = 0;
        $(weight).keyup(function() {
            calc = $(selector).html((parseFloat($(weightVal).val())*parseFloat($(hiddenVal).val())/100).toFixed(2));
            if($(".ration").val() == ""){
                $("tr.kcal").text(0);
                $("tr.protein").text(0);
                $("tr.fat").text(0);
                $("tr.carbo").text(0);
            }
            return calc;
        });
    }

    calcIngredient("#fLResult",".trFLunch .kcal","#fLResult",".trFLunch .hKcal");
    calcIngredient("#fLResult",".trFLunch .protein","#fLResult",".trFLunch .hProtein");
    calcIngredient("#fLResult",".trFLunch .fat","#fLResult",".trFLunch .hFat");
    calcIngredient("#fLResult",".trFLunch .carbo","#fLResult",".trFLunch .hCarbo");
    calcIngredient("#sLResult",".trSLunch .kcal","#sLResult",".trSLunch .hKcal");
    calcIngredient("#sLResult",".trSLunch .protein","#sLResult",".trSLunch .hProtein");
    calcIngredient("#sLResult",".trSLunch .fat","#sLResult",".trSLunch .hFat");
    calcIngredient("#sLResult",".trSLunch .carbo","#sLResult",".trSLunch .hCarbo");
    calcIngredient("#tLResult",".trTLunch .kcal","#tLResult",".trTLunch .hKcal");
    calcIngredient("#tLResult",".trTLunch .protein","#tLResult",".trTLunch .hProtein");
    calcIngredient("#tLResult",".trTLunch .fat","#tLResult",".trTLunch .hFat");
    calcIngredient("#tLResult",".trTLunch .carbo","#tLResult",".trTLunch .hCarbo");
    calcIngredient("#frLResult",".trFrLunch .kcal","#frLResult",".trFrLunch .hKcal");
    calcIngredient("#frLResult",".trFrLunch .protein","#frLResult",".trFrLunch .hProtein");
    calcIngredient("#frLResult",".trFrLunch .fat","#frLResult",".trFrLunch .hFat");
    calcIngredient("#frLResult",".trFrLunch .carbo","#frLResult",".trFrLunch .hCarbo");

    calcIngredient("#fSResult",".trFSnack .kcal","#fSResult",".trFSnack .hKcal");
    calcIngredient("#fSResult",".trFSnack .protein","#fSResult",".trFSnack .hProtein");
    calcIngredient("#fSResult",".trFSnack .fat","#fSResult",".trFSnack .hFat");
    calcIngredient("#fSResult",".trFSnack .carbo","#fSResult",".trFSnack .hCarbo");
    calcIngredient("#sSResult",".trSSnack .kcal","#sSResult",".trSSnack .hKcal");
    calcIngredient("#sSResult",".trSSnack .protein","#sSResult",".trSSnack .hProtein");
    calcIngredient("#sSResult",".trSSnack .fat","#sSResult",".trSSnack .hFat");
    calcIngredient("#sSResult",".trSSnack .carbo","#sSResult",".trSSnack .hCarbo");

    calcIngredient("#fDResult",".trFDinner .kcal","#fDResult",".trFDinner .hKcal");
    calcIngredient("#fDResult",".trFDinner .protein","#fDResult",".trFDinner .hProtein");
    calcIngredient("#fDResult",".trFDinner .fat","#fDResult",".trFDinner .hFat");
    calcIngredient("#fDResult",".trFDinner .carbo","#fDResult",".trFDinner .hCarbo");
    calcIngredient("#sDResult",".trSDinner .kcal","#sDResult",".trSDinner .hKcal");
    calcIngredient("#sDResult",".trSDinner .protein","#sDResult",".trSDinner .hProtein");
    calcIngredient("#sDResult",".trSDinner .fat","#sDResult",".trSDinner .hFat");
    calcIngredient("#sDResult",".trSDinner .carbo","#sDResult",".trSDinner .hCarbo");
    calcIngredient("#tDResult",".trTDinner .kcal","#tDResult",".trTDinner .hKcal");
    calcIngredient("#tDResult",".trTDinner .protein","#tDResult",".trTDinner .hProtein");
    calcIngredient("#tDResult",".trTDinner .fat","#tDResult",".trTDinner .hFat");
    calcIngredient("#tDResult",".trTDinner .carbo","#tDResult",".trTDinner .hCarbo");

    calcIngredient("#fFBResult",".trFFBreak .kcal","#fFBResult",".trFFBreak .hKcal");
    calcIngredient("#fFBResult",".trFFBreak .protein","#fFBResult",".trFFBreak .hProtein");
    calcIngredient("#fFBResult",".trFFBreak .fat","#fFBResult",".trFFBreak .hFat");
    calcIngredient("#fFBResult",".trFFBreak .carbo","#fFBResult",".trFFBreak .hCarbo");
    calcIngredient("#sFBResult",".trSFBreak .kcal","#sFBResult",".trSFBreak .hKcal");
    calcIngredient("#sFBResult",".trSFBreak .protein","#sFBResult",".trSFBreak .hProtein");
    calcIngredient("#sFBResult",".trSFBreak .fat","#sFBResult",".trSFBreak .hFat");
    calcIngredient("#sFBResult",".trSFBreak .carbo","#sFBResult",".trSFBreak .hCarbo");

    calcIngredient("#fSBResult",".trFSBreak .kcal","#fSBResult",".trFSBreak .hKcal");
    calcIngredient("#fSBResult",".trFSBreak .protein","#fSBResult",".trFSBreak .hProtein");
    calcIngredient("#fSBResult",".trFSBreak .fat","#fSBResult",".trFSBreak .hFat");
    calcIngredient("#fSBResult",".trFSBreak .carbo","#fSBResult",".trFSBreak .hCarbo");
    calcIngredient("#sSBResult",".trSSBreak .kcal","#sSBResult",".trSSBreak .hKcal");
    calcIngredient("#sSBResult",".trSSBreak .protein","#sSBResult",".trSSBreak .hProtein");
    calcIngredient("#sSBResult",".trSSBreak .fat","#sSBResult",".trSSBreak .hFat");
    calcIngredient("#sSBResult",".trSSBreak .carbo","#sSBResult",".trSSBreak .hCarbo");
</script>

</body>
</html>
