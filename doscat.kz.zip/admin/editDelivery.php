<?php
//ini_set('error_reporting', E_ALL);
//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);
header('Content-type: text/html; charset=utf8');
session_start();
$status = $_SESSION['status'];
$id = $_SESSION["user_id"];
$c_id = $_GET['id'];
include("../bd.php");
$result = $conn->query("set names utf8");
$query ="SELECT c.id, c.date, u.custom_address,u.address_1,u.address_2, (SELECT name FROM Gyms WHERE id = u.id_gym) as 'gym_name',(SELECT address FROM Gyms WHERE id = u.id_gym) as 'gym',
u.id as 'user_id',u.first_name, u.last_name, u.phone, u.id_gym, (SELECT (SELECT name FROM Program WHERE id = program_id) as 'name' FROM Product WHERE id = (SELECT product_id FROM Plans WHERE id = c.plan_id)) as 'plan',
(SELECT quantity FROM Delivery WHERE calendar_id = c.id) as 'quantity', (SELECT comment FROM Delivery WHERE calendar_id = c.id) as 'comment',
(SELECT partner_comment FROM Delivery WHERE calendar_id = c.id) as 'pcomment',(SELECT admin_comment FROM Delivery WHERE calendar_id = c.id) as 'acomment',
(SELECT date_time FROM Delivery WHERE calendar_id = c.id) as 'time', (SELECT status FROM Delivery WHERE calendar_id = c.id) as 'status',
(SELECT courier FROM Delivery WHERE calendar_id = c.id) as 'courier', (SELECT fact_time FROM Delivery WHERE calendar_id = c.id) as 'fact_time'
FROM Calendars c JOIN Users u ON u.id = (SELECT user_id FROM Plans WHERE id = c.plan_id) WHERE c.id = '$c_id'";
$result = $conn->query($query);
$row = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="zxx">
<head>

    <!-- TITLE OF SITE -->
    <title>Редактировать наряд</title>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0" />
    <!--[if IE]><meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1'><![endif]-->
    <meta name="author" content="bierx_87" />
    <meta name="description" content="" />

    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <link rel="stylesheet/less" type="text/css" href="../css/main.less">
    <script type="text/javascript" src="../js/less.min.js"></script>
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <link rel="stylesheet" media="all" type="text/css" href="../css/jquery-ui-timepicker-addon.css" />
    <noscript>
        <strong>Warning!</strong>
        Your browser does not support HTML5 so some elements on this page are simulated using JScript. Unfortunately your browser has JScript disabled. Please enable it in order to display this page.
    </noscript>
    <style>
        .get{
            margin-top: 10px;
        }
        .block_menu .nav-tabs {
            margin-left: 30%;
            margin-top: 10px;
        }
        .block_menu .nav-tabs li {
            width: auto;
            border: 1px;
        }
        .block_menu .nav-tabs li a {
            font-size: 16px;
        }
        .col-lg-12.text-center p {
            display: inline-block;
            font-size: 16px;
        }
        p.name {
            margin-right: 100px;
        }
    </style>
</head>

<body>

<!-- HEADER -->
<?php
include("menuTemp.php");
?>
<!-- HEADER END -->
<div class="container block_menu text-center">
    <div id="myTabContent" class="col-md-12">
        <div class="form">
            <form class="form-horizontal" data-toggle="validator" id="form">
                <fieldset>
                    <p style="font-size: 17px"><b>Наряд на доставку</b></p><br>
                    <div class="form-group">
                        <div class="col-lg-12 text-center">
                            <?php echo "<a href='../profile.php?id=".$row['user_id']."'><p class='name'>" . $row['first_name']." ".$row['last_name'] . "</p></a>";?>
                            <?php
                            $date = DateTime::createFromFormat('Y-m-d',$row['date']);
                            $date_request = $date->format("d-m-Y");
                            echo "<p class='date'>" . $date_request . "</p>";?>
                            <input type="hidden" id="status" value="<?php echo $status ?>">
                        </div>
                    </div>

                    <ul class="nav nav-tabs" style="margin-bottom: 20px">
                        <li class="home"><a data-toggle="tab" href="#home">Наряд</a></li>
                        <?php if($status == 1) { ?><li class="menu1"><a data-toggle="tab" href="#menu1">Отметки Dostyk Catering</a></li><?php } ?>
                        <li class="menu2"><a data-toggle="tab" href="#menu2">Отметки партнера</a></li>
                    </ul>
                    <div class="tab-content">
                        <div id="home" class="tab-pane fade">
                            <div class="form-group">
                                <label for="inputClient" class="col-lg-4 control-label">Клиент (имя, фамилия):</label>
                                <div class="col-lg-4 text-left">
                                    <?php echo "<p class='get'>" . $row['first_name']." ".$row['last_name'] . "</p>";?>
                                    <input type="hidden" id="user_id" value="<?php echo $row['user_id'] ?>">
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="inputPhone" class="col-lg-4 control-label">Телефон:</label>
                                <div class="col-lg-4 text-left">
                                    <?php echo "<p class='get'>" . $row['phone'] . "</p>";?>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="inputPlan" class="col-lg-4 control-label">План питания:</label>
                                <div class="col-lg-4 text-left">
                                    <?php echo "<p class='get'>" . $row['plan'] . "</p>";?>
                                </div>
                            </div>


                            <div class="form-group">
                                <label for="inputTime" class="col-lg-4 control-label">Кол-во:</label>
                                <div class="col-lg-4 text-left">
                                    <input class="form-control quantity" id="quantity" placeholder="Количество" type="text" value="<?php if($row['quantity'] != '0'){echo $row['quantity'];} else{echo '1';} if(!isset($row['quantity'])){echo '1';} ?>">
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="inputPlace" class="col-lg-4 control-label">Место доставки:</label>
                                <div class="col-lg-4 text-left">
                                    <?php if($status == 1){?>
                                        <select class="form-control" id="place" onchange="toggleAddress('getAddress',this.value)">
                                            <option value="">--Свой адрес--</option>
                                            <?php
                                            $queryGym = "SELECT * FROM Gyms";
                                            $resultGym = $conn->query($queryGym);
                                            while ($rowGym = $resultGym->fetch_assoc()) { ?>
                                                <option value="<?php echo $rowGym["id"]; ?>"<?php if($rowGym["id"] == $row['id_gym']) echo 'selected' ?>><?php echo $rowGym["name"]; ?></option>
                                            <?php } ?>
                                        </select>
                                    <?php }else{ ?>
                                        <?php echo "<p class='get'>" . $row["gym_name"]. "</p>";?>
                                    <?php } ?>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="inputAddress" class="col-lg-4 control-label">Адрес доставки:</label>
                                <div class="col-lg-4 text-left addr">
                                    <?php if($status == 1) {
                                        if (empty($row['address_1']) && empty($row['address_2'])) { ?>
                                            <input class="form-control address" id="address" placeholder="Адрес доставки" type="text" value="<?php echo $row['gym'];if ($row['id_gym'] == 0) echo $row['custom_address'] ?>">
                                        <?php } else {
                                            ?>
                                            <select class="form-control" id="address_val">
                                                <option value="">--Адресы--</option>
                                                <option value="1"><?php echo $row["custom_address"] ?></option>
                                                <?php if(!empty($row["address_1"])){ ?><option value="2"><?php echo $row["address_1"] ?></option><?php } ?>
                                                <?php if(!empty($row["address_2"])){ ?><option value="3"><?php echo $row["address_2"] ?></option><?php } ?>
                                            </select>
                                        <?php }
                                    }
                                    else{ ?>
                                        <?php echo "<p class='get'>" . $row["gym"]. "</p>";if($row['id_gym'] == 0) {echo "<p class='get'>" . $row["custom_address"]. "</p>";}?>
                                    <?php } ?>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="inputTime" class="col-lg-4 control-label">Курьер:</label>
                                <div class="col-lg-4 text-left">
                                    <?php if($status == 1){?>
                                        <select class="form-control" id="courier">
                                            <option value="">--Курьер--</option>
                                            <?php
                                            $queryCourier = "SELECT * FROM Users WHERE user_status=3";
                                            $resultCourier = $conn->query($queryCourier);
                                            while ($rowCourier = $resultCourier->fetch_assoc()) { ?>
                                                <option value="<?php echo $rowCourier["id"]; ?>"<?php if($rowCourier["id"] == $row['courier']) echo 'selected' ?>><?php echo $rowCourier["first_name"]." ".$rowCourier["last_name"]; ?></option>
                                            <?php } ?>
                                        </select>
                                    <?php }else{ ?>
                                        <?php echo "<p class='get'>" . $rowCourier["first_name"]." ".$rowCourier["last_name"] . "</p>";?>
                                    <?php } ?>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="inputTime" class="col-lg-4 control-label">Время план:</label>
                                <?php if($status == 1){
                                    $e = explode(" - ", $row['time']); ?>
                                    <div class="col-lg-2 text-left">
                                        <input class="form-control time" id="time1" placeholder="Время" type="text" value="<?php echo $e[0] ?>">
                                    </div>

                                    <div class="col-lg-2 text-left">
                                        <input class="form-control time" id="time2" placeholder="Время" type="text" value="<?php echo $e[1] ?>">
                                    </div>
                                <?php } else {?>
                                    <div class="col-lg-4 text-left">
                                        <?php echo "<p id='plan_time' class='get'>" . $row['time'] . "</p>";?>

                                    </div>
                                <?php } ?>

                            </div>
                            <div class="form-group">
                                <label for="inputDate" class="col-lg-4 control-label">Дата доставки:</label>
                                <div class="col-lg-4 text-left">
                                    <?php
                                    echo "<p class='get'>" . $date_request . "</p>";?>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="inputTime" class="col-lg-4 control-label">Номер наряда:</label>
                                <div class="col-lg-4 text-left">
                                    <?php echo "<p id='calendar' class='get'>" . $c_id . "</p>";?>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="inputStatus" class="col-lg-4 control-label">Статус доставки:</label>
                                <div class="col-lg-4">
                                    <select class="form-control" id="statusDelivery">
                                        <option value="">--Статус наряда--</option>
                                        <option value="1"<?php if($row['status'] == 1) echo 'selected' ?>>Доставлено</option>
                                        <option value="0"<?php if($row['status'] == 0) echo 'selected' ?>>Не доставлено</option>
                                    </select>
                                </div>
                            </div>

                        </div>
                        <div id="menu1" class="tab-pane fade">
                            <?php if($status == 1) {?>
                                <p style="font-size: 17px"><b>Отметки администратора Dostyk Catering</b></p>

                                <div class="form-group">
                                    <label for="inputTime" class="col-lg-4 control-label">Время факт:</label>

                                    <div class="col-lg-4 text-left">
                                        <?php if($status == 1){?>
                                            <input class="form-control time" id="time3" placeholder="Время факт" type="text" value="<?php echo $row['fact_time'] ?>">
                                        <?php }else{ ?>
                                            <?php echo "<p class='get'>" . $row['fact_time'] . "</p>";?>
                                        <?php } ?>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="inputComment" class="col-lg-4 control-label">Комментарий:</label>
                                    <div class="col-lg-4 text-left">
                                        <textarea class="form-control acomment" id="acomment"><?php echo $row['acomment'] ?></textarea>
                                    </div>
                                </div>
                            <?php } ?>

                        </div>
                        <div id="menu2" class="tab-pane fade">
                            <p style="font-size: 17px"><b>Отметки администратора Партнера</b></p>

                            <div class="form-group">
                                <label for="inputComment" class="col-lg-4 control-label">Комментарий:</label>
                                <div class="col-lg-4 text-left">
                                    <?php if($status == 2){?>
                                        <textarea class="form-control pcomment" id="pcomment"><?php echo $row["pcomment"]; ?></textarea>
                                    <?php }else{ ?>
                                        <?php echo "<p class='get'>" . $row["pcomment"]. "</p>";?>
                                    <?php } ?>
                                </div>
                            </div>

                        </div>
                    </div>

                    <div class="form-group text-center add">
                        <div class="col-lg-12">
                            <button type="submit" class="btn btn-success submit" onclick="actions('editDelivery',<?php echo $row['id'] ?>)">Сохранить</button>
                        </div>
                    </div>

                </fieldset>
            </form>
        </div>
    </div>
</div>

<!-- CONTACT END -->

<!-- SCRIPTS -->
<script src="../js/jquery-1.11.3.min.js" type="text/javascript"></script>
<script src="../js/bootstrap.min.js" type="text/javascript"></script>
<script src="../js/jquery.validate.min.js" type="text/javascript"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script type="text/javascript" src="../js/jquery-ui-timepicker-addon.js"></script>
<script type="text/javascript" src="../js/jquery-ui-timepicker-addon-i18n.min.js"></script>
<script type="text/javascript" src="../js/jquery.maskedinput.js"></script>

<script>
    $(function () {
        $(".time").timepicker($.timepicker.regional['ru']);
        var status = $("#status").val();
        if(status == 1) {
            $(".home").addClass("active");
            $("#home").addClass("in active");
        } else {
            $(".menu2").addClass("active");
            $("#menu2").addClass("in active");
        }
    });

    function toggleAddress(action, val) {

        $.ajax({
            url: "actions.php",
            data: {action:action,gym_id:val},
            type: "POST",
            success: function (data) {
                switch (action) {
                    case "getAddress":
                        if(data == "") {
                            var addr = $('.addr');
                            $(addr).html('<input class="form-control address" type="text" id="address"/>');
                        } else {
                            $(".addr").html(data).css("margin-top", "10px");
                        }
                        break;
                }
            }
        })
    }

    $('#address').on('input', function() {
        $("#place").val("");
    });

    $.urlParam = function(name){
        var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(window.location.href);
        if (results==null){
            return null;
        }
        else{
            return results[1] || 0;
        }
    };

    function actions(action, val){
        var time1 = $("#time1").val();
        var time2 = $("#time2").val();
        var date_time = time1 + " - " +time2;
        var fact_time = $("#time3").val();
        var user_id = $("#user_id").val();
        var quantity = $("#quantity").val();
        var comment = $("#comment").val();
        var pcomment = $("#pcomment").val();
        var acomment = $("#acomment").val();
        var status = $("#statusDelivery").val();
        var place = $("#place").val();
        var address = $("#address").val();
        var address_val = $("#address_val").val();
        var courier = $("#courier").val();
        var get_url = $.urlParam('c');
        $.ajax({
            url: "actions.php",
            data: {action: action,date_time:date_time,fact_time:fact_time,user_id:user_id,calendar:val,quantity:quantity,comment:comment,pcomment:pcomment,acomment:acomment,
                status_name:status,place:place,address:address,courier:courier,address_val:address_val},
            type: "POST",
            success: function (data) {
                if(get_url != null){
                    window.location = "../calendar.php?id="+get_url;
                } else {
                    window.location = "delivery.php";
                }
            },
            error: function (data) {
                if(get_url!= null){
                    window.location = "../calendar.php?id"+get_url;
                } else {
                    window.location = "delivery.php";
                }
            }
        })
    }
</script>
</body>
</html>


