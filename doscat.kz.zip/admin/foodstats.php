<?php
header('Content-type: text/html; charset=utf8');
session_start();
include("../bd.php");
$id = $_SESSION["user_id"];
?>

<!DOCTYPE html>
<html lang="zxx">
<head>

    <!-- TITLE OF SITE -->
    <title>Статистика блюд</title>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0" />
    <!--[if IE]><meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1'><![endif]-->
    <meta name="author" content="bierx_87" />
    <meta name="description" content="" />
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <link rel="stylesheet/less" type="text/css" href="../css/main.less">
    <script type="text/javascript" src="../js/less.min.js"></script>
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <link rel="stylesheet" type="text/css" href="../css/font-awesome.min.css">

    <noscript>
        <strong>Warning!</strong>
        Your browser does not support HTML5 so some elements on this page are simulated using JScript. Unfortunately your browser has JScript disabled. Please enable it in order to display this page.
    </noscript>
    <link rel="stylesheet" type="text/css" href="../css/dataTable.css">
</head>

<body>

<!-- HEADER -->
<?php
include("menuTemp.php");
?>
<!-- HEADER END -->
<div class="container block_menu text-center">
    <div id="myTabContent" class="tab-content">

        <table class="table table-striped table-hover " id="tablesorted">
            <thead>
            <tr>
                <th>Название</th>
                <th>3-х разовое меню</th>
                <th>5-разовое меню</th>
            </tr>
            </thead>
            <tbody>
            <?php
            $resultFood = $conn->query("set names utf8");
            $sqlFood = "SELECT * FROM Foods";
            $resultFood = $conn->query($sqlFood);

            while ($rowFood = $resultFood->fetch_assoc()) {
                $food_name = $rowFood['name'];
                $food_id = $rowFood['id'];
                echo '<tr><td style="width: 40%">'.$food_name.'</td>';
                $resultCount1 = $conn->query("set names utf8");
                $sqlCount1 = "SELECT COUNT(food_id) as food_count1 FROM Menu_Foods mf JOIN Menu m ON mf.menu_id = m.id WHERE food_id = '$food_id' AND m.type = 3";
                $resultCount1 = $conn->query($sqlCount1);
                while ($rowCount1 = $resultCount1->fetch_assoc()){

                    ?>
                        <td class="c3"><?php echo $rowCount1['food_count1'] ?></td>
                <?php }

                $resultCount2 = $conn->query("set names utf8");
                $sqlCount2 = "SELECT COUNT(food_id) as food_count2 FROM Menu_Foods mf JOIN Menu m ON mf.menu_id = m.id WHERE food_id = '$food_id' AND m.type = 5";
                $resultCount2 = $conn->query($sqlCount2);
                while ($rowCount2 = $resultCount2->fetch_assoc()){

                    ?>
                    <td class="c5"><?php echo $rowCount2['food_count2'] ?></td>
                <?php }
            echo '</tr>';
            }?>
            </tbody>
        </table>
    </div>
</div>

<!-- SCRIPTS -->
<script src="../js/jquery-1.11.3.min.js" type="text/javascript"></script>
<script src="../js/bootstrap.min.js" type="text/javascript"></script>
<script src="../js/jquery.validate.min.js" type="text/javascript"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script src="../js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.11/js/dataTables.bootstrap.min.js"></script>
<script>

    $(function(){
        $("#tablesorted").dataTable({
            "bPaginate": false,
            "bLengthChange": false
        });
    });

    function actions(action, id) {
        $.ajax({
            url: "actions.php",
            data: {action:action, gym_id:id},
            type: "POST",
            success: function (data) {
                switch (action) {
                    /*case "getGym":
                     $(".modal-body").html(data);
                     break;*/
                    case "deleteGym":
                        location.reload();
                        break;
                }
            }
        });
    }

    $(".glyphicon-trash").click(function(){
        if(!confirm("Вы хотите удалить?"))
            return false;
    });

</script>

</body>
</html>
