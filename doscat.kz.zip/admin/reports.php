<?php
header('Content-type: text/html; charset=utf8');
session_start();
$status = $_SESSION['status'];
$gym_id = $_SESSION['gym_id'];
include("../bd.php");

?>

<!DOCTYPE html>
<html lang="zxx">
<head>

    <!-- TITLE OF SITE -->
    <title>Отчеты</title>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0" />
    <!--[if IE]><meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1'><![endif]-->
    <meta name="author" content="bierx_87" />
    <meta name="description" content="" />

    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <link rel="stylesheet/less" type="text/css" href="../css/main.less">
    <script type="text/javascript" src="../js/less.min.js"></script>
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">

    <noscript>
        <strong>Warning!</strong>
        Your browser does not support HTML5 so some elements on this page are simulated using JScript. Unfortunately your browser has JScript disabled. Please enable it in order to display this page.
    </noscript>
    <style>
        .get{
            margin-top: 10px;
        }
        .form-control{
            display: inline-block;
            max-width: 250px;
            margin-top: 20px;;
        }
        .row-all-project h4 {
            border-bottom: 2px solid #dddddd;
            padding: 10px 15px;
            margin: 0;
            color: black;
        }
        .row-all-project a {
            border-bottom: 1px solid #dddddd;
            padding: 7px 10px;
            margin: 0;
            display: block;
            text-shadow: none;
        }
        #f_range, #s_range {
            display: none;
        }
        .col-lg-4.diapazon {
            margin-right: -265px;
            margin-top: 20px;
        }
    </style>
</head>

<body>

<?php
include("menuTemp.php");
?>
<!-- HEADER END -->
<div class="container block_menu text-center">
    <div id="myTabContent" class="tab-content">

        <div class="panel-title" style="font-size: 20px;text-align: center;margin-top: 15px;"><span>Статистика активных клиентов</span></div>
        <?php if($status == 1) { ?>
            <select class="form-control" id="gymFilter" onchange="getDelivery('getDeliverySalesGym',this.value)">
                <option value="">--Все спортзалы--</option>
                <?php
                $qGym = "SELECT name, id FROM Gyms";
                $rGym = $conn->query($qGym);
                while ($rowGym = $rGym->fetch_assoc()) { ?>
                    <option value="<?php echo $rowGym["id"]; ?>"><?php echo $rowGym["name"]; ?> </option>
                <?php } ?>
            </select>
        <?php } ?>

        <button class="btn btn-success export">Экспорт в PDF</button>

        <table class="table table-hover " id="tablesorted" style="width: 100%">
            <tr>
                <th width="13%">Спортзал</th>
                <th>Активных</th>
                <th>Неактивных</th>
                <th>Итого</th>
            </tr>
            <tbody>
            <?php
            $resultGym = $conn->query("set names utf8");
            $queryGym = "SELECT * FROM Gyms";

            $resultGym = $conn->query($queryGym);
            while ($rowGym = $resultGym->fetch_assoc()) {
            $gym_id = $rowGym['id'];
            $gym_name = $rowGym['name'];
                echo '<tr><td>'.$gym_name.'</td>';
                $resultCount1 = $conn->query("set names utf8");
                $queryCount1 = "SELECT COUNT(DISTINCT p.user_id) as 'count1' FROM Plans p JOIN Calendars c WHERE p.user_id in (SELECT id FROM Users WHERE id_gym = '$gym_id') AND c.date >= CURDATE()";

                $resultCount1 = $conn->query($queryCount1);
                while ($rowCount1 = $resultCount1->fetch_assoc()) {
                    ?>
                    <td class="c3"><?php echo $rowCount1['count1'] ?></td>
                    <?php
                }

                $resultCount2 = $conn->query("set names utf8");
                $queryCount2 = "SELECT COUNT(DISTINCT p.user_id) as 'count2' FROM Plans p JOIN Calendars c WHERE p.user_id in (SELECT id FROM Users WHERE id_gym = '$gym_id') AND c.date <= CURDATE()";

                $resultCount2 = $conn->query($queryCount2);
                while ($rowCount2 = $resultCount2->fetch_assoc()) {
                    ?>
                    <td class="c5"><?php echo $rowCount2['count2'] ?></td>
                    <?php
                }
                echo '</tr>';
            }
            $resultGym->close();
            ?>
            </tbody>
        </table>
    </div>
</div>

<!-- CONTACT END -->
<!-- SCRIPTS -->
<script src="../js/jquery-1.11.3.min.js" type="text/javascript"></script>
<script src="../js/bootstrap.min.js" type="text/javascript"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/js/bootstrap-datepicker.min.js"></script>
<script src="../js/jquery.validate.min.js" type="text/javascript"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script>

    $(function () {
        $('#dateFilter').datepicker({
            autoclose: true,
            dateFormat: 'dd-mm-yy',
            language: 'ru',
            todayHighlight: true,
            onSelect: function() {
                var date = $("#dateFilter").val();
                getDelivery('getDeliverySalesDate',date,<?php echo $_SESSION['gym_id'] ?>);
            }
        });
        $('#f_range, #s_range').datepicker({
            autoclose: true,
            dateFormat: 'dd-mm-yy',
            language: 'ru',
            todayHighlight: true
        });
        $.datepicker.regional['ru'] = {clearStatus: '',
            monthNames: ['Январь','Февраль','Март','Апрель','Май','Июнь',
                'Июль','Август','Сентябрь','Октябрь','Ноябрь','Декабрь'],
            monthNamesShort: ['Янв','Фев','Мар','Апр','Май','Июн',
                'Июл','Авг','Сен','Окт','Ноя','Дек'],
            dayNames: ['Воскресенье','Понедельник','Вторник','Среда','Четверг','Пятница','Суббота'],
            dayNamesShort: ['Вс','Пн','Вт','Ср','Чт','Пт','Сб'],
            dayNamesMin: ['Вс','Пн','Вт','Ср','Чт','Пт','Сб'],
            firstDay: 1 };
        $.datepicker.setDefaults($.datepicker.regional['ru']);

        var date = $("#dateFilter").val();
        getDelivery('getDeliverySalesDate',date,<?php echo $_SESSION['gym_id'] ?>);
    });

    $(".export").click(function () {
        var date = $("#dateFilter").val();
        var dateAr = date.split('-');
        var newDate = dateAr[2] + '-' + dateAr[1] + '-' + dateAr[0];
        var gym = $("#gymFilter").val();
        if(date == "" && gym == "") {
            window.open("../actions/mpdf/salesToPDF.php");
        } else if(date != "" && gym == "") {
            window.open("../actions/mpdf/salesToPDF.php?d="+newDate);
        } else if(gym != null && date == "") {
            window.open("../actions/mpdf/salesToPDF.php?g="+gym);
        }  else if(gym != null && date != "") {
            window.open("../actions/mpdf/salesToPDF.php?g="+gym+"&d="+newDate);
        }

    });

    $(".toggle").click(function () {
        $("#f_range, #s_range").toggle();

    });

    $("#f_range, #s_range").change(function(){
        if($("#f_range").val() != "" && $("#s_range").val() != "") {
            $(".toggle").replaceWith('<button class="btn btn-success rangeBtn">Фильтр</button>');
            $(".rangeBtn").click(function () {
                var f_range = $("#f_range").val();
                var s_range = $("#s_range").val();
                getDelivery("getDeliverySalesRange", f_range, s_range);
            });

        }
    });

    function getDelivery(action,val,id) {
        var date = $("#dateFilter").val();
        var dateAr = date.split('-');
        var newDate = dateAr[2] + '-' + dateAr[1] + '-' + dateAr[0];
        var gym = $("#gymFilter").val();
        $.ajax({
            type: "POST",
            url: "actions.php",
            data: {action:action,val:val,id:id,gym:gym,filter_date:date,newDate:newDate},
            success: function(data){
                switch (action) {
                    case "getDelivery":
                        $(".modal-body").html(data);
                        break;
                    case "getDeliverySalesDate":
                        $("table.table tbody").html(data);
                        break;
                    case "getDeliverySalesGym":
                        $("table.table tbody").html(data);
                        break;
                    case "getDeliverySalesRange":
                        $("table.table tbody").html(data);
                        $(".rangeBtn").replaceWith('<button class="btn btn-default toggle">Выбрать диапазон</button>');
                        //$("#f_range, #s_range").hide();
                        break;
                }
            }
        });
    }
</script>
</body>
</html>
