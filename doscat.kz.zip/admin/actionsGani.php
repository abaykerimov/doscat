<?php
header('Content-type: text/html; charset=utf8');
session_start();
include("../bd.php");
include("../actions/filter.php");
include("../actions/functions.php");
$id = $_SESSION["user_id"];
$resultUser = $conn->query("set names utf8");
$sqlUser = "SELECT * FROM Users WHERE id = '$id'";
$resultUser = $conn->query($sqlUser);
$rowUser = $resultUser->fetch_assoc();
$user_status = $rowUser['user_status'];

$photo = filter('photo');
$name = filter('name');
$description = filter('description');
$kcal = filter('kcal');
$protein = filter('protein');
$fat = filter('fat');
$carbo = filter('carbo');

$action = $_POST["action"];
$food_id = $_POST["food_id"];
$menu_id = $_POST["menu_id"];
$food_value = $_POST["food_value"];
if (!empty($action)) {
    switch ($action) {

        case "getDescriptions":
            $description = filter ("program_id");
            if (!empty($description)){
                $result = $conn->query("set names utf8");
                $query = "SELECT  photo,description, name FROM Program WHERE id = '$description'";
                $result = $conn->query($query);
                while ($row = $result->fetch_assoc()) { ?>
                <div class="form-group" style="margin-top: -20px;">
                    <h3><?php echo $row["name"]?> </h3>

                    <div class="col-lg-8 " style = "margin-left: 57px; width: 90%; height: auto;">
                        <img src="<?php echo $row["photo"] ?>" width="640px"; height="360px"  >
                    </div>
                </div>
                <br>

                <div class="form-group">
                    <div class="col-lg-8 " style = "margin-left: 57px; margin-top:20px;width: 90%; height: auto;">
                      <textarea rows="10" name="text" style="color:black; resize: none; margin-left: 5px; padding-left: 10px; max-width: 390px; width: 100%;"  disabled><?php echo $row["description"] ?></textarea>
                    </div>
                </div>

                <div class="form-group">
                    <div class="col-lg-8 " style = "margin-left: 25%;">
                      <div style="text-align: center;"> <button type="submit" class="btn btn-warning sendzakaz" style = "">Заказать</button></div>
                   </div>
                </div>
                <?php
                }
                $result->close();
            }
            break;

        case "getPrice":
            $description = filter("program_id");
            $value = filter("value");
            $type = filter("type");
            if (!empty($description)) {
                $result = $conn->query("set names utf8");
                $query = "SELECT MIN(P.price) as price, MAX(P.price) as maxprice, P.type as type, P.amount_days, PP.name, P.program_id FROM Program PP, Product P WHERE
                PP.id = P.program_id and P.type = '$type' and P.program_id = '$description' and P.amount_days BETWEEN 0 and '$value'";
                $result = $conn->query($query);
                while ($row = $result->fetch_assoc()) {
                    echo $row["price"];
                    echo "_";
                    echo $row['maxprice'];
                    echo "_";
                    echo 0;
                }
            }
            $result->close();
            break;

            case "getSinglePriceForCheckbox":
            $description = filter("program_id");
            $value = 1;
            $type = filter("type");
            if (!empty($description)){
                $result = $conn->query("set names utf8");
                $query = "SELECT MIN(P.price) as price, MAX(P.price) as maxprice, P.type as type, P.amount_days, PP.name, P.program_id FROM Program PP, Product P WHERE
                PP.id = P.program_id and P.type = '$type' and P.program_id = '$description' and P.amount_days BETWEEN 0 and '$value'";
                $result = $conn->query($query);
                while ($row = $result->fetch_assoc()) {
                    echo $row['maxprice'];
                    echo "_";
                    echo 0;
                }
            }
            $result->close();
            break;

        case "getSinglePrice":
            $description = filter("program_id");
            $value = 1;
            $type = filter("type");
            if (!empty($description)) {
                $result = $conn->query("set names utf8");
                $query = "SELECT MIN(P.price) as price, MAX(P.price) as maxprice, P.type as type, P.amount_days, PP.name, P.program_id FROM Program PP, Product P WHERE
                PP.id = P.program_id and P.type = '$type' and P.program_id = '$description' and P.amount_days BETWEEN 0 and '$value'";
                $result = $conn->query($query);
                while ($row = $result->fetch_assoc()) {
                    echo $row['maxprice'];
                    echo "_";
                    echo 0;
                }
            }
            $result->close();
            break;
        case "changeTypeInbox":
            $value = filter("value");
            if ($value == 0)
            {
                ?>
                    <div class="form-group">
                        <div class="col-lg-8 " style = "margin-left: 25%;">
                            <div style="text-align: center;"> <button type="submit" class="btn btn-warning sendzakaz" style = "">Заказать</button></div>
                        </div>
                    </div>
                <?php
                $result->close();
            }
            else
            {
                ?>
                <h1>Это надпись число один</h1>
                    <?php
                $result->close();

            }
            break;
    }
}
?>