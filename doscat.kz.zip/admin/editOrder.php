<?php
header('Content-type: text/html; charset=utf8');
session_start();
$status = $_SESSION["status"];
$id = $_SESSION["user_id"];
$order_id = $_GET['id'];
include("../bd.php");
$result = $conn->query("set names utf8");
$query ="SELECT p.id, u.id as user_id, u.first_name, u.last_name, u.phone, u.id_gym,u.custom_address,(SELECT address FROM Gyms WHERE id = u.id_gym) as gym_address, sip.name as status_name, (SELECT pp.name FROM Program pp WHERE pp.id = (SELECT program_id FROM Product WHERE id = p.product_id)) as product_name, p.date, p.price, p.days, (SELECT name FROM Delivery_inPlans WHERE id = p.delivery) as delivery_name, p.delivery, p.status FROM Plans p JOIN Users u ON u.id = p.user_id JOIN Status_inPlans sip ON sip.id = p.status WHERE p.id = '$order_id'";
$result = $conn->query($query);
$row = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="zxx">
<head>

    <!-- TITLE OF SITE -->
    <title>Редактировать заявку</title>


    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0" />
    <!--[if IE]><meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1'><![endif]-->
    <meta name="author" content="bierx_87" />
    <meta name="description" content="" />

    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <link rel="stylesheet/less" type="text/css" href="../css/main.less">
    <script type="text/javascript" src="../js/less.min.js"></script>
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <link rel="stylesheet" media="all" type="text/css" href="../css/jquery-ui-timepicker-addon.css" />


    <noscript>
        <strong>Warning!</strong>
        Your browser does not support HTML5 so some elements on this page are simulated using JScript. Unfortunately your browser has JScript disabled. Please enable it in order to display this page.
    </noscript>
    <style>
        .col-md-6.col-md-offset-2 {
            margin-bottom: 15px;
        }
        #sport,#address,.sportaddress {
            display: none;
        }
        .sportaddress {
            margin-top: 7px;
        }
        .get{
            margin-top: 10px;
        }
    </style>
</head>

<body>

<!-- HEADER -->
<?php
include("menuTemp.php");
?>
<!-- HEADER END -->
<div class="container block_menu text-center">
    <div id="myTabContent" class="col-md-12">
        <div class="form">
            <form class="form-horizontal" data-toggle="validator" id="form">
                <fieldset>
                    <p style="font-size: 17px"><b>Заявка на питание</b></p>
                    <hr>
                    <div class="form-group">
                        <label for="inputDate" class="col-lg-4 control-label">Дата покупки:</label>
                        <div class="col-lg-4 text-left">
                            <p class="get"><?php $date = DateTime::createFromFormat('Y-m-d',$row['date']);
                                $date_request = $date->format("d-m-Y");
                                echo $date_request ?></p>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="inputClient" class="col-lg-4 control-label">Имя:</label>
                        <div class="col-lg-4 text-left">
                            <a href="../profile.php?id=<?php echo $row['user_id'] ?>"> <p class="get"><?php echo $row['first_name'] ?></p></a>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="inputClient" class="col-lg-4 control-label">Фамилия:</label>
                        <div class="col-lg-4 text-left">
                            <a href="../profile.php?id=<?php echo $row['user_id'] ?>"><p class="get"><?php echo $row['last_name'] ?></p></a>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="inputPhone" class="col-lg-4 control-label">Телефон:</label>
                        <div class="col-lg-4 text-left">
                            <p class="get"><?php echo $row['phone'] ?></p>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="inputPlan" class="col-lg-4 control-label">План питания:</label>
                        <div class="col-lg-4 text-left">
                            <p class="get"><?php echo $row['product_name'] ?></p>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="inputPlace" class="col-lg-4 control-label">Тип доставки:</label>
                        <div class="col-lg-4 text-left">
                            <p class="get"><?php echo $row['delivery_name'] ?></p>
                        </div>
                    </div>

                    <!--
                    <div class="form-group">
                        <label for="inputComment" class="col-lg-4 control-label">Комментарий:</label>
                        <div class="col-lg-4">
                            <textarea class="form-control rcomment" id="rcomment"></textarea>
                        </div>
                    </div>
                    -->
                    <!--<hr>
                    <p style="font-size: 17px"><b>Отметки администратора Партнера</b></p>

                    <div class="form-group">
                        <label for="inputComment" class="col-lg-4 control-label">Комментарий:</label>
                        <div class="col-lg-4">
                            <textarea class="form-control comment" id="comment"></textarea>
                        </div>
                    </div>-->
                    <?php if($status == 1) {?>
                        <hr>
                        <p style="font-size: 17px"><b>Отметки администратора Dostyk Catering</b></p>

                        <div class="form-group">
                            <label for="inputStatus" class="col-lg-4 control-label">Статус заявки:</label>
                            <div class="col-lg-4 text-left">
                                <select class="form-control" id="status">
                                    <?php
                                    $qSiP = "SELECT * FROM Status_inPlans";
                                    $rSiP = $conn->query($qSiP);
                                    while ($rowSiP = $rSiP->fetch_assoc()) { ?>
                                        <option value="<?php echo $rowSiP["id"]; ?>"<?php if($rowSiP["id"] == $row['status']) echo 'selected' ?>><?php echo $rowSiP["name"]; ?></option>
                                    <?php } ?>
                                </select>
                            </div>
                        </div>

                    <!--<div class="form-group">
                            <label for="inputComment" class="col-lg-4 control-label">Комментарий:</label>
                            <div class="col-lg-4">
                                <textarea class="form-control acomment" id="acomment"></textarea>
                            </div>
                        </div>-->
                    <?php } ?>

                    <div class="form-group text-center add">
                        <div class="col-lg-12">
                            <button type="submit" class="btn btn-success submit" onclick="actions('editOrder',<?php echo $order_id ?>)">Сохранить</button>
                        </div>
                    </div>

                </fieldset>
            </form>
        </div>
    </div>
</div>

<!-- CONTACT END -->

<!-- SCRIPTS -->
<script src="../js/jquery-1.11.3.min.js" type="text/javascript"></script>
<script src="../js/bootstrap.min.js" type="text/javascript"></script>
<script src="../js/jquery.validate.min.js" type="text/javascript"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script type="text/javascript" src="../js/jquery-ui-timepicker-addon.js"></script>
<script type="text/javascript" src="../js/jquery-ui-timepicker-addon-i18n.min.js"></script>
<script type="text/javascript" src="../js/jquery.maskedinput.js"></script>

<script>
    $(function () {
        $('#date').datepicker({
            autoclose: true,
            dateFormat: 'dd-mm-yy',
            language: 'ru',
            todayHighlight: true
        });
        $.datepicker.regional['ru'] = {clearStatus: '',
            monthNames: ['Январь','Февраль','Март','Апрель','Май','Июнь',
                'Июль','Август','Сентябрь','Октябрь','Ноябрь','Декабрь'],
            monthNamesShort: ['Янв','Фев','Мар','Апр','Май','Июн',
                'Июл','Авг','Сен','Окт','Ноя','Дек'],
            dayNames: ['Воскресенье','Понедельник','Вторник','Среда','Четверг','Пятница','Суббота'],
            dayNamesShort: ['Вс','Пн','Вт','Ср','Чт','Пт','Сб'],
            dayNamesMin: ['Вс','Пн','Вт','Ср','Чт','Пт','Сб'],
            firstDay: 1 };
        $.datepicker.setDefaults($.datepicker.regional['ru']);
        $("#time").timepicker($.timepicker.regional['ru']);
        $("#phone").mask("+7 (999) 999-99-99");
    });

    function toggleAddress(){
        if($("#place").val() == "2"){
            $("#sport").css("display", "block");
            $(".sportaddress").css("display", "block");
            $("#address").css("display", "none");
            $("#address").val('');
        } else {
            $("#address").css("display", "block");
            $("#sport").css("display", "none");
            $("#sport").val('');
            $(".sportaddress").css("display", "none");
        }
    }
    $("#place").change(function(){
        toggleAddress();
    });

    $(document).ready(function () {
        toggleAddress();
    });

    function getAddress(action, value) {
        $.ajax({
            url: "actions.php",
            data: {action:action,gym_id:value},
            type: "POST",
            success: function (data) {
                switch (action) {
                    case "getAddress":
                        $(".sportaddress").html(data);
                        break;
                }
            }
        })
    }

    function actions(action, id){
        var request_date = $("#date").val();
        var request_time = $("#time").val();
        var first_name = $("#user_name").val();
        var last_name = $("#user_lname").val();
        var phone = $("#phone").val();
        var plan = $("#plan").val();
        var sport = $("#sport").val();
        var address = $("#address").val();
        var rcomment = $("#rcomment").val();
        var comment = $("#comment").val();
        var status = $("#status").val();
        var register = $("#register").val();
        var subscribe = $("#subscribe").val();
        var acomment = $("#acomment").val();
        $.ajax({
            url: "actions.php",
            data: {action: action,order_id:id,status:status},
            type: "POST",
            success: function (data) {
                switch (action) {
                    case "editOrder":
                        $(".add").append("<div id='suggnot' class='alert-box success'>Заявка успешно отредактирована</div>");
                        $( "div#suggnot" ).fadeIn( 300 ).delay( 1500 ).fadeOut( 400 );
                        window.location = "index.php";
                        break;
                }
            }
        })
    }
</script>
</body>
</html>


