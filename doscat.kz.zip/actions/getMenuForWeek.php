<?php
$id = $_SESSION["user_id"];
$select_date = $_POST["select_date"];
//SELECT id, (SELECT name FROM Program WHERE id = `program_id`) as `program`, `menu_number`, `day_of_the_week` FROM `Menu` WHERE date_start = ?
include("../bd.php");
if (!empty($_POST["select_date"])){
$resultMenu = $conn->query("set names utf8");
$sqlMenu = "SELECT id, (SELECT name FROM Program WHERE id = program_id) as program, menu_number,date_start,kcal,protein,fat,carbo FROM Menu WHERE date_start = '$select_date' ORDER BY date_start";
$resultMenu = $conn->query($sqlMenu);
$count = 0;
while ($rowMenu = $resultMenu->fetch_assoc()) {
$menu_id = $rowMenu['id'];

$result = $conn->query("set names utf8");
$sql = "SELECT DISTINCT food_type_id, (SELECT type_name FROM Food_Type WHERE id=food_type_id) as name FROM Menu_Foods m JOIN Food_Type ft ON ft.id=m.food_type_id WHERE menu_id = '$menu_id' ORDER BY ft.sort";
$result = $conn->query($sql);
if ($result->num_rows > 0 && $result->num_rows == $_POST["get_type"]){

if ($count == 0) {
?>

<thead>
<tr>
    <th class='th_name' style="width: 5%">№</th>
    <th width="10%">Дата недели</th>
    <?php
    while ($row = $result->fetch_assoc()) {
        ?>
        <!--SELECT DISTINCT `food_type_id` FROM `Menu_Foods`
        WHERE `menu_id` in (SELECT id FROM Menu WHERE date_start = "2017-01-09") ORDER by `food_type_id`
        запомни в переменную число количество -->
        <th><?php echo $row['name'] ?></th>
    <?php } ?>
    <th>Ккал</th>
    <th>Белок</th>
    <th>Жир</th>
    <th>Угл</th>
</tr>
</thead>
<tbody>
<?php
$count++;
}
$date = DateTime::createFromFormat('Y-m-d', $rowMenu['date_start']);
$date_start = $date->format("d-m-y"); ?>
<tr data-toggle="modal" data-target="#myModal" style="cursor: pointer"
    onclick="actions('getMenu',<?php echo $rowMenu['id'] ?>)">
    <td><?php echo $rowMenu['id'] ?></td>
    <td width="20%"><?php echo $date_start ?><br>
        <?php $day = date('l', strtotime($rowMenu['date_start']));
        if ($day == "Monday") {
            $day = "Понедельник";
        } else if ($day == "Tuesday") {
            $day = "Вторник";
        } else if ($day == "Wednesday") {
            $day = "Среда";
        } else if ($day == "Thursday") {
            $day = "Четверг";
        } else if ($day == "Friday") {
            $day = "Пятница";
        } else if ($day == "Saturday") {
            $day = "Суббота";
        } else if ($day == "Sunday") {
            $day = "Воскресенье";
        }
        echo $day;?><br>
        <?php echo $rowMenu['program'] ?></td>
    <?php
    $resultType = $conn->query("set names utf8");
    $sqlType = "SELECT DISTINCT food_type_id
    FROM Menu_Foods m JOIN Food_Type ft ON ft.id=m.food_type_id WHERE menu_id = '$menu_id' ORDER by ft.sort";

    $resultType = $conn->query($sqlType);
    if ($resultType->num_rows > 0){
    while ($rowType = $resultType->fetch_assoc()) {
        //здесь сравнить переменную с размером массива
        echo '<td>';
        $type_id = $rowType['food_type_id'];
        $resultFood = $conn->query("set names utf8");
        $sqlFood = "SELECT f.id, f.name, m.portion,TRUNCATE((f.kcal*m.portion/100),2) as calcKcal, TRUNCATE((f.protein*m.portion/100),2) as calcPro,
        TRUNCATE((f.fat*m.portion/100),2) as calcFat, TRUNCATE((f.carbohydrate*m.portion/100),2) as calcCarbo
        FROM Menu_Foods m JOIN Foods f ON f.id = m.food_id
        WHERE m.menu_id = '$menu_id' and m.food_type_id = '$type_id'";
        $resultFood = $conn->query($sqlFood);

        while ($rowFood = $resultFood->fetch_assoc()) {
            ?>
            <div class="col-md-12"
                 style="margin-bottom: 10px;padding-left: 0;"><?php echo $rowFood['name'] ?></div>
        <?php }
        echo "</td>";
    } ?>
    <td class="kcal"><?php echo $rowMenu['kcal'] ?></td>
    <td class="protein"><?php echo $rowMenu['protein'] ?></td>
    <td class="fat"><?php echo $rowMenu['fat'] ?></td>
    <td class="carbo"><?php echo $rowMenu['carbo'] ?></td>
</tr>
<?php }}}
echo '</tbody>';
}
?>
<script>
    $(".glyphicon.glyphicon-trash").click(function () {
        if (!confirm("Вы хотите удалить?")) {
            return false;
        }
    });
</script>
