<?php
session_start();
ini_set('error_reporting', E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
include("../bd.php");
include("filter.php");
include('../phpmailer/PHPMailerAutoload.php');
include('functions.php');
$confirm = filter('confirm');

$id = filter("user_id");
$id_product = filter('id_product');

//новые поля
$date_start = filter('date_start');
$days = filter('days');
//во первых проверим, авторизован ли пользователь и правильные ли данные он нам отправил
if (!empty($id_product) and !empty($id) and !empty($date_start) and !empty($days)) {

    $data = array();

    //подключим наши  функции и получим информацию о тарифе пользователя

    $active_plan = active($id);
    $balance = balance($id);



    //достанем стоимость тарифа
    $query_cost = $conn->prepare("SELECT price, amount_days, description2, freezing FROM Product WHERE id = ?");
    $query_cost->bind_param('i', $id_product);
    $query_cost->execute();
    $query_cost->store_result();
    if ($query_cost->num_rows > 0) {
        $query_cost->bind_result($price,$amount_days, $product_name,$freezing);
        while ($query_cost->fetch()) {
            $cost_product = $price*$amount_days;
        }
    }
    $query_cost->close();

    $data = create_calendar($id,$id_product,$price,$days,$freezing,$active_plan,$product_name,$date_start,3);


} else {
    //если мы сюда попади, значит пользователь не авторизован, но данные в сессию мы записали, значит напишем ответ
    $data[] = array(
        'status' => 'ERROR',
        'message' => "Ошибка, попробуйте обновить страницу!",
        'confirm' => false
    );
}



    echo json_encode($data);

?>