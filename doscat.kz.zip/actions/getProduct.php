<?php
require_once("../bd.php");
if(!empty($_POST["program_id"])) {
    $results = $conn->query("set names utf8");
    $query ="SELECT * FROM Product WHERE program_id = '" . $_POST["program_id"] . "'";
    $results = $conn->query($query);
    while($row = $results->fetch_assoc()){
    ?>
        <option value="<?php echo $row["id"]; ?>"><?php echo $row["name"]; ?></option>
        <?php
    }
}
?>