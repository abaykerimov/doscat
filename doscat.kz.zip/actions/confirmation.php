<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title>Подтверждение регистрации - DosCat.kz</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png">
    <link rel="icon" type="image/png" href="/favicon-32x32.png" sizes="32x32">
    <link rel="icon" type="image/png" href="/favicon-16x16.png" sizes="16x16">
    <link rel="manifest" href="/manifest.json">
    <link rel="mask-icon" href="/safari-pinned-tab.svg" color="#5bbad5">
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <link rel="stylesheet" href="/resources/demos/style.css">
    <meta name="theme-color" content="#ffffff">
</head>
<body>
<?php
//ini_set('error_reporting', E_ALL);
//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);
include("../bd.php");
include("filter.php");
require '../phpmailer/PHPMailerAutoload.php';
include('functions.php');
include('password.php');

if (isset($_GET['real'])) {
    $real = $_GET['real'];
    $real = stripslashes($real);
    $real = htmlspecialchars($real);
    $real = trim($real);
    if ($real == '' or !check_length($real, 60, 70)) {
        unset($real);
    }
}
if (isset($_GET['email'])) {
    $email = $_GET["email"];
    $email = stripslashes($email);
    $email = htmlspecialchars($email);
//удаляем лишние пробелы
    $email = trim($email);
    if ($email == '' or !check_length($email, 6, 31) or !preg_match("|^[-0-9a-z_\.]+@[-0-9a-z_^\.]+\.[a-z]{2,6}$|i", $email)) {
        unset($email);
        echo 'Неправильно введен e-mail адрес.';
    }
}
if (isset($real) and isset($email)) {


    $query_cost = $conn->prepare("SELECT id, phone, last_name FROM Users WHERE email = ? and modified = 0");
    $query_cost->bind_param('s', $email);
    $query_cost->execute();
    $query_cost->store_result();
    if ($query_cost->num_rows > 0) {
        $query_cost->bind_result($user_id,$phone,$last_name);
        while ($query_cost->fetch()) {
            $key = "3730625f574c333933655467504476693946724d5e4c6173505960";
            $bd_link = $email.$phone.$last_name.$key;

            if (password_verify($bd_link,$real)) {

                $randompass = randomPassword();
                $p = md5(md5($randompass . md5(sha1($randompass))));

                $insert_row = $conn->prepare('UPDATE Users SET password = ?, modified = now() WHERE id = ?');
                $insert_row->bind_param('si', $p, $user_id);
                $insert_row->execute();
                $insert_row->close();

                $mail = new PHPMailer;
                $message = "Здравствуйте ".$last_name.". <br>
Данные для входа в личный кабинет:<br><br>
Страница входа: <a href='http://doscat.kz/login.php'>http://doscat.kz/login.php</a><br>
Логин/E-mail: ".$email."<br>
Пароль: ".$randompass."<br>
<br><br>С уважением, команда DosCat.kz
";
                $mail->isSMTP();
                $mail->Host = 'mail.doscat.kz';  // Specify main and backup SMTP servers
                $mail->SMTPAuth = true;
                $mail->Username = 'ok@doscat.kz';
                $mail->Password = 'iKqd24_8';
                $mail->SMTPSecure = 'ssl';
                $mail->Port = 465;
                $mail->From = 'ok@doscat.kz';
                $mail->FromName = 'ok@doscat.kz';
                $mail->addAddress($email);
                //$mail->addAddress('zhkiro@gmail.com');
                //$mail->addAddress('kozhaly@gmail.com');
                //$mail->addAddress('art.denis@mail.ru');
                $mail->CharSet = "UTF-8";
                $mail->Subject = 'Данные для входа в личный кабинет DosCat.kz';
                $mail->Body = $message;
                $mail->ClearCustomHeaders();
                $mail->isHTML(true);
                $mail->send();

                echo "Личный кабинет создан. Пароль и логин отправлены на Вашу почту - ".$email;

            } else {
                //если пароли не сошлись
                exit ("Ошибка, попробуйте снова.");
            }
        }
    } else {
        //если пароли не сошлись
        exit ("Пользователь не найден или действие уже было совершено!");
    }
    $query_cost->close();
    $conn->close();


} else {
    echo 'Недостаточно данных.';
}
?>
</body>
</html>
