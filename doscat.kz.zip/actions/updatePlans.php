<?php
session_start();
ini_set('error_reporting', E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
include("../bd.php");
include("filter.php");
include('functions.php');

$id = $_SESSION["user_id"];
if (!isset($id) and !is_numeric($id)) {
    header("Location: login.php");
}

$id_plan = filter('id_plan');
$status = filter('status');
$type = filter('type');

$data = array();

if (!empty($id_plan) and !empty($id) and ($_SESSION['status'] == 1 || $_SESSION['status'] == 2)) {

    if ($type == "update" and !empty($status)) {
        $query = $conn->prepare('UPDATE Plans SET status = ? WHERE id = ?');
        $query->bind_param('ii', $status,$id_plan);
        $query->execute();
        if ($conn->errno) {
            die('Select Error (' . $conn->errno . ') ' . $conn->error);
        } else {
            $data[] = array(
                'status' => 'SUCCESS',
                'message' => "Статус поменялся.",
                'confirm' => false
            );
        }
        $query->close();
    }

    if ($type == "delete" and empty($status)) {
        //надо проверить - есть ли такой план, и есть ли от него зависимости
        $query_plan = $conn->prepare("SELECT count(id) FROM Delivery WHERE status = 1 and calendar_id in (SELECT id FROM Calendars WHERE plan_id = ?)");
        $query_plan->bind_param('i', $id_plan);
        $query_plan->execute();
        $query_plan->store_result();
        if ($query_plan->num_rows > 0) {
            $query_plan->bind_result($countDev);
            while ($query_plan->fetch()) {

                if ($countDev > 0) {

                    $data[] = array(
                        'status' => 'ERROR',
                        'message' => "У данного плана питания, есть дни, в которые была совершена доставка! Удаление запрещено!",
                        'confirm' => false
                    );

                } else {
                    //надо удалить все дни из Delivery
                    $query = $conn->prepare('DELETE FROM Delivery WHERE calendar_id in (SELECT id FROM Calendars WHERE plan_id = ?)');
                    $query->bind_param('i', $id_plan);
                    $query->execute();
                    if ($conn->errno) {
                        die('Select Error (' . $conn->errno . ') ' . $conn->error);
                    }
                    $query->close();

                    //надо удалить все дни из Calendars
                    $query = $conn->prepare('DELETE FROM Calendars WHERE plan_id  = ?');
                    $query->bind_param('i', $id_plan);
                    $query->execute();
                    if ($conn->errno) {
                        die('Select Error (' . $conn->errno . ') ' . $conn->error);
                    }
                    $query->close();

                    //надо удалить из Calendars
                    $query = $conn->prepare('DELETE FROM Plans WHERE id  = ?');
                    $query->bind_param('i', $id_plan);
                    $query->execute();
                    if ($conn->errno) {
                        die('Select Error (' . $conn->errno . ') ' . $conn->error);
                    }
                    $query->close();

                    $data[] = array(
                        'status' => 'SUCCESS',
                        'message' => "Запись успешно удалена!",
                        'confirm' => false
                    );
                }

            }

        }
        $query_plan->close();
    }

} else {
    $data[] = array(
        'status' => 'ERROR',
        'message' => "Ошибка, попробуйте обновить страницу!",
        'confirm' => false
    );
}

echo json_encode($data);

?>