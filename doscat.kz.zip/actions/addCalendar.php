<?php
session_start();
$id = $_SESSION["user_id"];
$status = $_SESSION["status"];
ini_set('error_reporting', E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
include("../bd.php");
include("filter.php");
include('../phpmailer/PHPMailerAutoload.php');

$date = filter('date');


//во первых проверим, авторизован ли пользователь и правильные ли данные он нам отправил
if (!empty($date) and !empty($id)) {

    $data = array();

    //подключим наши  функции и получим информацию о тарифе пользователя
    include('functions.php');
    $active_plan = active($id);
    $balance = balance($id);

    if (isset($_SESSION['admin_id'])) {
        $date_begin = date('Y-m-d', strtotime($active_plan['date_start'].' - 1 days'));
    } else {
        //дата, после которой можно менять, то есть сегодня +1
        $date_begin = date('Y-m-d');
        if (date("G") > 14) {
            $date_begin = date('Y-m-d', strtotime($date_begin.' + 1 days'));
        }

    }


    if ($active_plan['status'] == 'true' and $date <= $active_plan['date_end'] and ($date > $date_begin or $status == 1)) {
        //есть активный статус и еще проверим, дата в диапозоне или нет

        //узнаем, есть ли вообще
        $query = $conn->prepare("SELECT id FROM Calendars WHERE date = ? and plan_id = ?");
        $query->bind_param('si', $date,$active_plan['id_plan']);
        $query->execute();
        $query->store_result();
        if ($query->num_rows > 0) {
            //есть такая  дата, значит ее удалим
            $query->bind_result($id_calen);
            while ($query->fetch()) {

                //проверим, если ли в доставке?
                $query_delivery = $conn->prepare("SELECT id FROM Delivery WHERE calendar_id = ?");
                $query_delivery->bind_param('i', $id_calen);
                $query_delivery->execute();
                $query_delivery->store_result();
                if ($query_delivery->num_rows > 0) {
                    //ошибка
                    $data[] = array(
                        'status' => 'ERROR',
                        'message' => "Ошибка, Вы не можете изменить статус этого дня, так как уже произведена доставка!",
                        'edit' => false,
                        'show' => true
                    );
                } else {
                    //delete
                    $query_delete = $conn->prepare('DELETE FROM Calendars WHERE id = ?');
                    $query_delete->bind_param('i', $id_calen);
                    $query_delete->execute();
                    if ($conn->errno) {
                        die('Select Error (' . $conn->errno . ') ' . $conn->error);
                    }
                    $query_delete->close();

                    $data[] = array(
                        'status' => 'SUCCESS',
                        'message' => "Вы отменили питание - ".human_date($date),
                        'edit' => true,
                        'show' => false
                    );
                }

            }
        } else {
            //нет даты в базе, значит проверим, можем ли вообще добавить

            if ($active_plan['days_can_save'] > 0 and $active_plan['days'] > $active_plan['days_off'] and (($active_plan['days']-$active_plan['days_off']) > ($active_plan['days_count_from_cal'] - $active_plan['days_notchange']) ) ) {
                //добавляем

                //add
                $query_add = $conn->prepare('INSERT INTO Calendars (plan_id, date) VALUES (?,?)');
                $query_add->bind_param('is',$active_plan['id_plan'], $date);
                $query_add->execute();
                if ($conn->errno) {
                    die('Select Error (' . $conn->errno . ') ' . $conn->error);
                }
                $query_add->close();

                if ($active_plan['days'] - $active_plan['days_count_from_cal'] > 0) {
                    $data[] = array(
                        'status' => 'SUCCESS',
                        'message' => "Вам доставят питание - ".human_date($date),
                        'edit' => true,
                        'show' => true
                    );
                } else {
                    $data[] = array(
                        'status' => 'SUCCESS',
                        'message' => "Вам доставят питание - ".human_date($date),
                        'edit' => false,
                        'show' => true
                    );
                }


            } else {
                //не добавляем
                $data[] = array(
                    'status' => 'ERROR',
                    'message' => "Вы выбрали все оплаченные дни Вашего тарифа! Чтобы выбрать этот день, необходимо отменить питание у другого.",
                    'edit' => false,
                    'show' => true
                );
            }
        }
        $query->close();

    } else {
        //нельзя менять эту дату
        $data[] = array(
            'status' => 'ERROR',
            'message' => "Ошибка, Вы не можете изменить статус этого дня!",
            'edit' => false,
            'show' => true
        );
    }

} else {
    //если мы сюда попади, значит пользователь не авторизован, но данные в сессию мы записали, значит напишем ответ
    $data[] = array(
        'status' => 'ERROR',
        'message' => "Ошибка, попробуйте обновить страницу!",
        'edit' => false,
        'show' => true
    );
}

    echo json_encode($data);

?>