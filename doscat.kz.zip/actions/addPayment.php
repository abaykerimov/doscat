<?php
session_start();
ini_set('error_reporting', E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
include("../bd.php");
include("filter.php");
require '../phpmailer/PHPMailerAutoload.php';

$sum = filter('Amount');
$orderid = filter('AccountId');
$invoiceId= filter('InvoiceId');
//$phone = filter('phone');
$transaction = filter('TransactionId');
$comment = filter('Description');

$data;
$errors = true;

//во первых проверим, авторизован ли пользователь и правильные ли данные он нам отправил
if (!empty($sum) and !empty($orderid) and !empty($transaction)) {

    $query_balance = $conn->prepare("SELECT id, first_name, last_name, phone FROM Users WHERE id = ?");
    $query_balance->bind_param('i', $orderid);
    $query_balance->execute();
    $query_balance->store_result();
    if ($query_balance->num_rows > 0) {
        $query_balance->bind_result($id,$first_name,$last_name,$phone);
        while ($query_balance->fetch()) {

            $insert_row = $conn->prepare('INSERT INTO HistoryOfPayment (dateOfPayment, lastPayment, paymentMethod, transaction, user_id, comment) VALUES (NOW(),?,2,?,?,?)');
            $insert_row->bind_param('diis', $sum, $transaction, $id, $comment);
            $insert_row->execute();
            $insert_row->close();

            $mail = new PHPMailer;
            $message = "Счет №".$transaction." оплачен от авторизованного пользователя.<br>
            На сумму: ".$sum."<br>
            Номер телефона: ".$phone."<br>
            Пользователь: ".$first_name." ".$last_name."<br>
            ";
            $mail->isSMTP();
            $mail->Host = 'mail.doscat.kz';  // Specify main and backup SMTP servers
            $mail->SMTPAuth = true;
            $mail->Username = 'ok@doscat.kz';
            $mail->Password = 'iKqd24_8';
            $mail->SMTPSecure = 'ssl';
            $mail->Port = 465;
            $mail->From = 'ok@doscat.kz';
            $mail->FromName = 'ok@doscat.kz';
            $mail->addAddress('zhkiro@gmail.com');
            $mail->addAddress('kozhaly@gmail.com');
            $mail->addAddress('art.denis@mail.ru');
            $mail->CharSet = "UTF-8";
            $mail->Subject = "Счет №".$transaction." оплачен!";
            $mail->Body = $message;
            $mail->ClearCustomHeaders();
            $mail->isHTML(true);
            $mail->send();
            //вернем ок, типа все записали

            $data = '{"code":0}';

        }
    } else {
        $data = '{"code":0}';
    }
    $query_balance->close();

    $errors = false;
}

if (!empty($sum) and !empty($invoiceId) and !empty($transaction)) {

    $insert_row = $conn->prepare('INSERT INTO Payments (date, sum, transaction, phone) VALUES (NOW(),?,?,?)');
    $insert_row->bind_param('iss', $sum, $transaction, $invoiceId);
    $insert_row->execute();
    $insert_row->close();

    //достанем данные
    $query_cost = $conn->prepare("SELECT id, first_name, last_name FROM Users WHERE phone = ?");
    $query_cost->bind_param('s', $invoiceId);
    $query_cost->execute();
    $query_cost->store_result();
    if ($query_cost->num_rows > 0) {
        $query_cost->bind_result($user_id,$first_name,$last_name);
        while ($query_cost->fetch()) {
            //тут внесем всем людям с таким телефоном платеж
            $insert_row = $conn->prepare('INSERT INTO HistoryOfPayment (dateOfPayment, lastPayment, paymentMethod, transaction, user_id) VALUES (NOW(),?,2,?,?)');
            $insert_row->bind_param('diis', $sum, $transaction, $user_id);
            $insert_row->execute();
            $insert_row->close();

            $message = "Счет №".$transaction." оплачен! Данные о зачислении внесены в базу данных<br>
            На сумму: ".$sum."<br>
            Номер телефона: ".$invoiceId."<br>
            Пользователь: ".$first_name." ".$last_name."<br>
            ";
        }
    } else {
        //такого пользователя нет
        $message = "Счет №".$transaction." оплачен! Пользователь в базе данных с таким номером телефона не найден!<br>
        На сумму: ".$sum."<br>
        Номер телефона: ".$invoiceId."<br>
        ";
    }
    $query_cost->close();

    $mail = new PHPMailer;
    $mail->isSMTP();
    $mail->Host = 'mail.doscat.kz';
    $mail->SMTPAuth = true;
    $mail->Username = 'ok@doscat.kz';
    $mail->Password = 'iKqd24_8';
    $mail->SMTPSecure = 'ssl';
    $mail->Port = 465;
    $mail->From = 'ok@doscat.kz';
    $mail->FromName = 'ok@doscat.kz';
    $mail->addAddress('zhkiro@gmail.com');
    $mail->addAddress('kozhaly@gmail.com');
    $mail->addAddress('art.denis@mail.ru');
    $mail->CharSet = "UTF-8";
    $mail->Subject = "Счет №".$transaction." оплачен!";
    $mail->Body = $message;
    $mail->ClearCustomHeaders();
    $mail->isHTML(true);
    $mail->send();
    //вернем ок, типа все записали

    $data = '{"code":0}';

    $errors = false;
}

if ($errors) {

    $data = '{"code":0}';

}

echo $data;
?>