<?php
include("../bd.php");
include("filter.php");
$tomorrow_date = date('Y-m-d', strtotime("+1 days"));
$yesterday_date = date('Y-m-d',strtotime("-1 days"));
$today_date = date('Y-m-d');
$program = filter("program");
$d = filter("d");
?>
<a class="carousel-control left slim<?php echo $program ?>" href="#myCarousel<?php echo $program ?>" data-slide="prev"><span class="glyphicon glyphicon-chevron-left"></span></a>
<a class="carousel-control right slim<?php echo $program ?>" href="#myCarousel<?php echo $program ?>" data-slide="next"><span class="glyphicon glyphicon-chevron-right"></span></a>
<?php
$resultMenu = $conn->query("set names utf8");
if($d == 'yesterday') {
    echo '<h3>Вчера</h3>';
    $sqlMenu = "SELECT id, program_id,date_start,kcal,protein,fat,carbo FROM Menu
    WHERE date_start = '$yesterday_date' AND program_id = '$program'";
} elseif($d == 'today') {
    echo '<h3>Сегодня</h3>';
    $sqlMenu = "SELECT id, program_id,date_start,kcal,protein,fat,carbo FROM Menu
    WHERE date_start = '$today_date' AND program_id = '$program'";
} else {
    echo '<h3>Завтра</h3>';
    $sqlMenu = "SELECT id, program_id,date_start,kcal,protein,fat,carbo FROM Menu
    WHERE date_start = '$tomorrow_date' AND program_id = '$program'";
}
$resultMenu = $conn->query($sqlMenu);
while ($rowMenu = $resultMenu->fetch_assoc()) {
$menuid = $rowMenu['id']; ?>

<table class="table table-striped table-hover">
    <tbody>
    <?php
    $resultType = $conn->query("set names utf8");
    $sqlType = "SELECT DISTINCT m.food_type_id,f.type_name
    FROM Menu_Foods m JOIN Food_Type f ON f.id = m.food_type_id WHERE m.menu_id = '$menuid' ORDER by f.sort";
    $resultType = $conn->query($sqlType);
    while($rowType = $resultType->fetch_assoc()){
        $type_id = $rowType['food_type_id'];
        $type_name = $rowType['type_name']; ?>
        <tr>
            <td colspan="2" class="bolder text-center">
                <h3><?php echo $type_name ?></h3>
            </td>
        </tr>

        <?php
        $resultFood = $conn->query("set names utf8");
        $sqlFood = "SELECT f.id,f.photo,f.description, f.name, m.portion,TRUNCATE((f.kcal*m.portion/100),2) as calcKcal, TRUNCATE((f.protein*m.portion/100),2) as calcPro, TRUNCATE((f.fat*m.portion/100),2) as calcFat, TRUNCATE((f.carbohydrate*m.portion/100),2) as calcCarbo
        FROM Foods f JOIN Menu_Foods m ON f.id = m.food_id
        WHERE f.id in (SELECT food_id FROM Menu_Foods WHERE menu_id = '$menuid' and food_type_id = '$type_id') GROUP by f.id";
        $resultFood = $conn->query($sqlFood);

        while($rowFood = $resultFood->fetch_assoc()){
            $food_id = $rowFood['id'];?>
            <tr>
                <td class="paddingnone">
                    <img src="<?php echo $rowFood['photo'] ?>" alt="">
                </td>
                <td class="desk">
                    <h3><?php echo $rowFood['name'] ?></h3>
                    <p>
                    </p>
                    <p class="dopdesk1">
                        Ккал - <span class="kcal"><?php echo $rowFood['calcKcal'] ?></span>, белок - <span class="pro"><?php echo $rowFood['calcPro'] ?></span>, жир - <span class="fat"><?php echo $rowFood['calcFat'] ?></span>, угл. - <span class="carbo"><?php echo $rowFood['calcCarbo'] ?></span>
                    </p>
                    <p class="dopdesk2">
                        <?php echo $rowFood['portion'] ?> грамм.
                    </p>
                </td>
            </tr>
        <?php }}?>
    <tr>
        <td colspan="2" class="bolder text-center">
            <h4>Всего: Ккал - <?php echo $rowMenu['kcal'] ?>, Белок - <?php echo $rowMenu['protein'] ?>, Жир - <?php echo $rowMenu['fat'] ?>, Угл. - <?php echo $rowMenu['carbo'] ?></h4>
        </td>
    </tr>

    <?php } ?>
    </tbody>
</table>