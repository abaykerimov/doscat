<?php
include("../bd.php");
session_start();
$id = $_SESSION["user_id"];
$sql = "SELECT * FROM Users WHERE id = '$id'";
$result = $conn->query($sql);
$row = $result->fetch_assoc();
$balance = $row['balance'];


$id = $_POST['id'];
$updateBalance = $_POST['updateBalance'];
$add = $balance + $updateBalance;
$query = $conn->query("set names utf8");
$query = $conn->prepare("UPDATE Users SET balance='$add' WHERE id=?");
//
$query->bind_param('i', $id);
$query->execute();
?>