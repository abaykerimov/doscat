<?php
//ini_set('error_reporting', E_ALL);
//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);
session_start();
if (isset($_SESSION["status"])) {
    $status = $_SESSION["status"];
} else {
    $status = "";
}

include("../bd.php");
include("filter.php");
require '../phpmailer/PHPMailerAutoload.php';
include('functions.php');
include('password.php');

$program_id = filter('program');
$name = filter('user_name');
$surname = filter('surname');
$phone = filter('phone');
$days = filter('days');
$sum = filter('sum');
$Delivery_inPlans = filter('dzen');
$date_start = filter('date');

$address = filter('address');
$gym = filter('gym');
if (isset($_POST['mail'])) {$email= $_POST["mail"];
    $email = stripslashes($email);
    $email = htmlspecialchars($email);
    $email = trim($email);
    if (empty($email)) {$email = "Не указано";}
    if ($email == '') {
        unset($email);
    } else {
        if(!preg_match("|^[-0-9a-z_\.]+@[-0-9a-z_^\.]+\.[a-z]{2,6}$|i", $email))
        {
            unset($email);
        }
    }
}

$data = array();

//во первых проверим, авторизован ли пользователь и правильные ли данные он нам отправил
if ( (!empty($phone) or !empty($email)) and !empty($program_id) and !empty($days) and !empty($sum) and !empty($date_start) and (!empty($Delivery_inPlans) or $Delivery_inPlans == 0 ) ) {

    $price_for_req = $sum/$days;
    //достанем стоимость тарифа
    $query_cost = $conn->prepare("SELECT id, price, amount_days, (SELECT name FROM Program WHERE id = program_id) as program_name, freezing FROM Product WHERE type = ? and program_id = ? and price = ? and amount_days BETWEEN 0 and ?");
    $query_cost->bind_param('iiii', $Delivery_inPlans,$program_id,$price_for_req,$days);
    $query_cost->execute();
    $query_cost->store_result();
    if ($query_cost->num_rows > 0) {
        $query_cost->bind_result($id_product,$price,$amount_days, $program_name,$freezing);
        while ($query_cost->fetch()) {
            //тут значит все ок, к плану можно привязаться

            //здесь мы узнаем существует такой пользователь или нет
            if (empty($phone)) {
                $query_cost = $conn->prepare("SELECT id, first_name, last_name FROM Users WHERE email = ?");
                $query_cost->bind_param('s', $email);
            } else {
                $query_cost = $conn->prepare("SELECT id, first_name, last_name FROM Users WHERE phone = ?");
                $query_cost->bind_param('s', $phone);
            }
            $query_cost->execute();
            $query_cost->store_result();
            if ($query_cost->num_rows > 0) {
                $query_cost->bind_result($user_id,$first_name,$last_name);
                while ($query_cost->fetch()) {

                    //условие со статусом, если от админа то гоу
                    if($status == 1 || $status == 2) {
                        //Добавим новый план питания и календарь к нему
                        create_calendar($user_id,$id_product,$sum/$days,$days,$freezing,"",$program_name,$date_start,$Delivery_inPlans);

                        $messages = "Ваша заявка принята! Мы с Вами свяжемся в ближайшее время.";
                        $info = "У существующего пользователя, добавлен план питания и построен календарь.";
                    } else {

                        $messages = "Ваш e-mail или номер телефона уже зарегистрированы в системе. Авторизуйтесь, чтобы начать работу. Заявка была принята, но не обработана автоматически, мы с Вами свяжемся!";
                        $info = "У существующего пользователя, выдано предупреждение, необходимо перезвонить, чтобы уточнить информацию.";

                    }


                }
            } else {

                if (!empty($name) or !empty($surname) or !empty($phone) or !empty($email)) {

                    if (empty($gym)) {$gym = 0;}
                    //пароль
                    $randompass = randomPassword();
                    $p = md5(md5($randompass . md5(sha1($randompass))));
                    //такого пользователя нет, будем его создавать
                    $insert_row = $conn->prepare('INSERT INTO Users (first_name,last_name,phone,email,password,id_gym,custom_address,user_status,created) VALUES (?,?,?,?,?,?,?,0,NOW())');
                    $insert_row->bind_param('sssssis', $surname, $name, $phone, $email, $p, $gym, $address);
                    $insert_row->execute();
                    $user_id = $insert_row->insert_id;
                    $insert_row->close();

                    //тут будем создавать для него план питания
                    create_calendar($user_id,$id_product,$sum/$days,$days,$freezing,"",$program_name,$date_start,$Delivery_inPlans);

                    $key = "3730625f574c333933655467504476693946724d5e4c6173505960";
                    $bd_link = $email.$phone.$name.$key;
                    $real_link = password_hash($bd_link, PASSWORD_BCRYPT);

                    //здесь надо написать письмо и бла бла бла http://boongalo.com/confirmation.php?real='.$real_link.'&email=".$email."
                    $mail = new PHPMailer;
                    $message = "Здравствуйте ".$name.", Вы получили данное письмо, так как Вы или кто-то другой указали электронный адрес - ".$email." в заявке, на сайте <a href='http://doscat.kz'>doscat.kz</a>.<br><br>
Спасибо за Вашу заявку. Мы свяжемся с Вами в ближайшее время. А пока, предлагаем зарегистрироваться в один клик в нашей системе. Перейдите по ссылке и мы вышлем данные для входа в личный кабинет: <br><br><a href='http://doscat.kz/actions/confirmation.php?real=".$real_link."&email=".$email."'>http://doscat.kz/actions/confirmation.php?real=".$real_link."&email=".$email."</a><br><br>
Преимущества личного кабинета:
<ul>
<li>Онлайн пополнение баланса;</li>
<li>Планирование питания в удобном онлайн календаре;</li>
<li>Заморозка питания;</li>
<li>История платежей и питания;</li>
</ul>
<br>
Если заявку сделали не Вы, просто проигнорируйте данное сообщение.
<br><br>С уважением, команда DosCat.kz
";

                    $mail->isSMTP();
                    $mail->Host = 'mail.doscat.kz';  // Specify main and backup SMTP servers
                    $mail->SMTPAuth = true;
                    $mail->Username = 'ok@doscat.kz';
                    $mail->Password = 'iKqd24_8';
                    $mail->SMTPSecure = 'ssl';
                    $mail->Port = 465;
                    $mail->From = 'ok@doscat.kz';
                    $mail->FromName = 'ok@doscat.kz';
                    $mail->addAddress($email);
                    //$mail->addAddress('zhkiro@gmail.com');
                    //$mail->addAddress('kozhaly@gmail.com');
                    //$mail->addAddress('art.denis@mail.ru');
                    $mail->CharSet = "UTF-8";
                    $mail->Subject = 'Заявка на сайте DosCat.kz.';
                    $mail->Body = $message;
                    $mail->ClearCustomHeaders();
                    $mail->isHTML(true);
                    $mail->send();


                    $messages = "Ваша заявка принята! Мы с Вами свяжемся в ближайшее время.";
                    $info = "Создан пользователь, добавлен план питания и построен календарь. Пользователю отправлено письмо с приглашением в личный кабинет.";


                } else {
                    //не указаны имя и фамилия
                    $messages = "Ошибка, попробуйте обновить страницу, не указаны имя, фамилия, телефон или e-mail адрес!";
                    $info = "Новый пользователь не создан, так как не указаны имя или телефон, план питания и календарь не созданы!";

                }


            }
            $query_cost->close();

            //получаем $dzen - имя статуса заявки
            $query_Delivery_inPlans = $conn->prepare("SELECT name FROM Delivery_inPlans WHERE id = ?");
            $query_Delivery_inPlans->bind_param('i', $Delivery_inPlans);
            $query_Delivery_inPlans->execute();
            $query_Delivery_inPlans->store_result();
            if ($query_Delivery_inPlans->num_rows > 0) {
                $query_Delivery_inPlans->bind_result($dzen);
                while ($query_Delivery_inPlans->fetch()) {

                }
            }
            $query_Delivery_inPlans->close();

                if (empty($name)) {$name = "Не указано";}
                if (empty($surname)) {$name = "Не указано";}

            $mail = new PHPMailer;
            $message = "Новая заявка на сайте <br>
Имя: ".$name." <br>
Фамилия: ".$surname." <br>
Телефон: ".$phone." <br>
E-mail: ".$email." <br>
План питания: ".$program_name." <br>
Количество дней: ".$days." <br>
Стоимость в день: ".$sum/$days." <br>
Стоимость всего: ".$sum." <br>
Доставка: ".$dzen." <br>
Дата старта: ".$date_start." <br>
Адрес доставки: ".$address." <br>
Дата заявки: ".date("Y-m-d")." <br>
Информация: ".$info." <br>
            ";
            $mail->isSMTP();
            $mail->Host = 'mail.doscat.kz';  // Specify main and backup SMTP servers
            $mail->SMTPAuth = true;
            $mail->Username = 'ok@doscat.kz';
            $mail->Password = 'iKqd24_8';
            $mail->SMTPSecure = 'ssl';
            $mail->Port = 465;
            $mail->From = 'ok@doscat.kz';
            $mail->FromName = 'ok@doscat.kz';
            $mail->addAddress('zhkiro@gmail.com');
            $mail->addAddress('kozhaly@gmail.com');
            $mail->addAddress('art.denis@mail.ru');
            $mail->CharSet = "UTF-8";
            $mail->Subject = 'Новая DC заявка- '.$name;
            $mail->Body = $message;
            $mail->ClearCustomHeaders();
            $mail->isHTML(true);
            $mail->send();

        }

        $data[] = array(
            'status' => 'SUCCESS',
            'message' => $messages,
            'confirm' => false
        );

    } else {
        //надо сообщить об ошибке
        $data[] = array(
            'status' => 'ERROR',
            'message' => "Ошибка, невозможно определить план питания!",
            'confirm' => false
        );
        //exit;

    }
    $query_cost->close();

} else {
    //если мы сюда попади, значит пользователь не авторизован, но данные в сессию мы записали, значит напишем ответ
    $data[] = array(
        'status' => 'ERROR',
        'message' => "Ошибка, попробуйте обновить страницу, не все данные указаны!",
        'confirm' => false
    );
}

echo json_encode($data);
?>