<?php
include("../bd.php");
$resultFood = $conn->query("set names utf8");
$queryFood = "SELECT * FROM Foods ORDER BY name";
$resultFood = $conn->query($queryFood);
while ($rowFood = $resultFood->fetch_assoc()) {
    ?>
    <option value="<?php echo $rowFood["id"]; ?>"><?php echo $rowFood["name"]; ?></option>
    <?php
}
$resultFood->close();
?>