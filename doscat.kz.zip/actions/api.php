<?php
//ini_set('error_reporting', E_ALL);
//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);
header('Content-type: text/html; charset=utf8');

include("../bd.php");
// get the HTTP method, path and body of the request
$method = $_SERVER['REQUEST_METHOD'];
$request = explode('/', trim($_SERVER['PATH_INFO'],'/'));
$input = json_decode(file_get_contents('php://input'),true);

// connect to the mysql database
$link = mysqli_connect('srv-db-plesk09.ps.kz:3306', 'dosca_doscatkz', '6wAaa1_6', 'doscatkz_mainBase');
mysqli_set_charset($link,'utf8');

// retrieve the table and key from the path
$table = preg_replace('/[^a-z0-9_]+/i','',array_shift($request));
$key = array_shift($request)+0;

// escape the columns and values from the input object
$columns = preg_replace('/[^a-z0-9_]+/i','',array_keys($input));
$values = array_map(function ($value) use ($link) {
    if ($value===null) return null;
    return mysqli_real_escape_string($link,(string)$value);
},array_values($input));

// build the SET part of the SQL command
$set = '';
for ($i=0;$i<count($columns);$i++) {
    $set.=($i>0?',':'').'`'.$columns[$i].'`=';
    $set.=($values[$i]===null?'NULL':'"'.$values[$i].'"');
}
$today = date('Y-m-d');
// create SQL based on HTTP method
if ($method == 'GET') {
    $resultMenu = $conn->query("set names utf8");
    $sqlMenu = "SELECT id, program_id,date_start,kcal,protein,fat,carbo FROM Menu
    WHERE date_start = '$today' AND program_id = '1'";
    $resultMenu = $conn->query($sqlMenu);
    while ($rowMenu = $resultMenu->fetch_assoc()) {
        $menuid = $rowMenu['id'];
        $resultType = $conn->query("set names utf8");
        $sqlType = "SELECT DISTINCT m.food_type_id,f.type_name
    FROM Menu_Foods m JOIN Food_Type f ON f.id = m.food_type_id WHERE m.menu_id = '$menuid' ORDER by f.sort";
        $resultType = $conn->query($sqlType);
        while ($rowType = $resultType->fetch_assoc()) {
            $type_id = $rowType['food_type_id'];
            echo json_encode($rowType['type_name']. ":");
            echo "[";
            $resultFood = $conn->query("set names utf8");
            $sqlFood = "SELECT f.id,f.photo,f.description, f.name, m.portion,TRUNCATE((f.kcal*m.portion/100),2) as calcKcal, TRUNCATE((f.protein*m.portion/100),2) as calcPro, TRUNCATE((f.fat*m.portion/100),2) as calcFat, TRUNCATE((f.carbohydrate*m.portion/100),2) as calcCarbo
        FROM Foods f JOIN Menu_Foods m ON f.id = m.food_id
        WHERE f.id in (SELECT food_id FROM Menu_Foods WHERE menu_id = '$menuid' and food_type_id = '$type_id') GROUP by f.id";
            $resultFood = $conn->query($sqlFood);
            WHILE($rowFood = $resultFood->fetch_assoc()){



                ?>
                <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>

                <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery-json/2.4.0/jquery.json.min.js"></script>
                <script type='text/javascript'>
                    $(document).ready(function () {

                        var JsonData = '<?php echo "name: ".$rowFood['name'] ?>';
                        var your_object = $.toJSON(JsonData);
                        $.ajax({
                            type: "POST",                 //метод запроса, POST или GET (если опустить, то по умолчанию GET)
                            url: "http://abuka.pythonanywhere.com/abay",            //серверный скрипт принимающий запрос
                            data: your_object,	//можно передать переменную с json в одном из параметре запроса
                            success: function(res) {      //функция выполняется при удачном заверщение
                                alert("Данные успешно отправлены на сервер");
                            }
                        });
                        console.log(your_object);
                    });
                </script>
<?php
            }
            echo "],";
        }
    }

}else {
    echo mysqli_affected_rows($link);
}

// close mysql connection
mysqli_close($link);

//echo $today;
// create SQL based on HTTP method
//if($method == 'GET') {

//
//
//             for ($i=0;$i<mysqli_num_rows($resultFood);$i++) {
//                 $data = mysqli_fetch_object($resultFood);
//                 $a = array();
//                 echo ($i>0?',':'').json_encode($data);
//             }
//             mysqli_close($link);
//         }
//     }
//}


    /*case 'PUT':
        $sql = "update `$table` set $set where id=$key";
        break;
    case 'POST':
        $sql = "insert into `$table` set $set";
        break;
    case 'DELETE':
        $sql = "delete `$table` where id=$key";
        break;
    if ($method == 'GET') {
                 if (!$key) echo '[';
                 for ($i=0;$i<mysqli_num_rows($resultFood);$i++) {
                     echo ($i>0?',':'').json_encode(mysqli_fetch_object($resultFood));
                 }
                 if (!$key) echo ']';
             } elseif ($method == 'POST') {
                 echo mysqli_insert_id($link);
             } else {
                 echo mysqli_affected_rows($link);
             }
             mysqli_close($link);

    */

// excecute SQL statement

// die if SQL statement failed
