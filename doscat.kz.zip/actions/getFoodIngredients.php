<?php
$food_value = $_POST["food_value"];

if(!empty($food_value)) {
    $result = $conn->query("set names utf8");
    $query ="SELECT * FROM Foods WHERE id = '$food_value'";
    $result = $conn->query($query);
    while($row = $result->fetch_assoc()){
        ?>

        <td class="kcal"><?php echo $row["kcal"]; ?></td>
        <td class="protein"><?php echo $row["protein"]; ?></td>
        <td class="fat"><?php echo $row["fat"]; ?></td>
        <td class="carbo"><?php echo $row["carbohydrate"]; ?></td>

        <input class="hKcal" type="hidden" value="<?php echo $row["kcal"]; ?>">
        <input class="hProtein" type="hidden" value="<?php echo $row["protein"]; ?>">
        <input class="hFat" type="hidden" value="<?php echo $row["fat"]; ?>">
        <input class="hCarbo" type="hidden" value="<?php echo $row["carbohydrate"]; ?>">
        <?php
    }
    $result->close();
}