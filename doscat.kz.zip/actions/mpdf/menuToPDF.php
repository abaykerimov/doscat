<?php
header('Content-type: text/html; charset=utf8');
include("../bd.php");
include("../filter.php");
include('mpdf.php');
//ini_set('error_reporting', E_ALL);
//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);
$menu_id = filter("id");

$resultMenu = $conn->query("set names utf8");
$sqlMenu = "SELECT id, (SELECT name FROM Program WHERE id=program_id) as program,date_start, day_of_the_week,kcal, protein, fat, carbo
FROM Menu WHERE id = '$menu_id'";
$resultMenu = $conn->query($sqlMenu);
while ($rowMenu = $resultMenu->fetch_assoc()) {
    $menuid = $rowMenu["id"];
    $date = DateTime::createFromFormat("Y-m-d", $rowMenu["date_start"]);
    $date_start = $date->format("d-m-y");
    $day = date('l', strtotime($rowMenu["date_start"]));
    if ($day == 'Monday') {
        $day = 'Понедельник';
    } else if ($day == 'Tuesday') {
        $day = 'Вторник';
    } else if ($day == 'Wednesday') {
        $day = 'Среда';
    } else if ($day == 'Thursday') {
        $day = 'Четверг';
    } else if ($day == 'Friday') {
        $day = 'Пятница';
    } else if ($day == 'Saturday') {
        $day = 'Суббота';
    } else if ($day == 'Sunday') {
        $day = 'Воскресенье';
    }

    $mpdf = new mPDF();

    $mpdf->WriteHTML('
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="../../css/bootstrap.min.css">
<style>
@font-face {
font-family: dejaVu; /* Имя шрифта */
src: url(ttfonts/DejaVuSerifCondensed.ttf); /* Путь к файлу со шрифтом */
}
tr.type th {padding-top: 15px;}
tr td {padding-top: 5px; padding-bottom:5px;}
tr td.portion {padding-left:10px}
tr.sum th {padding-top: 5px;}
tr, th, td, p {font-family: dejaVu, serif;}
</style>
</head>
<body>
<img src="../../img/doscat_logo.png" style="width: 40%; margin-bottom: 30px;">
<table style="width:100%;">
<tbody>

<tr>
  <th>Программа:</th>
  <td colspan="2">' . $rowMenu["program"] . '</td>
</tr>

<tr>
  <th>Дата меню:</th>
  <td>' . $date_start . '</td>
</tr>
<tr>
  <th>День недели:</th>
  <td>' . $day . '</td>
</tr>

');
    $resultType = $conn->query('set names utf8');
    $sqlType = "SELECT DISTINCT m.food_type_id,f.type_name
    FROM Menu_Foods m JOIN Food_Type f ON f.id = m.food_type_id WHERE m.menu_id = '$menuid' ORDER by f.sort";
    $resultType = $conn->query($sqlType);
    while ($rowType = $resultType->fetch_assoc()) {
        $type_id = $rowType["food_type_id"];
        $type_name = $rowType["type_name"];
        $mpdf->WriteHTML("
<tr class='type'>
    <th>" . $type_name . "</th>
    <th style='width:20%;'>Выход</th>
    <th>Ккал</th>
    <th>Белок</th>
    <th>Жир</th>
    <th>Углеводы</th>
</tr>

");
        $resultFood = $conn->query("set names utf8");
        $sqlFood = "SELECT f.id,f.name, m.portion, TRUNCATE((f.kcal*m.portion/100),2) as calcKcal, TRUNCATE((f.protein*m.portion/100),2) as calcPro,
        TRUNCATE((f.fat*m.portion/100),2) as calcFat, TRUNCATE((f.carbohydrate*m.portion/100),2) as calcCarbo
        FROM Menu_Foods m JOIN Foods f ON f.id = m.food_id
        WHERE m.menu_id = '$menuid' and m.food_type_id = '$type_id'";
        $resultFood = $conn->query($sqlFood);

        while ($rowFood = $resultFood->fetch_assoc()) {
            $food_id = $rowFood["id"];
            $mpdf->WriteHTML("
<tr>
    <td>" . $rowFood["name"] . "</td>
    <td class='portion'>" . $rowFood["portion"] . "</td>
    <td>" . $rowFood["calcKcal"] . "</td>
    <td>" . $rowFood["calcPro"] . "</td>
    <td>" . $rowFood["calcFat"] . "</td>
    <td>" . $rowFood["calcCarbo"] . "</td>
</tr>
");
        }
        $resultSumType = $conn->query("set names utf8");
        $sqlSumType = "SELECT sum(TRUNCATE((f.kcal*m.portion/100),2)) as sumKcal, sum(TRUNCATE((f.protein*m.portion/100),2)) as sumPro,
        sum(TRUNCATE((f.fat*m.portion/100),2)) as sumFat, sum(TRUNCATE((f.carbohydrate*m.portion/100),2)) as sumCarbo
        FROM Menu_Foods m JOIN Foods f ON f.id = m.food_id
        WHERE m.menu_id = '$menuid' and m.food_type_id = '$type_id'";
        $resultSumType = $conn->query($sqlSumType);

        while ($rowSumType = $resultSumType->fetch_assoc()) {
            $mpdf->WriteHTML('

            <tr style="background-color: #c8c8c8">
                <td width="25%"></td>
                <td>Калории ' . $type_name . '</td>
                <td>' . $rowSumType["sumKcal"] . '</td>
                <td>' . $rowSumType["sumPro"] . '</td>
                <td>' . $rowSumType["sumFat"] . '</td>
                <td>' . $rowSumType["sumCarbo"] . '</td>
            </tr>
        ');
        }
    }
    $mpdf->WriteHTML('
</tbody>
    <tr class="sum" style="background-color: #c8c8c8;">
        <th width="25%"></th>
        <th>Всего</th>
        <th>' . $rowMenu["kcal"] . '</th>
        <th>' . $rowMenu["protein"] . '</th>
        <th>' . $rowMenu["fat"] . '</th>
        <th>' . $rowMenu["carbo"] . '</th>
    </tr>

    </table>
</body>
</html>
');
}
$mpdf->AddPage();
$resultMenu = $conn->query("set names utf8");
$sqlMenu = "SELECT id, (SELECT name FROM Program WHERE id=program_id) as program,date_start, day_of_the_week,kcal, protein, fat, carbo
FROM Menu WHERE id = '$menu_id'";
$resultMenu = $conn->query($sqlMenu);
while ($rowMenu = $resultMenu->fetch_assoc()) {
    $menuid = $rowMenu["id"];
    $date = DateTime::createFromFormat("Y-m-d", $rowMenu["date_start"]);
    $date_start = $date->format("d-m-y");
    $day = date('l', strtotime($rowMenu["date_start"]));
    if ($day == 'Monday') {
        $day = 'Понедельник';
    } else if ($day == 'Tuesday') {
        $day = 'Вторник';
    } else if ($day == 'Wednesday') {
        $day = 'Среда';
    } else if ($day == 'Thursday') {
        $day = 'Четверг';
    } else if ($day == 'Friday') {
        $day = 'Пятница';
    } else if ($day == 'Saturday') {
        $day = 'Суббота';
    } else if ($day == 'Sunday') {
        $day = 'Воскресенье';
    }

    $mpdf->WriteHTML('
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="../../css/bootstrap.min.css">
<style>
@font-face {
font-family: dejaVu; /* Имя шрифта */
src: url(ttfonts/DejaVuSerifCondensed.ttf); /* Путь к файлу со шрифтом */
}
tr.type th {padding-top: 15px;}
tr td {padding-top: 5px; padding-bottom:5px;}
tr td.portion {padding-left:10px}
tr.sum th {padding-top: 5px;}
tr, th, td, p {font-family: dejaVu, serif;}
</style>
</head>
<body>
<img src="../../img/doscat_logo.png" style="width: 40%; margin-bottom: 30px;">
<table style="width:100%;">
<tbody>

<tr>
  <th>Программа:</th>
  <td colspan="2">' . $rowMenu["program"] . '</td>
</tr>

<tr>
  <th>Дата меню:</th>
  <td>' . $date_start . '</td>
</tr>
<tr>
  <th>День недели:</th>
  <td>' . $day . '</td>
</tr>

');
    $resultType = $conn->query('set names utf8');
    $sqlType = "SELECT DISTINCT m.food_type_id,f.type_name
    FROM Menu_Foods m JOIN Food_Type f ON f.id = m.food_type_id WHERE m.menu_id = '$menuid' ORDER by f.sort";
    $resultType = $conn->query($sqlType);
    while ($rowType = $resultType->fetch_assoc()) {
        $type_id = $rowType["food_type_id"];
        $type_name = $rowType["type_name"];
        $mpdf->WriteHTML("
    <tr class='type'>
        <th>" . $type_name . "</th>
        <th style='width:20%;'>Выход</th>
        <th>Ккал</th>
        <th>Белок</th>
        <th>Жир</th>
        <th>Углеводы</th>
    </tr>

    ");
        $resultFood = $conn->query("set names utf8");
        $sqlFood = "SELECT f.id,f.name, m.portion, TRUNCATE((f.kcal*m.portion/100),2) as calcKcal, TRUNCATE((f.protein*m.portion/100),2) as calcPro,
        TRUNCATE((f.fat*m.portion/100),2) as calcFat, TRUNCATE((f.carbohydrate*m.portion/100),2) as calcCarbo
        FROM Menu_Foods m JOIN Foods f ON f.id = m.food_id
        WHERE m.menu_id = '$menuid' and m.food_type_id = '$type_id'";
        $resultFood = $conn->query($sqlFood);

        while ($rowFood = $resultFood->fetch_assoc()) {
            $food_id = $rowFood["id"];
            $mpdf->WriteHTML("
    <tr>
        <td>" . $rowFood["name"] . "</td>
        <td class='portion'>" . $rowFood["portion"] . "</td>
        <td>" . $rowFood["calcKcal"] . "</td>
        <td>" . $rowFood["calcPro"] . "</td>
        <td>" . $rowFood["calcFat"] . "</td>
        <td>" . $rowFood["calcCarbo"] . "</td>
    </tr>
    ");
        }
        $resultSumType = $conn->query("set names utf8");
        $sqlSumType = "SELECT sum(TRUNCATE((f.kcal*m.portion/100),2)) as sumKcal, sum(TRUNCATE((f.protein*m.portion/100),2)) as sumPro,
        sum(TRUNCATE((f.fat*m.portion/100),2)) as sumFat, sum(TRUNCATE((f.carbohydrate*m.portion/100),2)) as sumCarbo
        FROM Menu_Foods m JOIN Foods f ON f.id = m.food_id
        WHERE m.menu_id = '$menuid' and m.food_type_id = '$type_id'";
        $resultSumType = $conn->query($sqlSumType);

        while ($rowSumType = $resultSumType->fetch_assoc()) {
            $mpdf->WriteHTML('

                <tr style="background-color: #c8c8c8">
                    <td width="25%"></td>
                    <td>Калории ' . $type_name . '</td>
                    <td>' . $rowSumType["sumKcal"] . '</td>
                    <td>' . $rowSumType["sumPro"] . '</td>
                    <td>' . $rowSumType["sumFat"] . '</td>
                    <td>' . $rowSumType["sumCarbo"] . '</td>
                </tr>
            ');
        }
    }
    $mpdf->WriteHTML('
</tbody>
    <tr class="sum" style="background-color: #c8c8c8;">
        <th width="25%"></th>
        <th>Всего</th>
        <th>' . $rowMenu["kcal"] . '</th>
        <th>' . $rowMenu["protein"] . '</th>
        <th>' . $rowMenu["fat"] . '</th>
        <th>' . $rowMenu["carbo"] . '</th>
    </tr>

    </table>
</body>
</html>
');
}
$mpdf->AddPage();
$resultMenu = $conn->query("set names utf8");
$sqlMenu = "SELECT id, (SELECT name FROM Program WHERE id=program_id) as program,date_start, day_of_the_week,kcal, protein, fat, carbo
FROM Menu WHERE id = '$menu_id'";
$resultMenu = $conn->query($sqlMenu);
while ($rowMenu = $resultMenu->fetch_assoc()) {
    $menuid = $rowMenu["id"];
    $date = DateTime::createFromFormat("Y-m-d", $rowMenu["date_start"]);
    $date_start = $date->format("d-m-y");
    $day = date('l', strtotime($rowMenu["date_start"]));
    if ($day == 'Monday') {
        $day = 'Понедельник';
    } else if ($day == 'Tuesday') {
        $day = 'Вторник';
    } else if ($day == 'Wednesday') {
        $day = 'Среда';
    } else if ($day == 'Thursday') {
        $day = 'Четверг';
    } else if ($day == 'Friday') {
        $day = 'Пятница';
    } else if ($day == 'Saturday') {
        $day = 'Суббота';
    } else if ($day == 'Sunday') {
        $day = 'Воскресенье';
    }

    $mpdf->WriteHTML('
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="../../css/bootstrap.min.css">
<style>
@font-face {
font-family: dejaVu; /* Имя шрифта */
src: url(ttfonts/DejaVuSerifCondensed.ttf); /* Путь к файлу со шрифтом */
}
tr.type th {padding-top: 15px;}
tr td {padding-top: 5px; padding-bottom:5px;}
tr td.portion {padding-left:10px}
tr.sum th {padding-top: 5px;}
tr, th, td, p {font-family: dejaVu, serif;}
</style>
</head>
<body>
<img src="../../img/doscat_logo.png" style="width: 40%; margin-bottom: 30px;">
<table style="width:100%;">
<tbody>

<tr>
  <th>Программа:</th>
  <td colspan="2">' . $rowMenu["program"] . '</td>
</tr>

<tr>
  <th>Дата меню:</th>
  <td>' . $date_start . '</td>
</tr>
<tr>
  <th>День недели:</th>
  <td>' . $day . '</td>
</tr>

');
    $resultType = $conn->query('set names utf8');
    $sqlType = "SELECT DISTINCT m.food_type_id,f.type_name
    FROM Menu_Foods m JOIN Food_Type f ON f.id = m.food_type_id WHERE m.menu_id = '$menuid' ORDER by f.sort";
    $resultType = $conn->query($sqlType);
    while ($rowType = $resultType->fetch_assoc()) {
        $type_id = $rowType["food_type_id"];
        $type_name = $rowType["type_name"];
        $mpdf->WriteHTML("
    <tr class='type'>
        <th>" . $type_name . "</th>
        <th style='width:20%;'>Выход</th>
        <th>Ккал</th>
        <th>Белок</th>
        <th>Жир</th>
        <th>Углеводы</th>
    </tr>

    ");
        $resultFood = $conn->query("set names utf8");
        $sqlFood = "SELECT f.id,f.name, m.portion, TRUNCATE((f.kcal*m.portion/100),2) as calcKcal, TRUNCATE((f.protein*m.portion/100),2) as calcPro,
        TRUNCATE((f.fat*m.portion/100),2) as calcFat, TRUNCATE((f.carbohydrate*m.portion/100),2) as calcCarbo
        FROM Menu_Foods m JOIN Foods f ON f.id = m.food_id
        WHERE m.menu_id = '$menuid' and m.food_type_id = '$type_id'";
        $resultFood = $conn->query($sqlFood);

        while ($rowFood = $resultFood->fetch_assoc()) {
            $food_id = $rowFood["id"];
            $mpdf->WriteHTML("
    <tr>
        <td>" . $rowFood["name"] . "</td>
        <td class='portion'>" . $rowFood["portion"] . "</td>
        <td>" . $rowFood["calcKcal"] . "</td>
        <td>" . $rowFood["calcPro"] . "</td>
        <td>" . $rowFood["calcFat"] . "</td>
        <td>" . $rowFood["calcCarbo"] . "</td>
    </tr>
    ");
        }
        $resultSumType = $conn->query("set names utf8");
        $sqlSumType = "SELECT sum(TRUNCATE((f.kcal*m.portion/100),2)) as sumKcal, sum(TRUNCATE((f.protein*m.portion/100),2)) as sumPro,
        sum(TRUNCATE((f.fat*m.portion/100),2)) as sumFat, sum(TRUNCATE((f.carbohydrate*m.portion/100),2)) as sumCarbo
        FROM Menu_Foods m JOIN Foods f ON f.id = m.food_id
        WHERE m.menu_id = '$menuid' and m.food_type_id = '$type_id'";
        $resultSumType = $conn->query($sqlSumType);

        while ($rowSumType = $resultSumType->fetch_assoc()) {
            $mpdf->WriteHTML('

                <tr style="background-color: #c8c8c8">
                    <td width="25%"></td>
                    <td>Калории ' . $type_name . '</td>
                    <td>' . $rowSumType["sumKcal"] . '</td>
                    <td>' . $rowSumType["sumPro"] . '</td>
                    <td>' . $rowSumType["sumFat"] . '</td>
                    <td>' . $rowSumType["sumCarbo"] . '</td>
                </tr>
            ');
        }
    }
    $mpdf->WriteHTML('
</tbody>
    <tr class="sum" style="background-color: #c8c8c8;">
        <th width="25%"></th>
        <th>Всего</th>
        <th>' . $rowMenu["kcal"] . '</th>
        <th>' . $rowMenu["protein"] . '</th>
        <th>' . $rowMenu["fat"] . '</th>
        <th>' . $rowMenu["carbo"] . '</th>
    </tr>

    </table>
</body>
</html>
');
}
$mpdf->AddPage();
$resultMenu = $conn->query("set names utf8");
$sqlMenu = "SELECT id, (SELECT name FROM Program WHERE id=program_id) as program,date_start, day_of_the_week,kcal, protein, fat, carbo
FROM Menu WHERE id = '$menu_id'";
$resultMenu = $conn->query($sqlMenu);
while ($rowMenu = $resultMenu->fetch_assoc()) {
    $menuid = $rowMenu["id"];
    $date = DateTime::createFromFormat("Y-m-d", $rowMenu["date_start"]);
    $date_start = $date->format("d-m-y");
    $day = date('l', strtotime($rowMenu["date_start"]));
    if ($day == 'Monday') {
        $day = 'Понедельник';
    } else if ($day == 'Tuesday') {
        $day = 'Вторник';
    } else if ($day == 'Wednesday') {
        $day = 'Среда';
    } else if ($day == 'Thursday') {
        $day = 'Четверг';
    } else if ($day == 'Friday') {
        $day = 'Пятница';
    } else if ($day == 'Saturday') {
        $day = 'Суббота';
    } else if ($day == 'Sunday') {
        $day = 'Воскресенье';
    }

    $mpdf->WriteHTML('
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="../../css/bootstrap.min.css">
<style>
@font-face {
font-family: dejaVu; /* Имя шрифта */
src: url(ttfonts/DejaVuSerifCondensed.ttf); /* Путь к файлу со шрифтом */
}
tr.type th {padding-top: 15px;}
tr td {padding-top: 5px; padding-bottom:5px;}
tr td.portion {padding-left:10px}
tr.sum th {padding-top: 5px;}
tr, th, td, p {font-family: dejaVu, serif;}
</style>
</head>
<body>
<img src="../../img/doscat_logo.png" style="width: 40%; margin-bottom: 30px;">
<table style="width:100%;">
<tbody>

<tr>
  <th>Программа:</th>
  <td colspan="2">' . $rowMenu["program"] . '</td>
</tr>

<tr>
  <th>Дата меню:</th>
  <td>' . $date_start . '</td>
</tr>
<tr>
  <th>День недели:</th>
  <td>' . $day . '</td>
</tr>

');
    $resultType = $conn->query('set names utf8');
    $sqlType = "SELECT DISTINCT m.food_type_id,f.type_name
    FROM Menu_Foods m JOIN Food_Type f ON f.id = m.food_type_id WHERE m.menu_id = '$menuid' ORDER by f.sort";
    $resultType = $conn->query($sqlType);
    while ($rowType = $resultType->fetch_assoc()) {
        $type_id = $rowType["food_type_id"];
        $type_name = $rowType["type_name"];
        $mpdf->WriteHTML("
    <tr class='type'>
        <th>" . $type_name . "</th>
        <th style='width:20%;'>Выход</th>
        <th>Ккал</th>
        <th>Белок</th>
        <th>Жир</th>
        <th>Углеводы</th>
    </tr>

    ");
        $resultFood = $conn->query("set names utf8");
        $sqlFood = "SELECT f.id,f.name, m.portion, TRUNCATE((f.kcal*m.portion/100),2) as calcKcal, TRUNCATE((f.protein*m.portion/100),2) as calcPro,
        TRUNCATE((f.fat*m.portion/100),2) as calcFat, TRUNCATE((f.carbohydrate*m.portion/100),2) as calcCarbo
        FROM Menu_Foods m JOIN Foods f ON f.id = m.food_id
        WHERE m.menu_id = '$menuid' and m.food_type_id = '$type_id'";
        $resultFood = $conn->query($sqlFood);

        while ($rowFood = $resultFood->fetch_assoc()) {
            $food_id = $rowFood["id"];
            $mpdf->WriteHTML("
    <tr>
        <td>" . $rowFood["name"] . "</td>
        <td class='portion'>" . $rowFood["portion"] . "</td>
        <td>" . $rowFood["calcKcal"] . "</td>
        <td>" . $rowFood["calcPro"] . "</td>
        <td>" . $rowFood["calcFat"] . "</td>
        <td>" . $rowFood["calcCarbo"] . "</td>
    </tr>
    ");
        }
        $resultSumType = $conn->query("set names utf8");
        $sqlSumType = "SELECT sum(TRUNCATE((f.kcal*m.portion/100),2)) as sumKcal, sum(TRUNCATE((f.protein*m.portion/100),2)) as sumPro,
        sum(TRUNCATE((f.fat*m.portion/100),2)) as sumFat, sum(TRUNCATE((f.carbohydrate*m.portion/100),2)) as sumCarbo
        FROM Menu_Foods m JOIN Foods f ON f.id = m.food_id
        WHERE m.menu_id = '$menuid' and m.food_type_id = '$type_id'";
        $resultSumType = $conn->query($sqlSumType);

        while ($rowSumType = $resultSumType->fetch_assoc()) {
            $mpdf->WriteHTML('

                <tr style="background-color: #c8c8c8">
                    <td width="25%"></td>
                    <td>Калории ' . $type_name . '</td>
                    <td>' . $rowSumType["sumKcal"] . '</td>
                    <td>' . $rowSumType["sumPro"] . '</td>
                    <td>' . $rowSumType["sumFat"] . '</td>
                    <td>' . $rowSumType["sumCarbo"] . '</td>
                </tr>
            ');
        }
    }
    $mpdf->WriteHTML('
</tbody>
    <tr class="sum" style="background-color: #c8c8c8;">
        <th width="25%"></th>
        <th>Всего</th>
        <th>' . $rowMenu["kcal"] . '</th>
        <th>' . $rowMenu["protein"] . '</th>
        <th>' . $rowMenu["fat"] . '</th>
        <th>' . $rowMenu["carbo"] . '</th>
    </tr>

    </table>
</body>
</html>
');
}
$mpdf->Output("Меню.pdf", "D");
exit;

?>
