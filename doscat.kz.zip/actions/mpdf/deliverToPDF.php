<?php
header('Content-type: text/html; charset=utf8');
include("../bd.php");
session_start();
$gym_id = $_SESSION['gym_id'];
$status = $_SESSION['status'];
include("../filter.php");
include('mpdf.php');
//ini_set('error_reporting', E_ALL);
//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);
$c_date = filter("date");
$date = DateTime::createFromFormat("d-m-Y", $c_date);
$date_start = $date->format("Y-m-d");
$mpdf = new mPDF();

$mpdf->WriteHTML('
<!DOCTYPE html>
<html>
<head>
<title>Наряды в PDF</title>
<link rel="stylesheet" type="text/css" href="../../css/bootstrap.min.css">
<style>
@font-face {
font-family: dejaVu; /* Имя шрифта */
src: url(ttfonts/DejaVuSerifCondensed.ttf); /* Путь к файлу со шрифтом */
}
tr.type th {padding-top: 15px;}
tr td, tr th {padding-top: 5px; padding-bottom:5px;width:100px; border: 1px solid #798d8f;padding-left: 5px;}
tr, th, td, p {font-family: dejaVu, serif;}
p {display: inline-block}
</style>
</head>
<body>
<img src="../../img/doscat_logo.png" style="width: 20%; margin-bottom: 5px;float: right">
<p style="text-align: center;margin-top: 15px"><b>Список доставки</b></p>
<p>Дата доставки: '.$c_date.'</p>
<table style="width:100%;margin-top:20px">
<thead>
    <tr>
        <th>№</th>
        <th width="35%">Адрес</th>
        <th>Получатель</th>
        <th>План питания</th>
        <th width="5%">Кол-во</th>
        <th>Комментарий</th>
        <th width="5%">Время план</th>
        <th>Подпись получено</th>
        <th width="5%">Время факт</th>
        <th>Курьер</th>
    </tr>
</thead>
<tbody>
');
$result = $conn->query("set names utf8");
$sum_quantity = 0;
if($status == 2) {
    $query = "SELECT c.id, u.custom_address,c.date, (SELECT address FROM Gyms WHERE id = u.id_gym) as 'gym',
u.first_name, u.last_name, u.phone, (SELECT (SELECT name FROM Program WHERE id = program_id) as 'name' FROM Product WHERE id = (SELECT product_id FROM Plans WHERE id = c.plan_id)) as 'plan',
(SELECT quantity FROM Delivery WHERE calendar_id = c.id) as 'quantity', (SELECT comment FROM Delivery WHERE calendar_id = c.id) as 'comment',
(SELECT date_time FROM Delivery WHERE calendar_id = c.id) as 'time', (SELECT first_name FROM Users WHERE id in (SELECT courier FROM Delivery WHERE calendar_id = c.id)) as 'courier_name', (SELECT last_name FROM Users WHERE id in (SELECT courier FROM Delivery WHERE calendar_id = c.id)) as 'courier_lname'
FROM Calendars c JOIN Users u ON u.id = (SELECT user_id FROM Plans WHERE id = c.plan_id) WHERE c.date = '$date_start' AND u.id_gym = '$gym_id'";
} else {
    $query = "SELECT c.id, u.custom_address,c.date, (SELECT address FROM Gyms WHERE id = u.id_gym) as 'gym',
u.first_name, u.last_name, u.phone, (SELECT (SELECT name FROM Program WHERE id = program_id) as 'name' FROM Product WHERE id = (SELECT product_id FROM Plans WHERE id = c.plan_id)) as 'plan',
(SELECT quantity FROM Delivery WHERE calendar_id = c.id) as 'quantity', (SELECT comment FROM Delivery WHERE calendar_id = c.id) as 'comment',
(SELECT date_time FROM Delivery WHERE calendar_id = c.id) as 'time', (SELECT first_name FROM Users WHERE id in (SELECT courier FROM Delivery WHERE calendar_id = c.id)) as 'courier_name', (SELECT last_name FROM Users WHERE id in (SELECT courier FROM Delivery WHERE calendar_id = c.id)) as 'courier_lname'
FROM Calendars c JOIN Users u ON u.id = (SELECT user_id FROM Plans WHERE id = c.plan_id) WHERE c.date = '$date_start' ORDER BY (SELECT courier FROM Delivery WHERE calendar_id = c.id) DESC";
}

$result = $conn->query($query);
while ($row = $result->fetch_assoc()) {
    $address = $row["custom_address"];
    if($row["custom_address"] == ""){
        $address = $row["gym"];
    }
    if($row["quantity"] == ""){
        $row["quantity"] = 1;
    }
    $sum_quantity += $row['quantity'];
    $mpdf->WriteHTML('
<tr>
    <td>'.$row['id'].'</td>
    <td>'.$address.'</td>
    <td style="width:25%">'.$row['first_name']." ".$row['last_name']."<br>".$row['phone'].'</td>
    <td>'.$row['plan'].'</td>
    <td style="width:30px;text-align: center">'.$row['quantity'].'</td>
    <td>'.$row['comment'].'</td>
    <td style="width:30px">'.$row['time'].'</td>
    <td></td>
    <td style="width:30px"></td>
    <td>'.$row['courier_name'].' '.$row['courier_lname'].'</td>
</tr>
');
?>
<?php
}
$mpdf->WriteHTML('
</tbody>
</table>
<table style=" font-size: 12px">
<tr style="border-color: #ffffff;">
<th width="100%">Общее количество - '.$sum_quantity.' шт.</th>
</tr>
</table>

</body>
</html>
');
$mpdf->Output();

exit;

?>
