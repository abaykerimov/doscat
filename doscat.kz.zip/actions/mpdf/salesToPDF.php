<?php
header('Content-type: text/html; charset=utf8');
include("../bd.php");
session_start();
$gym_id = $_SESSION['gym_id'];
$status = $_SESSION['status'];
include("../filter.php");
include('mpdf.php');
//ini_set('error_reporting', E_ALL);
//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);

$d = filter("d");
$g = filter("g");

$mpdf = new mPDF();

$mpdf->WriteHTML('
<!DOCTYPE html>
<html>
<head>
<title>Продажи в PDF</title>
<link rel="stylesheet" type="text/css" href="../../css/bootstrap.min.css">
<style>
@font-face {
font-family: dejaVu; /* Имя шрифта */
src: url(ttfonts/DejaVuSerifCondensed.ttf); /* Путь к файлу со шрифтом */
}
tr.type th {padding-top: 15px;}
tr td, tr th {padding-top: 5px; padding-bottom:5px;width:100px; border: 1px solid #798d8f;padding-left: 5px;}
tr, th, td, p {font-family: dejaVu, serif;}
p {display: inline-block}
</style>
</head>
<body>
<img src="../../img/doscat_logo.png" style="width: 20%; margin-bottom: 30px;float: right">
<p style="text-align: center;margin-top: 70px"><b>Список продаж</b></p>
<table id="table" style="width:100%;margin-top:20px">
<thead>
    <tr>
        <th>№</th>
        <th>Дата</th>
        <th>ФИО</th>
        <th>Спортзал</th>
        <th>План питания</th>
        <th>Кол-во</th>
        <th>Стоимость</th>
        <th>Агентские</th>
        <th>Тип доставки</th>
    </tr>
</thead>
<tbody>
');
$result = $conn->query("set names utf8");
$sum_quantity = 0;
$commission = 0;
if($status == 2){
    if(!isset($d)) {
        $query = "SELECT c.id, c.date, u.first_name, u.last_name,(SELECT name FROM Gyms WHERE id = u.id_gym) as 'gym_name',(SELECT (SELECT name FROM Program WHERE id = program_id) as 'name' FROM Product WHERE id = (SELECT product_id FROM Plans WHERE id = c.plan_id)) as 'plan', d.quantity,
    (SELECT price*d.quantity FROM Product WHERE id = (SELECT product_id FROM Plans WHERE id = c.plan_id)) as 'price', (SELECT commission*d.quantity FROM Product WHERE id = (SELECT product_id FROM Plans WHERE id = c.plan_id)) as 'commission',
    (SELECT type FROM Product WHERE id = (SELECT product_id FROM Plans WHERE id = c.plan_id)) as 'type'
    FROM Calendars c JOIN Users u ON u.id = (SELECT user_id FROM Plans WHERE id = c.plan_id) JOIN Delivery d ON d.calendar_id = c.id
    WHERE d.status = 1 AND u.id_gym = '$gym_id'";
    } else {
        $query = "SELECT c.id, c.date, u.first_name, u.last_name,(SELECT name FROM Gyms WHERE id = u.id_gym) as 'gym_name',(SELECT (SELECT name FROM Program WHERE id = program_id) as 'name' FROM Product WHERE id = (SELECT product_id FROM Plans WHERE id = c.plan_id)) as 'plan', d.quantity,
    (SELECT price*d.quantity FROM Product WHERE id = (SELECT product_id FROM Plans WHERE id = c.plan_id)) as 'price', (SELECT commission*d.quantity FROM Product WHERE id = (SELECT product_id FROM Plans WHERE id = c.plan_id)) as 'commission',
    (SELECT type FROM Product WHERE id = (SELECT product_id FROM Plans WHERE id = c.plan_id)) as 'type'
    FROM Calendars c JOIN Users u ON u.id = (SELECT user_id FROM Plans WHERE id = c.plan_id) JOIN Delivery d ON d.calendar_id = c.id
    WHERE d.status = 1 AND u.id_gym = '$gym_id' AND c.date = '$d'";
    }
}
else {
    if(empty($d) && empty($g)) {
        $query = "SELECT c.id, c.date, u.first_name, u.last_name,(SELECT name FROM Gyms WHERE id = u.id_gym) as 'gym_name',(SELECT (SELECT name FROM Program WHERE id = program_id) as 'name' FROM Product WHERE id = (SELECT product_id FROM Plans WHERE id = c.plan_id)) as 'plan', d.quantity,
    (SELECT price*d.quantity FROM Product WHERE id = (SELECT product_id FROM Plans WHERE id = c.plan_id)) as 'price', (SELECT commission*d.quantity FROM Product WHERE id = (SELECT product_id FROM Plans WHERE id = c.plan_id)) as 'commission',
    (SELECT type FROM Product WHERE id = (SELECT product_id FROM Plans WHERE id = c.plan_id)) as 'type'
    FROM Calendars c JOIN Users u ON u.id = (SELECT user_id FROM Plans WHERE id = c.plan_id) JOIN Delivery d ON d.calendar_id = c.id
    WHERE d.status = 1";
    } elseif(!empty($d) && empty($g)) {
        $query = "SELECT c.id, c.date, u.first_name, u.last_name,(SELECT name FROM Gyms WHERE id = u.id_gym) as 'gym_name',(SELECT (SELECT name FROM Program WHERE id = program_id) as 'name' FROM Product WHERE id = (SELECT product_id FROM Plans WHERE id = c.plan_id)) as 'plan', d.quantity,
    (SELECT price*d.quantity FROM Product WHERE id = (SELECT product_id FROM Plans WHERE id = c.plan_id)) as 'price', (SELECT commission*d.quantity FROM Product WHERE id = (SELECT product_id FROM Plans WHERE id = c.plan_id)) as 'commission',
    (SELECT type FROM Product WHERE id = (SELECT product_id FROM Plans WHERE id = c.plan_id)) as 'type'
    FROM Calendars c JOIN Users u ON u.id = (SELECT user_id FROM Plans WHERE id = c.plan_id) JOIN Delivery d ON d.calendar_id = c.id
    WHERE d.status = 1 AND c.date = '$d'";
    } elseif(empty($d) && !empty($g)) {
        $query = "SELECT c.id, c.date, u.first_name, u.last_name,(SELECT name FROM Gyms WHERE id = u.id_gym) as 'gym_name',(SELECT (SELECT name FROM Program WHERE id = program_id) as 'name' FROM Product WHERE id = (SELECT product_id FROM Plans WHERE id = c.plan_id)) as 'plan', d.quantity,
    (SELECT price*d.quantity FROM Product WHERE id = (SELECT product_id FROM Plans WHERE id = c.plan_id)) as 'price', (SELECT commission*d.quantity FROM Product WHERE id = (SELECT product_id FROM Plans WHERE id = c.plan_id)) as 'commission',
    (SELECT type FROM Product WHERE id = (SELECT product_id FROM Plans WHERE id = c.plan_id)) as 'type'
    FROM Calendars c JOIN Users u ON u.id = (SELECT user_id FROM Plans WHERE id = c.plan_id) JOIN Delivery d ON d.calendar_id = c.id
    WHERE d.status = 1 AND u.id_gym = '$g'";
    } elseif(!empty($d) && !empty($g)) {
        $query = "SELECT c.id, c.date, u.first_name, u.last_name,(SELECT name FROM Gyms WHERE id = u.id_gym) as 'gym_name',(SELECT (SELECT name FROM Program WHERE id = program_id) as 'name' FROM Product WHERE id = (SELECT product_id FROM Plans WHERE id = c.plan_id)) as 'plan', d.quantity,
    (SELECT price*d.quantity FROM Product WHERE id = (SELECT product_id FROM Plans WHERE id = c.plan_id)) as 'price', (SELECT commission*d.quantity FROM Product WHERE id = (SELECT product_id FROM Plans WHERE id = c.plan_id)) as 'commission',
    (SELECT type FROM Product WHERE id = (SELECT product_id FROM Plans WHERE id = c.plan_id)) as 'type'
    FROM Calendars c JOIN Users u ON u.id = (SELECT user_id FROM Plans WHERE id = c.plan_id) JOIN Delivery d ON d.calendar_id = c.id
    WHERE d.status = 1 AND u.id_gym = '$g' AND c.date = '$d'";
    }

}
$result = $conn->query($query);
while ($row = $result->fetch_assoc()) {
    $sum_quantity += $row['quantity'];
    $commission += $row['commission'];

    $date = DateTime::createFromFormat('Y-m-d', $row['date']);
    $date_d = $date->format("d-m-Y");
    $type = $row['type'];
    $t = '';
    if($type == 0){$t = 'По адресу';} elseif($type == 1){$t = 'В спортзал';} else{$t = 'Особые условия';}
    $mpdf->WriteHTML('
<tr>
    <td>'.$row['id'].'</td>
    <td>'.$date_d.'</td>
    <td>'.$row['first_name']." ".$row['last_name'].'</td>
    <td>'.$row['gym_name'].'</td>
    <td>'.$row['plan'].'</td>
    <td style="text-align: center">'.$row['quantity'].'</td>
    <td>'.$row['price'].'</td>
    <td>'.$row['commission'].'</td>
    <td>'.$t.'</td>
</tr>
');
    ?>
    <?php
}
$mpdf->WriteHTML('

</tbody>

</table>
<table style=" font-size: 12px">
<tr style="border-color: #ffffff;">
<th width="100%">Общее количество - '.$sum_quantity.' шт.</th>
</tr>
<tr style="border-color: #ffffff"><th>Общая агентская стоимость - '.$commission.' тг.</th>
</tr>
</table>

<script src="../../js/jquery-1.11.3.min.js" type="text/javascript"></script>
<script type="text/javascript">
var output = document.getElementById("table");
    output.innerHTML = "test";
</script>
</body>
</html>
');
$mpdf->Output();

exit;

?>
