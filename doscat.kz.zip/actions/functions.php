<?php
//session_start();
//$id = $_SESSION["user_id"];
//ini_set('error_reporting', E_ALL);
//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);

function check_length($value = "", $min, $max) {
    $result = (mb_strlen($value) < $min || mb_strlen($value) > $max);
    return !$result;
}

function balance($parameter) {

    include(__DIR__ . "/bd.php");

    $query = $conn->prepare("SELECT sum(lastPayment) as 'plus' FROM HistoryOfPayment WHERE user_id = ?");
    $query->bind_param('i', $parameter);
    $query->execute();
    $query->store_result();
    if ($query->num_rows > 0) {
        $query->bind_result($plus);
        $query->fetch();
    } else {
        $plus = 0;
    }
    $query->close();

    //$query_images = $conn->prepare("SELECT sum(price*days) as 'minus' FROM Plans WHERE user_id = ?");
    $query_images = $conn->prepare("SELECT sum(p.price*d.quantity) as 'minus' FROM Delivery d JOIN Plans p ON p.id = (SELECT plan_id FROM Calendars WHERE id = d.calendar_id) WHERE d.user_id = ? and d.status = 1");
    $query_images->bind_param('i', $parameter);
    $query_images->execute();
    $query_images->store_result();
    if ($query_images->num_rows > 0) {
        $query_images->bind_result($minus);
        $query_images->fetch();
    } else {
        $minus = 0;
    }
    $query_images->close();

    return ($plus-$minus);
}

function active($id) {

    //require_once __DIR__ . '/../bd.php';
    include(__DIR__ . "/bd.php");

    $var = array();

    if (!empty($id) and is_numeric($id)) {

        //SELECT COUNT(d.id), min(c.date) FROM Calendars c JOIN Delivery d ON c.id = d.calendar_id WHERE c.date <= DATE_ADD(CURDATE(),INTERVAL 1 DAY) and d.status = 1 and c.plan_id = ?
        //нужно получить данные по плану, так как в один день он может купить, затем сменить тариф, то сортируем по id
            $query_plan = $conn->prepare("SELECT plan.id as 'id', plan.date as `date_start`, DATE_ADD(plan.date,INTERVAL days+p.freezing DAY) as `date_end`, (SELECT min(date) FROM Calendars WHERE plan_id = plan.id) as `date_start_eat`, p.freezing as 'freezing', p.id as 'id_product', p.description2 as 'name_product', (SELECT name FROM Program WHERE id = p.program_id) as 'name_program', plan.price, plan.days, (SELECT COUNT(d.id) FROM Calendars c JOIN Delivery d ON c.id = d.calendar_id WHERE d.status = 1 and c.plan_id = plan.id) as 'days_off', (SELECT COUNT(id) FROM Calendars WHERE date <= DATE_ADD(CURDATE(),INTERVAL 0 DAY) and plan_id = plan.id) as 'days_notchange', DATEDIFF(DATE_ADD(plan.date,INTERVAL days+p.freezing DAY),DATE_ADD(CURDATE(),INTERVAL 1 DAY))-1 as 'days_on', (SELECT count(id) FROM Calendars WHERE plan_id = plan.id) as 'days_count_from_cal' FROM Plans plan JOIN Product p ON plan.product_id = p.id WHERE user_id = ? and DATE_ADD(plan.date,INTERVAL plan.days+p.freezing DAY) >= CURDATE() ORDER by plan.id DESC LIMIT 1");
        $query_plan->bind_param('i', $id);
        $query_plan->execute();
        $query_plan->store_result();
        if ($query_plan->num_rows > 0) {
            $query_plan->bind_result($id_plan, $date_start, $date_end, $date_start_eat, $freezing, $id_product, $name_product, $name_program, $price, $days, $days_off, $days_notchange, $days_on,$days_count_from_cal);
            while ($query_plan->fetch()) {

                //чистые, еще не потерянные дни без воскресений
                $days_can_save = 0;

                if ($id_plan > 0) {
                    //все ок, значит подписка есть
                    $date_begin = date('Y-m-d');
                    $date_begin = date('Y-m-d', strtotime($date_begin.' + 2 days'));

                    $date = $date_begin;
                    while ($date <= $date_end) {
                        $date_arr=explode("-", $date);
                        if (date("w",mktime (0, 0, 0, $date_arr[1], $date_arr[2], $date_arr[0])) > 0) {
                            $days_can_save++;
                        }
                        $date = date('Y-m-d', strtotime($date.' + 1 days'));
                    }

                    if (date("G") < 15) {
                        $days_on++;
                        $days_can_save++;

                        //если завтра стоит питание, то я должен считать его как не пропавшее
                        //$query_images = $conn->prepare("SELECT id FROM Calendars WHERE plan_id = ? and date = ?");
                        //$query_images->bind_param('is', $id_plan, date('Y-m-d', strtotime(date('Y-m-d').' + 1 days')));
                        //$query_images->execute();
                        //$query_images->store_result();
                        //if ($query_images->num_rows > 0) {
                        //    $days_off = $days_off - 1;
                        //}
                        //$query_images->close();

                    }

                    $var[] = array(
                        'status' => 'true',
                        'id_plan' => $id_plan,
                        'date_start' => $date_start,
                        'date_end' => $date_end,
                        'date_start_eat' => $date_start_eat,
                        'freezing' => $freezing,
                        'id_product' => $id_product,
                        'name_product' => $name_program,
                        'name_program' => $name_program,
                        'price' => $price,
                        //всего дней, которые он может есть
                        'days' => $days,
                        //дни, которые уже не вернуть и которые он уже поел (достаются с таблицы доставко со статусом- доставлено)
                        'days_off' => $days_off,
                        //дни, которые остались до конца с послезавтра
                        'days_on' => $days_on,
                        //дни, которые есть возможность сохранить, исключая воскресенье, начиная с послезавтра
                        'days_can_save' => $days_can_save,
                        //это число дней тупо из календаря для этого тарифа
                        'days_count_from_cal' => $days_count_from_cal,
                        //дни, которые уже не вернуть
                        'days_notchange' => $days_notchange
                    );

                } else {
                    //пришли нулы, не активен
                    $var[] = array(
                        'status' => 'false',
                        'id_plan' => $id_plan,
                        'date_start' => $date_start,
                        'date_end' => $date_end,
                        'freezing' => $freezing,
                        'id_product' => $id_product,
                        'name_product' => $name_program,
                        'name_program' => $name_program,
                        'price' => $price,
                        'days' => $days,
                        //дни, которые уже не вернуть
                        'days_off' => $days_off,
                        //дни, которые остались до конца
                        'days_on' => $days_on,
                        //дни, которые есть возможность сохранить, исключая воскресенье, начиная с послезавтра
                        'days_can_save' => $days_can_save,
                        //это число дней тупо из календаря для этого тарифа
                        'days_count_from_cal' => $days_count_from_cal,
                        //дни, которые уже не вернуть
                        'days_notchange' => $days_notchange
                    );
                }

            }
        } else {
            $var[] = array(
                'status' => 'error'
            );
        }
        $query_plan->close();

    } else {
        $var[] = array(
            'status' => 'error'
        );
    }

    return $var[0];
}

function human_date($date)
{
    $months = array(1 => 'января', 2 => 'февраля', 3 => 'марта',
        4 => 'апреля', 5 => 'мая', 6 => 'июня',
        7 => 'июля', 8 => 'августа', 9 => 'сентября',
        10 => 'октября', 11 => 'ноября', 12 => 'декабря');

    $date = new DateTime($date);
    $month = $months[$date->format('n')];

    return $date->format("d {$month} Y").' г';
}
function numberforday ($date) {
    if (!empty($date)) {
        if ($date == 0) {$date = "Воскресенье";}
        if ($date == 1) {$date = "Понедельник";}
        if ($date == 2) {$date = "Вторник";}
        if ($date == 3) {$date = "Среда";}
        if ($date == 4) {$date = "Четверг";}
        if ($date == 5) {$date = "Пятница";}
        if ($date == 6) {$date = "Суббота";}
        return $date;
    } else {
        return "";
    }
}
function format_date($date)
{
    if (!empty($date)) {
        $date = new DateTime($date);
        return $date->format("d-m-Y").'';
    } else {
        return "";
    }

}

function declension_words($num,$arWords){
    if ($num < 21){
        if ($num == 1)
            $w = $arWords[0];
        elseif ($num > 1 && $num < 5)
            $w = $arWords[1];
        else
            $w = $arWords[2];
        return $w;
    } else {
        $l = (int)substr($num, -1);
        if ($l == 1)
            $w = $arWords[0];
        elseif ($l > 1 && $l < 5)
            $w = $arWords[1];
        else
            $w = $arWords[2];
        return $w;
    }
}

function create_calendar($id,$id_product,$price,$amount_days,$freezing,$active_plan,$program_name,$date_start,$Delivery_inPlans) {
    include(__DIR__ . "/bd.php");

    $query = $conn->prepare('INSERT INTO Plans (user_id, product_id, date, price, days, delivery) VALUES (?, ?, ?, ?, ?, ?)');
    $query->bind_param('iisiii', $id, $id_product, $date_start, $price, $amount_days,$Delivery_inPlans);
    $query->execute();
    if ($conn->errno) {

        $data[] = array(
            'status' => 'ERROR'
        );

        die('Select Error (' . $conn->errno . ') ' . $conn->error);
    } else {
        $insert_id = $conn->insert_id;

        //теперь тут нужно составить календарь в цикле
        $date_begin = $date_start;
        $date_end = date('Y-m-d', strtotime($date_begin.' + '.($amount_days+$freezing).' days'));

        //$date = date('Y-m-d', strtotime($date_begin.' + 2 days'));
        $date = $date_begin;
        $count_for_amo_day = 0;
        while ($date <= $date_end) {
            $date_arr=explode("-", $date);
            if (date("w",mktime (0, 0, 0, $date_arr[1], $date_arr[2], $date_arr[0])) > 0) {
                //вот тут делаем инсерт в календарь, если количество итераций не выше чем количество дней
                if ($count_for_amo_day < $amount_days) {
                    $query_calendar = $conn->prepare('INSERT INTO Calendars (plan_id, date) VALUES (?, ?)');
                    $query_calendar->bind_param('is', $insert_id, $date);
                    $query_calendar->execute();
                    if ($conn->errno) {
                        die('Select Error (' . $conn->errno . ') ' . $conn->error);
                    }
                    $query_calendar->close();
                    $count_for_amo_day++;
                }

            }
            $date = date('Y-m-d', strtotime($date.' + 1 days'));
        }


        $data[] = array(
            'status' => 'SUCCESS',
            'message' => "Вы перешли на тариф ".$program_name.". Ваш календарь питания сформирован.",
            'confirm' => true
        );

    }
    $query->close();

    return $data;
}

function randomPassword() {
    $alphabet = '1234567890';
    $pass = array(); //remember to declare $pass as an array
    $alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
    for ($i = 0; $i < 5; $i++) {
        $n = rand(0, $alphaLength);
        $pass[] = $alphabet[$n];
    }
    return implode($pass); //turn the array into a string
}
?>