<?php
header('Content-type: text/html; charset=utf8');
session_start();
$fname = $_FILES['file']['name'];
$img_ext = strrchr($fname, '.');
if(is_array($_FILES)) {
    if(is_uploaded_file($_FILES['file']['tmp_name'])) {
        $sourcePath = $_FILES['file']['tmp_name'];
        $targetPath = "../uploads/";
        $new        = rand(0000,9999);
        $newfilename = $new.$fname;
        if (!is_dir($targetPath)) mkdir($targetPath);
        $targetPath = $targetPath . basename($newfilename);
        if(move_uploaded_file($sourcePath,$targetPath)) {
            ?>
            <img id="avatar" src="<?php echo $targetPath; ?>" width="100px" height="100px" />
            <?php
        }
    }
}
?>