<?php
$servername = "srv-db-plesk09.ps.kz:3306";
$username = "dosca_doscatkz";
$password = "6wAaa1_6";
$dbname = "doscatkz_mainBase";
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$conn->query("set names utf8");
?>