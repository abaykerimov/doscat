<?php
header('Content-type: text/html; charset=utf8');
session_start();
include("../bd.php");
include("../actions/filter.php");
include("../actions/functions.php");
$id = $_SESSION["user_id"];
$resultUser = $conn->query("set names utf8");
$sqlUser = "SELECT * FROM Users WHERE id = '$id'";
$resultUser = $conn->query($sqlUser);
$rowUser = $resultUser->fetch_assoc();
$user_status = $rowUser['user_status'];

$photo = filter('photo');
$name = filter('name');
$description = filter('description');
$kcal = filter('kcal');
$protein = filter('protein');
$fat = filter('fat');
$carbo = filter('carbo');

$action = $_POST["action"];
$food_id = $_POST["food_id"];
$menu_id = $_POST["menu_id"];
$food_value = $_POST["food_value"];
if (!empty($action)) {
    switch ($action) {
        case "addFood":
            $get_type = filter("get_type");
            $unit = filter("unit");
            $price = filter("price");
            $query = $conn->query("set names utf8");
            $query = $conn->query("SELECT id FROM Foods WHERE name = '$name'");
            if ($query->num_rows > 0) {
                echo '<script>alert("Такой рецепт уже существует!")</script>';

            } else {
                $insert_row = $conn->query("set names utf8");
                $insert_row = $conn->prepare('INSERT INTO Foods (photo, name, description, kcal, protein, fat, carbohydrate, unit, price, isDessert) VALUES (?,?,?,?,?,?,?,?,?,?)');
                $insert_row->bind_param('sssssssiii', $photo, $name, $description, $kcal, $protein, $fat, $carbo, $unit, $price, $get_type);
                $insert_row->execute();
                $insert_row->close();
            }
            break;
        case "editFood":
            $check = filter("check");
            $query = $conn->query("set names utf8");
            $query = $conn->prepare("UPDATE Foods SET name = '$name', photo = '$photo', description = '$description', kcal = '$kcal', protein = '$protein', fat = '$fat', carbohydrate = '$carbo',isCheck = '$check' WHERE id = ?");
            $query->bind_param('i', $food_id);
            $query->execute();
            if ($conn->errno) {
                die('Select Error (' . $conn->errno . ') ' . $conn->error);
            }
            $query->close();
            break;
        case "deleteFood":
            if (!empty($food_id)) {
                $query = $conn->prepare('DELETE FROM Foods WHERE id = ?');
                $query->bind_param('i', $food_id);
                $query->execute();
                if ($conn->errno) {
                    die('Select Error (' . $conn->errno . ') ' . $conn->error);
                }
                $query->close();
            }
            break;
        case "get_1":
            include("../actions/getFoodIngredients.php");
            break;
        case "get_2":
            include("../actions/getFoodIngredients.php");
            break;
        case "get_3":
            include("../actions/getFoodIngredients.php");
            break;
        case "get_4":
            include("../actions/getFoodIngredients.php");
            break;
        case "get_5":
            include("../actions/getFoodIngredients.php");
            break;
        case "get_6":
            include("../actions/getFoodIngredients.php");
            break;
        case "get_7":
            include("../actions/getFoodIngredients.php");
            break;
        case "get_8":
            include("../actions/getFoodIngredients.php");
            break;
        case "get_9":
            include("../actions/getFoodIngredients.php");
            break;
        case "get_10":
            include("../actions/getFoodIngredients.php");
            break;
        case "get_11":
            include("../actions/getFoodIngredients.php");
            break;
        case "get_12":
            include("../actions/getFoodIngredients.php");
            break;
        case "get_13":
            include("../actions/getFoodIngredients.php");
            break;
        case "addMenu":
            $program = filter('program');
            $number = rand(1, 100);
            $date_post = filter('date');
            $date = DateTime::createFromFormat('d-m-Y', $date_post);
            $date_start = $date->format("Y-m-d");
            $numKcal = filter('numKcal');
            $kcal = filter("kcal");
            $pro = filter("pro");
            $fat = filter("fat");
            $carbo = filter("carbo");

            $query = $conn->query("set names utf8");
            $query = $conn->prepare('INSERT INTO Menu (program_id, menu_number, date_start, number_kcal,user_id,kcal,protein,fat,carbo) VALUES (?,?,?,?,?,?,?,?,?)');
            $query->bind_param('iisiissss', $program, $number, $date_start, $numKcal, $id, $kcal, $pro, $fat, $carbo);
            $query->execute();
            $query->close();
            break;
        case "addFoods":
            $type = filter('food_types');
            $foods = filter('foods');
            $portion = filter('portion');
            $sql = "SELECT id FROM Menu ORDER BY id DESC LIMIT 1";
            $query = $conn->query($sql);
            while($row = $query->fetch_assoc()) {
                $result = $conn->prepare('INSERT INTO Menu_Foods (food_id, food_type_id, portion, menu_id) VALUES (?,?,?,?)');
                $result->bind_param('iiii', $foods, $type, $portion, $row['id']);
                $result->execute();
            }
            break;
        case "editMenu":
            $menuid = filter("id");
            $program = filter("program");
            $date = filter("date");
            $day = filter("day");
            $query = $conn->query("set names utf8");
            $query = $conn->prepare("UPDATE Menu SET program_id = '$program',date_start = '$date',day_of_the_week = '$day' WHERE id = ?");
            $query->bind_param('i', $menuid);
            $query->execute();
            $query->close();
            break;
        case "editFoods":
            $menuid = filter("id");
            $data_id = filter("data_id");
            $types = filter('food_types');
            $food = filter('foods');
            $portions = filter('portion');
            $query = $conn->query("set names utf8");
            $query = $conn->prepare("UPDATE Menu_Foods SET food_id = '$food',food_type_id = '$types',portion = '$portions' WHERE id = ?");
            $query->bind_param('i', $data_id);
            $query->execute();
            $query->close();
            break;
        case "deleteMenu":
            if (!empty($menu_id)) {
                $query = $conn->prepare('DELETE FROM Menu WHERE id = ?');
                $query->bind_param('i', $menu_id);
                $query->execute();
                if ($query) {
                    $result = $conn->prepare('DELETE FROM Menu_Foods WHERE menu_id = ?');
                    $result->bind_param('i', $menu_id);
                    $result->execute();
                }
                $query->close();
            }
            break;
        case "getAddress":
            $gym_id = filter("gym_id");
            if (!empty($gym_id)) {
                $result = $conn->query("set names utf8");
                $query = "SELECT address FROM Gyms WHERE id = '$gym_id'";
                $result = $conn->query($query);
                while ($row = $result->fetch_assoc()) { ?>
                    <?php echo $row["address"]; ?>
                    <?php
                }
                $result->close();
            }
            break;
        case "addOrder":
            $request_date = filter("request_date");
            $date = DateTime::createFromFormat('d-m-Y', $request_date);
            $date_request = $date->format("Y-m-d");
            $request_time = filter("request_time");
            $user = filter("user");
            $phone = filter("phone");
            $plan = filter("plan");
            $sport = filter("sport");
            $address = filter("address");
            $rcomment = filter("rcomment");
            $comment = filter("comment");
            $status = filter("status");
            $register = filter("register");
            $subscribe = filter("subscribe");
            $acomment = filter("acomment");
            if ($sport != "") {
                $bool = 1;
            } else {
                $bool = 0;
            }
            $insert_row = $conn->query("set names utf8");
            $insert_row = $conn->prepare('INSERT INTO Requests (request_date,request_time,product_id,name,phone,status,subscribe,isRegistered,custom_address,address_bool,gym_id) VALUES (?,?,?,?,?,?,?,?,?,?,?)');
            $insert_row->bind_param('ssisssiisii', $date_request, $request_time, $plan, $user, $phone, $status, $subscribe, $register, $address, $bool, $sport);
            $insert_row->execute();
            $r_id = $insert_row->insert_id;
            if ($insert_row) {
                $query = $conn->query("set names utf8");
                $query = $conn->prepare('INSERT INTO Request_Comments (request_comment, partner_comment, admin_comment, request_id) VALUES (?,?,?,?)');
                $query->bind_param('sssi', $rcomment, $comment, $acomment, $r_id);
                $query->execute();
            }
            $insert_row->close();
            break;
        case "getOrder":
            $order_id = filter("val");
            if (!empty($order_id)) {
                $result = $conn->query("set names utf8");
                $query = "SELECT r.id,r.request_date,r.request_time,(SELECT name FROM Product WHERE id = r.product_id) as product,
                r.name,r.phone,(SELECT status_name FROM Request_Statuses WHERE id=r.status) as 'status_name',r.subscribe,r.isRegistered,(SELECT request_comment FROM Request_Comments WHERE request_id = r.id) as comment,
                r.custom_address,r.address_bool,(SELECT name FROM Gyms WHERE id = r.gym_id) as gym,(SELECT address FROM Gyms WHERE id = r.gym_id) as gym_address,(SELECT partner_comment FROM Request_Comments WHERE request_id = r.id) as pcomment,
                (SELECT admin_comment FROM Request_Comments WHERE request_id = r.id) as acomment
                FROM Requests r WHERE r.id = '$order_id'";
                $result = $conn->query($query);
                while ($row = $result->fetch_assoc()) {
                    $date = DateTime::createFromFormat('Y-m-d', $row['request_date']);
                    $date_start = $date->format("d-m-y"); ?>
                    <form class="form-horizontal" role="form" data-toggle="validator" id="form">
                        <fieldset>
                            <div class="form-group">
                                <label for="inputDate" class="col-lg-4 control-label">Дата заявки:</label>

                                <div class="col-lg-4 text-left">
                                    <p class="get"><?php echo $date_start ?></p>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="inputTime" class="col-lg-4 control-label">Время заявки:</label>

                                <div class="col-lg-4">
                                    <p class="get"><?php echo $row['request_time'] ?></p>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="inputClient" class="col-lg-4 control-label">Клиент (имя, фамилия):</label>

                                <div class="col-lg-4">
                                    <p class="get"><?php echo $row['name'] ?></p>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="inputPhone" class="col-lg-4 control-label">Телефон:</label>

                                <div class="col-lg-4">
                                    <p class="get"><?php echo $row['phone'] ?></p>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="inputPlan" class="col-lg-4 control-label">План питания:</label>

                                <div class="col-lg-4">
                                    <p class="get"><?php echo $row['product'] ?></p>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="inputPlace" class="col-lg-4 control-label">Место доставки:</label>

                                <div class="col-lg-4">
                                    <?php
                                    if ($row['address_bool'] == 0) {
                                        echo "<p class='get'>Свой адрес</p>";
                                    } else {
                                        echo "<p class='get'>" . $row['gym'] . "</p>";
                                    }
                                    ?>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="inputAddress" class="col-lg-4 control-label">Адрес доставки:</label>

                                <div class="col-lg-4">
                                    <?php
                                    if ($row['address_bool'] == 0) {
                                        echo "<p class='get'>" . $row['custom_address'] . "</p>";
                                    } else {
                                        echo "<p class='get'>" . $row['gym_address'] . "</p>";
                                    }
                                    ?>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="inputComment" class="col-lg-4 control-label">Комментарий:</label>

                                <div class="col-lg-4">
                                    <p class="get"><?php echo $row['comment'] ?></p>
                                </div>
                            </div>
                            <hr>

                            <p style="font-size: 17px"><b>Отметки администратора Партнера</b></p>

                            <div class="form-group">
                                <label for="inputComment" class="col-lg-4 control-label">Комментарий:</label>

                                <div class="col-lg-4">
                                    <p class="get"><?php echo $row['pcomment'] ?></p>
                                </div>
                            </div>
                            <?php if ($id == '3' || $id == '5' || $id == '9' || $id == '16') { ?>
                                <hr>
                                <p style="font-size: 17px"><b>Отметки администратора Dostyk Catering</b></p>

                                <div class="form-group">
                                    <label for="inputStatus" class="col-lg-4 control-label">Статус заявки:</label>

                                    <div class="col-lg-4">
                                        <p class="get"><?php echo $row['status_name'] ?></p>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="inputReg" class="col-lg-4 control-label">Регистрация на сайте:</label>

                                    <div class="col-lg-4">
                                        <?php
                                        if ($row['isRegistered'] == 0) {
                                            echo "<p class='get'>Не зарегистрирован</p>";
                                        } else {
                                            echo "<p class='get'>Зарегистрирован</p>";
                                        }
                                        ?>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="inputSub" class="col-lg-4 control-label">Подписка:</label>

                                    <div class="col-lg-4">
                                        <?php
                                        if ($row['subscribe'] == 0) {
                                            echo "<p class='get'>Нет подписки</p>";
                                        } else {
                                            echo "<p class='get'>Есть подписка</p>";
                                        }
                                        ?>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="inputComment" class="col-lg-4 control-label">Комментарий:</label>

                                    <div class="col-lg-4">
                                        <p class='get'>

                                        <p><?php echo $row['acomment'] ?></p>
                                    </div>
                                </div>
                            <?php } ?>

                            <div class="form-group text-center add">
                                <div class="col-lg-12">
                                    <button type="button" class="btn btn-default" data-dismiss="modal">Закрыть</button>
                                    <a class="btn btn-warning" href="editOrder.php?id=<?php echo $row['id'] ?>">Редактировать</a>
                                    <a class="btn btn-danger" onclick="
                                        if (confirm('Вы хотите удалить?')){
                                        getRequest('deleteOrder', <?php echo $row['id'] ?>)}"
                                       data-dismiss="modal">Удалить</a>
                                </div>
                            </div>
                        </fieldset>
                    </form>
                    <?php
                }
                $result->close();
            }
            break;
        case "deleteOrder":
            $order_id = filter("val");
            if (!empty($order_id)) {
                $query = $conn->prepare('DELETE FROM Requests WHERE id = ?');
                $query->bind_param('i', $order_id);
                $query->execute();
                if ($query) {
                    $result = $conn->prepare('DELETE FROM Request_Comments WHERE request_id = ?');
                    $result->bind_param('i', $order_id);
                    $result->execute();
                }
                $query->close();
            }
            break;
        case "editOrder":
            $order_id = filter("order_id");
            $request_date = filter("request_date");
            $date = DateTime::createFromFormat('d-m-Y', $request_date);
            $date_request = $date->format("Y-m-d");
            $request_time = filter("request_time");
            $user = filter("user");
            $phone = filter("phone");
            $plan = filter("plan");
            $sport = filter("sport");
            $address = filter("address");
            $rcomment = filter("rcomment");
            $comment = filter("comment");
            $status = filter("status");
            $register = filter("register");
            $subscribe = filter("subscribe");
            $acomment = filter("acomment");
            if ($sport != "") {
                $bool = 1;
            } else {
                $bool = 0;
            }
            $query = $conn->query("set names utf8");
            $query = $conn->prepare("UPDATE Requests SET request_date='$date_request',request_time='$request_time',name='$user',phone='$phone',status='$status',subscribe='$subscribe',isRegistered='$register',custom_address='$address',address_bool='$bool',gym_id='$sport' WHERE id = ?");
            $query->bind_param('i', $order_id);
            $query->execute();
            if ($query) {
                $sql = "SELECT request_id FROM Request_Comments WHERE request_id = '$order_id'";
                $sql_query = $conn->query($sql);
                if ($sql_query->num_rows == 0) {
                    $insert_row = $conn->query("set names utf8");
                    $insert_row = $conn->prepare('INSERT INTO Request_Comments (request_comment, partner_comment, admin_comment,request_id) VALUES (?,?,?,?)');
                    $insert_row->bind_param('sssi', $rcomment, $comment, $acomment, $order_id);
                    $insert_row->execute();
                } else {
                    $result = $conn->query("set names utf8");
                    $result = $conn->prepare("UPDATE Request_Comments SET request_comment='$rcomment',partner_comment='$comment',admin_comment ='$acomment' WHERE request_id = ?");
                    $result->bind_param('i', $order_id);
                    $result->execute();
                }
            }
            $query->close();
            break;
        case "getOrderRequest":
            $filter_date = filter("val");
            $date = DateTime::createFromFormat('d-m-Y', $filter_date);
            $date_request = $date->format("Y-m-d");
            $result = $conn->query("set names utf8");
            $query = "SELECT r.id,r.request_date,r.request_time,p.name as product,r.name,r.phone,r.status,r.isRegistered,(SELECT request_comment FROM Request_Comments WHERE request_id = r.id) as comment FROM Requests r JOIN Product p ON p.id = r.product_id WHERE r.request_date='$date_request'";
            $result = $conn->query($query);
            while ($row = $result->fetch_assoc()) {
                if ($row['isRegistered'] == 0) {
                    $var = "Не зарегистрирован";
                } else {
                    $var = "Зарегистрирован";
                } ?>
                <tr data-toggle="modal" data-target="#myModal" style="cursor: pointer"
                    onclick="getRequest('getOrder',<?php echo $row['id'] ?>)">
                    <td><?php echo $row['id'] ?></td>
                    <td><?php echo $row['request_date'] ?></td>
                    <td><?php echo $row['request_time'] ?></td>
                    <td><?php echo $row['product'] ?></td>
                    <td><?php echo $row['name'] ?></td>
                    <td><?php echo $row['phone'] ?></td>
                    <td><?php echo $row['status'] ?></td>
                    <td><?php echo $var ?></td>
                    <td><?php echo $row['comment'] ?></td>
                </tr>
                <?php
            }
            $result->close();
            break;
        case "getOrderStatus":
            $status = filter("val");
            $result = $conn->query("set names utf8");
            if ($status != "") {
                $query = "SELECT r.id,r.request_date,r.request_time,p.name as product,r.name,r.phone,r.status,r.isRegistered,(SELECT request_comment FROM Request_Comments WHERE request_id = r.id) as comment FROM Requests r JOIN Product p ON p.id = r.product_id WHERE r.status='$status'";
            } else {
                $query = "SELECT r.id,r.request_date,r.request_time,p.name as product,r.name,r.phone,r.status,r.isRegistered,(SELECT request_comment FROM Request_Comments WHERE request_id = r.id) as comment FROM Requests r JOIN Product p ON p.id = r.product_id";
            }
            $result = $conn->query($query);
            while ($row = $result->fetch_assoc()) {
                if ($row['isRegistered'] == 0) {
                    $var = "Не зарегистрирован";
                } else {
                    $var = "Зарегистрирован";
                } ?>
                <tr data-toggle="modal" data-target="#myModal" style="cursor: pointer"
                    onclick="getRequest('getOrder',<?php echo $row['id'] ?>)">
                    <td><?php echo $row['id'] ?></td>
                    <td><?php echo $row['request_date'] ?></td>
                    <td><?php echo $row['request_time'] ?></td>
                    <td><?php echo $row['product'] ?></td>
                    <td><?php echo $row['name'] ?></td>
                    <td><?php echo $row['phone'] ?></td>
                    <td><?php echo $row['status'] ?></td>
                    <td><?php echo $var ?></td>
                    <td><?php echo $row['comment'] ?></td>
                </tr>
                <?php
            }
            $result->close();
            break;
        case "getOrderRegister":
            $register = filter("val");
            $result = $conn->query("set names utf8");
            if ($register != "") {
                $query = "SELECT r.id,r.request_date,r.request_time,p.name as product,r.name,r.phone,r.status,r.isRegistered,(SELECT request_comment FROM Request_Comments WHERE request_id = r.id) as comment FROM Requests r JOIN Product p ON p.id = r.product_id WHERE r.isRegistered='$register'";
            } else {
                $query = "SELECT r.id,r.request_date,r.request_time,p.name as product,r.name,r.phone,r.status,r.isRegistered,(SELECT request_comment FROM Request_Comments WHERE request_id = r.id) as comment FROM Requests r JOIN Product p ON p.id = r.product_id";
            }
            $result = $conn->query($query);
            while ($row = $result->fetch_assoc()) {
                if ($row['isRegistered'] == 0) {
                    $var = "Не зарегистрирован";
                } else {
                    $var = "Зарегистрирован";
                } ?>
                <tr data-toggle="modal" data-target="#myModal" style="cursor: pointer"
                    onclick="getRequest('getOrder',<?php echo $row['id'] ?>)">
                    <td><?php echo $row['id'] ?></td>
                    <td><?php echo $row['request_date'] ?></td>
                    <td><?php echo $row['request_time'] ?></td>
                    <td><?php echo $row['product'] ?></td>
                    <td><?php echo $row['name'] ?></td>
                    <td><?php echo $row['phone'] ?></td>
                    <td><?php echo $row['status'] ?></td>
                    <td><?php echo $var ?></td>
                    <td><?php echo $row['comment'] ?></td>
                </tr>
                <?php
            }
            $result->close();
            break;
        case "getOrderSubscribe":
            $subscribe = filter("val");
            $result = $conn->query("set names utf8");
            if ($subscribe != "") {
                $query = "SELECT r.id,r.request_date,r.request_time,p.name as product,r.name,r.phone,r.status,r.isRegistered,(SELECT request_comment FROM Request_Comments WHERE request_id = r.id) as comment FROM Requests r JOIN Product p ON p.id = r.product_id WHERE r.subscribe='$subscribe'";
            } else {
                $query = "SELECT r.id,r.request_date,r.request_time,p.name as product,r.name,r.phone,r.status,r.isRegistered,(SELECT request_comment FROM Request_Comments WHERE request_id = r.id) as comment FROM Requests r JOIN Product p ON p.id = r.product_id";
            }
            $result = $conn->query($query);
            while ($row = $result->fetch_assoc()) {
                if ($row['isRegistered'] == 0) {
                    $var = "Не зарегистрирован";
                } else {
                    $var = "Зарегистрирован";
                } ?>
                <tr data-toggle="modal" data-target="#myModal" style="cursor: pointer"
                    onclick="getRequest('getOrder',<?php echo $row['id'] ?>)">
                    <td><?php echo $row['id'] ?></td>
                    <td><?php echo $row['request_date'] ?></td>
                    <td><?php echo $row['request_time'] ?></td>
                    <td><?php echo $row['product'] ?></td>
                    <td><?php echo $row['name'] ?></td>
                    <td><?php echo $row['phone'] ?></td>
                    <td><?php echo $row['status'] ?></td>
                    <td><?php echo $var ?></td>
                    <td><?php echo $row['comment'] ?></td>
                </tr>
                <?php
            }
            $result->close();
            break;
        case "getClientGym":
            $gym = filter("val");
            $resultClient = $conn->query("set names utf8");
            if ($gym == "") {
                $sqlClient = "SELECT u.id,(SELECT name FROM Gyms WHERE id = u.id_gym) as gym,u.first_name,u.last_name,u.phone FROM Users u";
            } elseif ($gym == '0') {
                $sqlClient = "SELECT u.id,(SELECT name FROM Gyms WHERE id = u.id_gym) as gym,u.first_name,u.last_name,u.phone FROM Users u WHERE u.address_boolean='$gym'";
            } elseif ($gym != "") {
                $sqlClient = "SELECT u.id,(SELECT name FROM Gyms WHERE id = u.id_gym) as gym,u.first_name,u.last_name,u.phone FROM Users u WHERE u.id_gym='$gym'";
            }
            $resultClient = $conn->query($sqlClient);
            while ($rowClient = $resultClient->fetch_assoc()) {
                $active = active($rowClient['id']);
                $balance = balance($rowClient['id']);
                ?>
                <tr data-toggle="modal" data-target="#myModal" style="cursor: pointer"
                    onclick="actions('getClient',<?php echo $rowClient['id'] ?>)">
                    <td><?php echo $rowClient['id'] ?></td>
                    <td><?php echo $rowClient['gym'] ?></td>
                    <td><?php echo $rowClient['first_name'] . " " . $rowClient['last_name'] ?></td>
                    <td><?php echo $rowClient['phone'] ?></td>
                    <td><?php echo $active['name_product'] ?></td>
                    <td><?php echo $active['date_end'] ?></td>
                    <td><?php echo $balance ?></td>
                    <td><?php echo $rowClient['comment'] ?></td>
                </tr>
            <?php }
            $resultClient->close();
            break;
        case "getMenuProgram":
            $program = filter("menu_id");
            $get_type = filter("get_type");
            $resultMenu = $conn->query("set names utf8");
            if($program == "") {
                $sqlMenu = "SELECT id, (SELECT name FROM Program WHERE id = program_id) as program, menu_number,date_start,kcal,protein,fat,carbo FROM Menu ORDER BY date_start";
            } else{
                $sqlMenu = "SELECT id, (SELECT name FROM Program WHERE id = program_id) as program, menu_number,date_start,kcal,protein,fat,carbo FROM Menu WHERE program_id = '$program' ORDER BY date_start";
            }
            $resultMenu = $conn->query($sqlMenu);
            $count = 0;
            while ($rowMenu = $resultMenu->fetch_assoc()) {
                $menu_id = $rowMenu['id'];

                $result = $conn->query("set names utf8");
                $sql = "SELECT DISTINCT food_type_id, (SELECT type_name FROM Food_Type WHERE id=food_type_id) as name FROM Menu_Foods m JOIN Food_Type ft ON ft.id=m.food_type_id WHERE menu_id = '$menu_id' ORDER BY ft.sort";
                $result = $conn->query($sql);
                if ($result->num_rows > 0 && $result->num_rows == $get_type){

                    if ($count == 0) {
                        ?>

                        <thead>
                        <tr>
                            <th class='th_name' style="width: 5%">№</th>
                            <th width="10%">Дата недели</th>
                            <?php
                            while ($row = $result->fetch_assoc()) {
                                ?>
                                <!--SELECT DISTINCT `food_type_id` FROM `Menu_Foods`
                                WHERE `menu_id` in (SELECT id FROM Menu WHERE date_start = "2017-01-09") ORDER by `food_type_id`
                                запомни в переменную число количество -->
                                <th><?php echo $row['name'] ?></th>
                            <?php } ?>
                            <th>Ккал</th>
                            <th>Белок</th>
                            <th>Жир</th>
                            <th>Угл</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
                        $count++;
                    }
                    $date = DateTime::createFromFormat('Y-m-d', $rowMenu['date_start']);
                    $date_start = $date->format("d-m-y"); ?>
                <tr data-toggle="modal" data-target="#myModal" style="cursor: pointer"
                    onclick="actions('getMenu',<?php echo $rowMenu['id'] ?>)">
                    <td><?php echo $rowMenu['id'] ?></td>
                    <td width="20%"><?php echo $date_start ?><br>
                        <?php $day = date('l', strtotime($rowMenu['date_start']));
                        if ($day == "Monday") {
                            $day = "Понедельник";
                        } else if ($day == "Tuesday") {
                            $day = "Вторник";
                        } else if ($day == "Wednesday") {
                            $day = "Среда";
                        } else if ($day == "Thursday") {
                            $day = "Четверг";
                        } else if ($day == "Friday") {
                            $day = "Пятница";
                        } else if ($day == "Saturday") {
                            $day = "Суббота";
                        } else if ($day == "Sunday") {
                            $day = "Воскресенье";
                        }
                        echo $day;?><br>
                        <?php echo $rowMenu['program'] ?></td>
                    <?php
                    $resultType = $conn->query("set names utf8");
                    $sqlType = "SELECT DISTINCT food_type_id
                    FROM Menu_Foods m JOIN Food_Type ft ON ft.id=m.food_type_id WHERE menu_id = '$menu_id' ORDER by ft.sort";

                    $resultType = $conn->query($sqlType);
                    if ($resultType->num_rows > 0){
                        while ($rowType = $resultType->fetch_assoc()) {
                            //здесь сравнить переменную с размером массива
                            echo '<td>';
                            $type_id = $rowType['food_type_id'];
                            $resultFood = $conn->query("set names utf8");
                            $sqlFood = "SELECT f.id, f.name, m.portion,TRUNCATE((f.kcal*m.portion/100),2) as calcKcal, TRUNCATE((f.protein*m.portion/100),2) as calcPro,
                        TRUNCATE((f.fat*m.portion/100),2) as calcFat, TRUNCATE((f.carbohydrate*m.portion/100),2) as calcCarbo
                        FROM Menu_Foods m JOIN Foods f ON f.id = m.food_id
                        WHERE m.menu_id = '$menu_id' and m.food_type_id = '$type_id'";
                            $resultFood = $conn->query($sqlFood);

                            while ($rowFood = $resultFood->fetch_assoc()) {
                                ?>
                                <div class="col-md-12"
                                     style="margin-bottom: 10px;padding-left: 0;"><?php echo $rowFood['name'] ?></div>
                            <?php }
                            echo "</td>";
                        } ?>
                        <td class="kcal"><?php echo $rowMenu['kcal'] ?></td>
                        <td class="protein"><?php echo $rowMenu['protein'] ?></td>
                        <td class="fat"><?php echo $rowMenu['fat'] ?></td>
                        <td class="carbo"><?php echo $rowMenu['carbo'] ?></td>
                        </tr>
                    <?php }
                }
            }
            echo '</tbody>';
            break;
        case "getFood":
            $food_id = filter("food_id");
            if (!empty($food_id)) {
                $resultFood = $conn->query("set names utf8");
                $sqlFood = "SELECT * FROM Foods WHERE id = '$food_id'";
                $resultFood = $conn->query($sqlFood);
                while ($rowFood = $resultFood->fetch_assoc()) {
                    ?>
                    <form class="form-horizontal" role="form" data-toggle="validator" id="form">
                        <fieldset>
                            <div class="form-group">
                                <label for="inputDate" class="col-lg-4 control-label">Фото:</label>

                                <div class="col-lg-4 text-left">
                                    <img class="get" src="<?php echo $rowFood['photo'] ?>"/>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="inputTime" class="col-lg-4 control-label">Название:</label>

                                <div class="col-lg-4">
                                    <p class="get"><?php echo $rowFood['name'] ?></p>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="inputClient" class="col-lg-4 control-label">Описание:</label>

                                <div class="col-lg-4">
                                    <p class="get"><?php echo $rowFood['description'] ?></p>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="inputPhone" class="col-lg-4 control-label">Ккалория:</label>

                                <div class="col-lg-4">
                                    <p class="get"><?php echo $rowFood['kcal'] ?></p>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="inputPlan" class="col-lg-4 control-label">Белок:</label>

                                <div class="col-lg-4">
                                    <p class="get"><?php echo $rowFood['protein'] ?></p>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="inputPlace" class="col-lg-4 control-label">Жир:</label>

                                <div class="col-lg-4">
                                    <p class="get"><?php echo $rowFood['fat'] ?></p>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="inputAddress" class="col-lg-4 control-label">Углеводы:</label>

                                <div class="col-lg-4">
                                    <p class="get"><?php echo $rowFood['carbohydrate'] ?></p>
                                </div>
                            </div>
                            <div class="form-group text-center add">
                                <div class="col-lg-12">
                                    <button type="button" class="btn btn-default" data-dismiss="modal">Закрыть</button>
                                    <?php if ($rowFood['isCheck'] == 0 || ($id == 5 || $id == 16 && $rowFood['isCheck'] == 1)) { ?>
                                        <a class="btn btn-warning" href="editFood.php?id=<?php echo $rowFood['id'] ?>">Редактировать</a>
                                        <a class="btn btn-danger" onclick="
                                            if (confirm('Вы хотите удалить?')){
                                            actions('deleteFood', <?php echo $rowFood['id'] ?>)}" data-dismiss="modal">Удалить</a>
                                    <?php } ?>
                                </div>
                            </div>
                        </fieldset>
                    </form>
                    <?php
                }
                $resultFood->close();
            }
            break;
        case "addGym":
            $gym_name = filter("gym_name");
            $gym_address = filter("gym_address");
            $insert_row = $conn->query("set names utf8");
            $insert_row = $conn->prepare('INSERT INTO Gyms (name, address) VALUES (?,?)');
            $insert_row->bind_param('ss', $gym_name, $gym_address);
            $insert_row->execute();
            $insert_row->close();
            break;
        case "deleteGym":
            $gym_id = filter("gym_id");
            if (!empty($gym_id)) {
                $query = $conn->prepare('DELETE FROM Gyms WHERE id = ?');
                $query->bind_param('i', $gym_id);
                $query->execute();
                if ($conn->errno) {
                    die('Select Error (' . $conn->errno . ') ' . $conn->error);
                }
                $query->close();
            }
            break;
        case "editGym":
            $gym_id = filter("gym_id");
            $gym_name = filter("gym_name");
            $gym_address = filter("gym_address");
            $query = $conn->query("set names utf8");
            $query = $conn->prepare("UPDATE Gyms SET name = '$gym_name', address = '$gym_address' WHERE id = ?");
            $query->bind_param('i', $gym_id);
            $query->execute();
            if ($conn->errno) {
                die('Select Error (' . $conn->errno . ') ' . $conn->error);
            }
            $query->close();
            break;
        case "getMenu":
            $menu_id = filter("menu_id");

            $resultMenu = $conn->query("set names utf8");
            $sqlMenu = "SELECT id, (SELECT name FROM Program WHERE id=program_id) as program,date_start, day_of_the_week,(SELECT first_name FROM Users WHERE id=user_id) as author
            FROM Menu WHERE id = '$menu_id'";
            $resultMenu = $conn->query($sqlMenu);
            while ($rowMenu = $resultMenu->fetch_assoc()) {
                $menuid = $rowMenu['id'];
                $date = DateTime::createFromFormat('Y-m-d', $rowMenu['date_start']);
                $date_start = $date->format("d-m-y"); ?>
                <form class="form-horizontal" role="form" data-toggle="validator" id="form">
                    <fieldset>
                        <div class="form-group">
                            <label class="col-lg-4 control-label">Автор:</label>

                            <div class="col-lg-4 text-left">
                                <p class="get"><?php echo $rowMenu['author'] ?></p>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="inputDate" class="col-lg-4 control-label">Программа:</label>

                            <div class="col-lg-4 text-left">
                                <p class="get"><?php echo $rowMenu['program'] ?></p>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="inputTime" class="col-lg-4 control-label">Дата меню:</label>

                            <div class="col-lg-4">
                                <p class="get"><?php echo $date_start ?></p>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="inputPlan" class="col-lg-4 control-label">День недели:</label>

                            <div class="col-lg-4">
                                <p class="get"><?php
                                    $day = date('l', strtotime($rowMenu['date_start']));
                                    if ($day == "Monday") {
                                        $day = "Понедельник";
                                    } else if ($day == "Tuesday") {
                                        $day = "Вторник";
                                    } else if ($day == "Wednesday") {
                                        $day = "Среда";
                                    } else if ($day == "Thursday") {
                                        $day = "Четверг";
                                    } else if ($day == "Friday") {
                                        $day = "Пятница";
                                    } else if ($day == "Saturday") {
                                        $day = "Суббота";
                                    } else if ($day == "Sunday") {
                                        $day = "Воскресенье";
                                    }
                                    echo $day;
                                    ?></p>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-lg-10 col-md-offset-1">
                                <table class="table" style="width: 100%">
                                    <?php
                                    $resultType = $conn->query("set names utf8");
                                    $sqlType = "SELECT DISTINCT m.food_type_id,f.type_name
                                FROM Menu_Foods m JOIN Food_Type f ON f.id = m.food_type_id WHERE m.menu_id = '$menuid' ORDER by f.sort";
                                    $resultType = $conn->query($sqlType);
                                    while ($rowType = $resultType->fetch_assoc()) {
                                        $type_id = $rowType['food_type_id'];
                                        $type_name = $rowType['type_name'];
                                        ?>
                                        <tbody class="body_<?php echo $type_id ?>">
                                        <tr>
                                            <th><?php echo $type_name ?></th>
                                            <th>Выход</th>
                                            <th>Ккал</th>
                                            <th>Белок</th>
                                            <th>Жир</th>
                                            <th>Углеводы</th>
                                        </tr>
                                        <?php
                                        $resultFood = $conn->query("set names utf8");
                                        $sqlFood = "SELECT f.id, m.id,f.name, m.portion,TRUNCATE((f.kcal*m.portion/100),2) as calcKcal, TRUNCATE((f.protein*m.portion/100),2) as calcPro, TRUNCATE((f.fat*m.portion/100),2) as calcFat, TRUNCATE((f.carbohydrate*m.portion/100),2) as calcCarbo
                                FROM Menu_Foods m JOIN Foods f ON f.id = m.food_id
                                WHERE m.menu_id = '$menuid' and m.food_type_id = '$type_id'";
                                        $resultFood = $conn->query($sqlFood);

                                        while ($rowFood = $resultFood->fetch_assoc()) {
                                            $food_id = $rowFood['id']; ?>
                                            <tr class="type_<?php echo $type_id ?>">
                                                <td><?php echo $rowFood["name"]; ?></td>
                                                <td><?php echo $rowFood['portion'] ?></td>
                                                <td class="kcal"><?php echo $rowFood['calcKcal'] ?></td>
                                                <td class="protein"><?php echo $rowFood['calcPro'] ?></td>
                                                <td class="fat"><?php echo $rowFood['calcFat'] ?></td>
                                                <td class="carbo"><?php echo $rowFood['calcCarbo'] ?></td>
                                            </tr>
                                            <?php
                                        }
                                        ?>
                                        </tbody>
                                        <tr class="calcFood" style="background-color: #c8c8c8">
                                            <td width="25%"></td>
                                            <td>Калории <?php echo $type_name ?></td>
                                            <td class="sumFKcal_<?php echo $type_id ?> typeKcal"></td>
                                            <td class="sumFPro_<?php echo $type_id ?> typePro"></td>
                                            <td class="sumFFat_<?php echo $type_id ?> typeFat"></td>
                                            <td class="sumFCarbo_<?php echo $type_id ?> typeCarbo"></td>
                                        </tr>
                                    <?php }
                                    $resultSum = $conn->query("set names utf8");
                                    $sqlSum = "SELECT f.id, SUM(TRUNCATE((f.kcal*m.portion/100),2)) as sumKcal, SUM(TRUNCATE((f.protein*m.portion/100),2)) as sumPro,
                            SUM(TRUNCATE((f.fat*m.portion/100),2)) as sumFat, SUM(TRUNCATE((f.carbohydrate*m.portion/100),2)) as sumCarbo
                            FROM Foods f JOIN Menu_Foods m ON f.id = m.food_id
                            WHERE f.id in (SELECT food_id FROM Menu_Foods WHERE menu_id = '$menuid') GROUP by f.id";
                                    $resultSum = $conn->query($sqlSum);
                                    $rowSum = $resultSum->fetch_assoc()
                                    ?>
                                    <tr style="background-color: #1dc116">
                                        <th WIDTH="25%"></th>
                                        <th>Всего</th>
                                        <th class="sumKcal"><?php echo $rowSum['sumKcal'] ?></th>
                                        <th class="sumPro"><?php echo $rowSum['sumPro'] ?></th>
                                        <th class="sumFat"><?php echo $rowSum['sumFat'] ?></th>
                                        <th class="sumCarbo"><?php echo $rowSum['sumCarbo'] ?></th>
                                    </tr>

                                </table>
                            </div>
                        </div>

                        <div class="form-group text-center add">
                            <div class="col-lg-12">
                                <button type="button" class="btn btn-default" data-dismiss="modal">Закрыть</button>
                                <a class="btn btn-danger" onclick="
                                    if (confirm('Вы хотите удалить?')){
                                    actions('deleteMenu', <?php echo $rowMenu['id'] ?>)}"
                                   data-dismiss="modal">Удалить</a>
                                <a href="../actions/mpdf/menuToPDF.php?id=<?php echo $rowMenu['id'] ?>" target="_blank" class="btn btn-success">Экспортировать в PDF</a>
                            </div>
                        </div>
                    </fieldset>
                </form>
            <?php }
            break;
        case "editUserInfo":
            $user_id = filter("id");
            $first_name = filter("first_name");
            $last_name = filter("last_name");
            $phone = filter("phone");
            $email = filter("email");
            $db = filter("db");

            $query = $conn->query("set names utf8");
            $query = $conn->prepare("UPDATE Users SET first_name='$first_name', last_name='$last_name', email='$email', phone='$phone', dateOfBirthday='$db' WHERE id = ?");
            $query->bind_param('i', $user_id);
            $query->execute();
            if ($conn->errno) {
                die('Select Error (' . $conn->errno . ') ' . $conn->error);
            }
            $query->close();
            break;
        case "editUserGym":
            $user_id = filter("id");
            $gym = filter("gym");
            $query = $conn->query("set names utf8");
            $query = $conn->prepare("UPDATE Users SET id_gym = '$gym' WHERE id = ?");
            $query->bind_param('i', $user_id);
            $query->execute();
            if ($conn->errno) {
                die('Select Error (' . $conn->errno . ') ' . $conn->error);
            }
            $query->close();
            break;
        case "editUserAddress":
            $user_id = filter("id");
            $address = filter("custom");
            $check = filter("check");
            $gym = filter("gym");

            $query = $conn->query("set names utf8");
            $query = $conn->prepare("UPDATE Users SET custom_address = '$address', address_boolean = '$check', id_gym = '$gym' WHERE id = ?");
            $query->bind_param('i', $user_id);
            $query->execute();
            if ($conn->errno) {
                die('Select Error (' . $conn->errno . ') ' . $conn->error);
            }
            $query->close();
            break;
        case "addUserBalance":
            $client_id = filter("id");
            $sum = filter("admin_sum");
            $result = $conn->query("set names utf8");
            $result = $conn->prepare('INSERT INTO HistoryOfPayment (user_id,lastPayment,dateOfPayment,paymentMethod,transaction,comment) VALUES (?,?,NOW(),1,NULL,NULL)');
            $result->bind_param('ii', $client_id, $sum);
            $result->execute();
            $result->close();
            break;
        case "deleteClient":
            $client_id = filter("client_id");
            if (!empty($client_id)) {
                $query = $conn->prepare('DELETE FROM Users WHERE id = ?');
                $query->bind_param('i', $client_id);
                $query->execute();
                if ($query) {
                    $result = $conn->prepare('DELETE FROM HistoryOfPayment WHERE user_id = ?');
                    $result->bind_param('i', $client_id);
                    $result->execute();
                }
                $query->close();
            }
            break;
        case "addUserInfo":
            $first_name = filter("first_name");
            $last_name = filter("last_name");
            $phone = filter("phone");
            $email = filter("email");
            $db = filter("db");
            $user_status = filter("user_status");
            $p = md5(md5("12345" . md5(sha1("12345"))));
            $qCheck = $conn->query("set names utf8");
            $qCheck = $conn->query("SELECT email FROM Users WHERE email = '$email'");
            if ($qCheck->num_rows > 0) {
                echo "<div id='alert1' class='alert-box success'>Такая почта уже существует!</div>";

            } else {
                $insert_row = $conn->query("set names utf8");
                $insert_row = $conn->prepare('INSERT INTO Users (first_name,last_name,phone,email,dateOfBirthday,password,user_status) VALUES (?,?,?,?,?,?,?)');
                $insert_row->bind_param('ssssssi', $first_name, $last_name, $phone, $email, $db, $p, $user_status);
                $insert_row->execute();
                $user_id = $insert_row->insert_id;
                if ($insert_row) {
                    echo $user_id;
                }
                $insert_row->close();
            }
            break;
        case "getDescriptions":
            $description = filter ("program_id");
            if (!empty($description))
            {
                $result = $conn->query("set names utf8");
                $query = "SELECT destinct(description)  FROM Product WHERE program_id = '$description'";
                $result = $conn->query($query);
                while ($row = $result->fetch_assoc()) { ?>
                    <?php echo $row["description"]; ?>
                    <?php
                }
                $result->close();

            }
            break;
        case "getDeliveryDate":
            $filter_date = filter("val");
            $id_gym = filter("id");
            $date = DateTime::createFromFormat('d-m-Y', $filter_date);
            $date_request = $date->format("Y-m-d");
            $result = $conn->query("set names utf8");
            if($user_status == 2){
                $query = "SELECT c.id, u.custom_address,(SELECT id FROM Gyms WHERE id = u.id_gym) as 'id_gym',(SELECT address FROM Gyms WHERE id = u.id_gym) as 'gym',
            u.first_name, u.last_name, u.phone, (SELECT name FROM Product WHERE id = (SELECT product_id FROM Plans WHERE id = c.plan_id)) as 'plan',
            (SELECT quantity FROM Delivery WHERE calendar_id = c.id) as 'quantity', (SELECT comment FROM Delivery WHERE calendar_id = c.id) as 'comment',
            (SELECT date_time FROM Delivery WHERE calendar_id = c.id) as 'time', (SELECT status FROM Delivery WHERE calendar_id = c.id) as 'status',
            (SELECT fact_time FROM Delivery WHERE calendar_id = c.id) as 'fact_time'
            FROM Calendars c JOIN Users u ON u.id = (SELECT user_id FROM Plans WHERE id = c.plan_id) WHERE c.date = '$date_request' AND id_gym = '$id_gym'";
            }
            else {
                $query = "SELECT c.id, u.custom_address,(SELECT id FROM Gyms WHERE id = u.id_gym) as 'id_gym',(SELECT address FROM Gyms WHERE id = u.id_gym) as 'gym',
            u.first_name, u.last_name, u.phone, (SELECT name FROM Product WHERE id = (SELECT product_id FROM Plans WHERE id = c.plan_id)) as 'plan',
            (SELECT quantity FROM Delivery WHERE calendar_id = c.id) as 'quantity', (SELECT comment FROM Delivery WHERE calendar_id = c.id) as 'comment',
            (SELECT date_time FROM Delivery WHERE calendar_id = c.id) as 'time', (SELECT status FROM Delivery WHERE calendar_id = c.id) as 'status',
            (SELECT fact_time FROM Delivery WHERE calendar_id = c.id) as 'fact_time'
            FROM Calendars c JOIN Users u ON u.id = (SELECT user_id FROM Plans WHERE id = c.plan_id) WHERE c.date = '$date_request'";
            }
            $result = $conn->query($query);
            while ($row = $result->fetch_assoc()) { ?>
                <tr data-toggle="modal" data-target="#myModal" style="cursor: pointer"
                    onclick="getDelivery('getDelivery',<?php echo $row['id'] ?>)">
                    <td><?php echo $row['custom_address']; if($row['custom_address']=="") echo $row['gym'] ?></td>
                    <td><?php echo $row['first_name']." ".$row['last_name']."<br>".$row['phone'] ?></td>
                    <td><?php echo $row['plan'] ?></td>
                    <td><?php echo $row['quantity'] ?></td>
                    <td><?php echo $row['comment'] ?></td>
                    <td><?php echo $row['time'] ?></td>
                    <td><?php echo $row['status'] ?></td>
                    <td><?php echo $row['fact_time'] ?></td>
                </tr>
                <?php
            }
            $result->close();
            break;
        case "getDelivery":
            $c_id = filter("val");
            $result = $conn->query($query);
            if (!empty($c_id)) {
                $result = $conn->query("set names utf8");
                $query = "SELECT c.id, u.custom_address, (SELECT address FROM Gyms WHERE id = u.id_gym) as 'gym',
                u.first_name, u.last_name, u.phone, (SELECT name FROM Product WHERE id = (SELECT product_id FROM Plans WHERE id = c.plan_id)) as 'plan',
                (SELECT quantity FROM Delivery WHERE calendar_id = c.id) as 'quantity', (SELECT comment FROM Delivery WHERE calendar_id = c.id) as 'comment',
                (SELECT date_time FROM Delivery WHERE calendar_id = c.id) as 'time', (SELECT status FROM Delivery WHERE calendar_id = c.id) as 'status',
                (SELECT fact_time FROM Delivery WHERE calendar_id = c.id) as 'fact_time'
                FROM Calendars c JOIN Users u ON u.id = (SELECT user_id FROM Plans WHERE id = c.plan_id) WHERE c.id = '$c_id'";
                $result = $conn->query($query);
                while ($row = $result->fetch_assoc()) {
                    $address = $row["custom_address"];
                    if($row["custom_address"] == ""){
                        $address = $row["gym"];
                    }?>
                    <form class="form-horizontal" role="form" data-toggle="validator" id="form">
                        <fieldset>
                            <div class="form-group">
                                <label for="inputTime" class="col-lg-4 control-label">Адрес:</label>

                                <div class="col-lg-4">
                                    <p class="get"><?php echo $row['custom_address']; if($row['custom_address']=="") echo $row['gym'] ?></p>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="inputClient" class="col-lg-4 control-label">Получатель:</label>

                                <div class="col-lg-4">
                                    <p class="get"><?php echo $row['first_name']." ".$row['last_name']."<br>".$row['phone'] ?></p>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="inputPhone" class="col-lg-4 control-label">Время план:</label>

                                <div class="col-lg-4">
                                    <p class="get"><?php echo $row['time'] ?></p>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="inputTime" class="col-lg-4 control-label">Время факт:</label>

                                <div class="col-lg-4">
                                    <p class="get"><?php echo $row['fact_time']?></p>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="inputPlan" class="col-lg-4 control-label">Пакет:</label>

                                <div class="col-lg-4">
                                    <p class="get"><?php echo $row['plan'] ?></p>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="inputPlace" class="col-lg-4 control-label">Кол-во:</label>

                                <div class="col-lg-4">
                                    <p class="get"><?php echo $row['quantity'] ?></p>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="inputAddress" class="col-lg-4 control-label">Оплата:</label>

                                <div class="col-lg-4">
                                    <p class="get"><?php echo $row['comment'] ?></p>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="inputTime" class="col-lg-4 control-label">Статус доставки:</label>

                                <div class="col-lg-4">
                                    <p class="get"><?php echo $row['status']?></p>
                                </div>
                            </div>
                            <div class="form-group text-center add">
                                <div class="col-lg-12">
                                    <button type="button" class="btn btn-default" data-dismiss="modal">Закрыть</button>
                                    <a class="btn btn-warning" href="editDelivery.php?id=<?php echo $row['id'] ?>">Редактировать</a>
                                </div>
                            </div>
                        </fieldset>
                    </form>
                <?php }
                $result->close();
            }
            break;
        case "editDelivery":
            $calendar = filter("calendar");
            $user_id = filter("user_id");
            $time = filter("date_time");
            $fact_time = filter("fact_time");
            $quantity = filter("quantity");
            $comment = filter("comment");
            $pcomment = filter("pcomment");
            $acomment = filter("acomment");
            $status_name = filter("status_name");
            $place = filter("place");
            $address = filter("address");
            $courier = filter("courier");
            $sql = "SELECT calendar_id FROM Delivery WHERE calendar_id = '$calendar'";
            $sql_query = $conn->query($sql);
            if ($sql_query->num_rows == 0) {
                $insert_row = $conn->query("set names utf8");
                $insert_row = $conn->prepare('INSERT INTO Delivery (calendar_id, user_id, date_time, fact_time, quantity, comment, partner_comment, admin_comment, status, courier) VALUES (?,?,?,?,?,?,?,?,?,?)');
                $insert_row->bind_param('iisssssssi', $calendar, $user_id, $time, $fact_time, $quantity, $comment, $pcomment, $acomment, $status_name, $courier);
                $insert_row->execute();
            } else {
                $result = $conn->query("set names utf8");
                $result = $conn->prepare("UPDATE Delivery SET calendar_id='$calendar',user_id='$user_id',date_time ='$time',fact_time='$fact_time',quantity = '$quantity',comment = '$comment',partner_comment = '$pcomment',admin_comment = '$acomment',status = '$status_name',courier = '$courier' WHERE calendar_id = ?");
                $result->bind_param('i', $calendar);
                $result->execute();
            }
            if($place == "") {
                $result = $conn->query("set names utf8");
                $result = $conn->prepare("UPDATE Users SET custom_address='$address',address_boolean=0, id_gym='$place' WHERE id = ?");
                $result->bind_param('i', $user_id);
                $result->execute();
            } else {
                $result = $conn->query("set names utf8");
                $result = $conn->prepare("UPDATE Users SET custom_address='',address_boolean=1, id_gym='$place' WHERE id = ?");
                $result->bind_param('i', $user_id);
                $result->execute();
            }
            $sql_query->close();
            break;
        case "getDeliveryStatus":
            $status = filter("val");
            $id_gym = filter("id");
            $result = $conn->query("set names utf8");
            if ($status != "") {
                if($user_status == 2){
                    $query = "SELECT c.id, u.custom_address, (SELECT id FROM Gyms WHERE id = u.id_gym) as 'id_gym',(SELECT address FROM Gyms WHERE id = u.id_gym) as 'gym',
                u.first_name, u.last_name, u.phone, (SELECT name FROM Product WHERE id = (SELECT product_id FROM Plans WHERE id = c.plan_id)) as 'plan',
                (SELECT quantity FROM Delivery WHERE calendar_id = c.id) as 'quantity', (SELECT comment FROM Delivery WHERE calendar_id = c.id) as 'comment',
                (SELECT date_time FROM Delivery WHERE calendar_id = c.id) as 'time'
                FROM Calendars c JOIN Users u ON u.id = (SELECT user_id FROM Plans WHERE id = c.plan_id) WHERE (SELECT status FROM Delivery WHERE calendar_id = c.id) = '$status' AND id_gym = '$id_gym'";
                } else {
                    $query = "SELECT c.id, u.custom_address, (SELECT address FROM Gyms WHERE id = u.id_gym) as 'gym',
                u.first_name, u.last_name, u.phone, (SELECT name FROM Product WHERE id = (SELECT product_id FROM Plans WHERE id = c.plan_id)) as 'plan',
                (SELECT quantity FROM Delivery WHERE calendar_id = c.id) as 'quantity', (SELECT comment FROM Delivery WHERE calendar_id = c.id) as 'comment',
                (SELECT date_time FROM Delivery WHERE calendar_id = c.id) as 'time'
                FROM Calendars c JOIN Users u ON u.id = (SELECT user_id FROM Plans WHERE id = c.plan_id) WHERE (SELECT status FROM Delivery WHERE calendar_id = c.id) = '$status'";
                }

            } else {
                $query = "SELECT c.id, u.custom_address, (SELECT address FROM Gyms WHERE id = u.id_gym) as 'gym',
                u.first_name, u.last_name, u.phone, (SELECT name FROM Product WHERE id = (SELECT product_id FROM Plans WHERE id = c.plan_id)) as 'plan',
                (SELECT quantity FROM Delivery WHERE calendar_id = c.id) as 'quantity', (SELECT comment FROM Delivery WHERE calendar_id = c.id) as 'comment',
                (SELECT date_time FROM Delivery WHERE calendar_id = c.id) as 'time'
                FROM Calendars c JOIN Users u ON u.id = (SELECT user_id FROM Plans WHERE id = c.plan_id)";
            }
            $result = $conn->query($query);
            while ($row = $result->fetch_assoc()) {?>
                <tr data-toggle="modal" data-target="#myModal" style="cursor: pointer"
                    onclick="getDelivery('getDelivery',<?php echo $row['id'] ?>)">
                    <td><?php echo $row['custom_address']; if($row['custom_address']=="") echo $row['gym'] ?></td>
                    <td><?php echo $row['first_name']." ".$row['last_name']."<br>".$row['phone'] ?></td>
                    <td><?php echo $row['time'] ?></td>
                    <td><?php echo $row['plan'] ?></td>
                    <td><?php echo $row['quantity'] ?></td>
                    <td><?php echo $row['comment'] ?></td>
                </tr>
                <?php
            }
            $result->close();
            break;

        case "deletePrice":
            $price_id = filter("price_id");
            if (!empty($price_id)) {
                $query = $conn->prepare('DELETE FROM Product WHERE id = ?');
                $query->bind_param('i', $price_id);
                $query->execute();
                if ($conn->errno) {
                    die('Select Error (' . $conn->errno . ') ' . $conn->error);
                }
                $query->close();
            }
            break;

        case "editPrice":
            $price_id = filter("price_id");
            $photo = filter("photo");
            $product_name = filter("product_name");
            $type = filter("price_type");
            $kcal = filter("kcal");
            $price = filter("price");
            $amount = filter("amount");
            $description = filter("description");
            $description2 = filter("description2");
            $freezing = filter("freezing");
            $commission = filter("commission");
            $query = $conn->query("set names utf8");
            $query = $conn->prepare("UPDATE Product SET photo='$photo',name='$product_name',kcal='$kcal',price='$price',amount_days='$amount',description='$description',description2='$description2',freezing='$freezing',commission='$commission',type='$type' WHERE id = ?");
            $query->bind_param('i', $price_id);
            $query->execute();
            if ($conn->errno) {
                die('Select Error (' . $conn->errno . ') ' . $conn->error);
            }
            $query->close();
            break;

        case "addPrice":
            $photo = filter("photo");
            $product_name = filter("product_name");
            $type = filter("price_type");
            $kcal = filter("kcal");
            $price = filter("price");
            $amount = filter("amount");
            $description = filter("description");
            $description2 = filter("description2");
            $freezing = filter("freezing");
            $commission = filter("commission");
            $query = $conn->query("set names utf8");
            $query = $conn->prepare("INSERT INTO Product (photo, name, kcal, price, amount_days, description, description2, freezing, commission, type) VALUES(?,?,?,?,?,?,?,?,?,?)");
            $query->bind_param('sssiissisi', $photo, $product_name, $kcal, $price, $amount, $description, $description2, $freezing, $commission, $type);
            $query->execute();
            $query->close();
            break;
    }
}
?>