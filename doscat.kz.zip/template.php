<?php
if($_SESSION["admin_id"] > 0) {
    $user_id = $_SESSION["admin_id"];
} else {
    $user_id = $_SESSION["user_id"];
}

$status = $_SESSION['status'];
$active_p = active($user_id);

include("../bd.php");
$resultUser = $conn->query("set names utf8");
$sqlUser = "SELECT first_name,last_name,id_gym,(SELECT name FROM Gyms WHERE id = id_gym) as 'gym_name' FROM Users WHERE id = '$user_id'";
$resultUser = $conn->query($sqlUser);
$rowUser = $resultUser->fetch_assoc();
$id_gym = $rowUser['id_gym'];

if($status == 1 || $status == 2) {?>
    <nav class="navbar navbar-default navbar-fixed-top" style="min-height: 81px">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="admin/index.php"><img src="../img/logo.png" alt="Dostyk Catering - правильное питание с доставкой по Алматы"></a>
            </div>

            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="profile.php"><?php if($status==1){echo 'Админ';}
                            elseif($status==2){
                                echo 'Партнер<br>'. $rowUser['gym_name'];
                            }
                            elseif($status==3){echo 'Курьер';} else{echo 'Клиент';} ?>
                        </a>
                    </li>
                    <?php $rCount1 = $conn->query("set names utf8");
                    $sqlCount1 = "SELECT COUNT(DISTINCT user_id) as 'count' FROM Plans WHERE user_id in (SELECT id FROM Users WHERE id_gym = '$id_gym')";
                    $rCount1 = $conn->query($sqlCount1);
                    $rowCount1 = $rCount1->fetch_assoc(); ?>
                    <li><a>Активных клиентов: <?php echo $rowCount1['count']; ?>
                            <?php $rCount2 = $conn->query("set names utf8");
                            $sqlCount2 = "SELECT COUNT(id) as 'count' FROM Users WHERE id_gym = '$id_gym'";
                            $rCount2 = $conn->query($sqlCount2);
                            $rowCount2 = $rCount2->fetch_assoc(); ?>
                            <br>Всего клиентов: <?php echo $rowCount2['count']; ?></a></li>
                    <li><a href="logout.php">Выйти</a></li>
                </ul>
            </div>
        </div>
    </nav>
    <?php if($status == 1) { ?>
        <nav class="navbar navbar-inverse" style="margin-bottom: 0;margin-top: 80px;">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-2">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                </div>
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-2">

                    <ul class="nav navbar-nav">

                        <li class="dropdown">
                            <a class="dropdown-toggle" data-toggle="dropdown" style="cursor: pointer">Меню
                                <span class="caret"></span></a>
                            <ul class="dropdown-menu">
                                <li><a href="admin/menu.php?type=3">Меню 3x</a></li>
                                <li><a href="admin/menu.php?type=5">Меню 5x</a></li>
                                <li><a href="admin/foods.php?type=0">Блюда</a></li>
                                <li><a href="admin/foods.php?type=1">Десерты</a></li>
                            </ul>

                        </li>
                        <li><a href="payments.php">Платежи</a></li>
                        <li><a href="">Учет денег</a></li>
                        <li><a href="admin/price.php">Прайс-лист</a></li>
                        <li class="dropdown">
                            <a class="dropdown-toggle" data-toggle="dropdown" style="cursor: pointer">Отчеты
                                <span class="caret"></span></a>
                            <ul class="dropdown-menu">
                                <li><a href="reports.php">Статистика клиентов</a></li>
                                <li><a href="foodstats.php">Статистика блюд</a></li>
                            </ul>
                        </li>
                        <li><a href="">Жалобы</a></li>
                        <li class="dropdown">
                            <a class="dropdown-toggle" data-toggle="dropdown" style="cursor: pointer">Справочники
                                <span class="caret"></span></a>
                            <ul class="dropdown-menu">
                                <li><a href="gyms.php">Спортзалы</a></li>
                                <li><a href="couriers.php">Курьеры</a></li>
                            </ul>
                        </li>
                        <li><a href="">Настройки</a></li>
                    </ul>
                </div>
            </div>
        </nav>
    <?php } if($status == 1 || $status == 2) {
        if($status == 2){
            $style = 'style="margin-top: 80px;background-color: rgba(255, 255, 115, 0.5);"';
        } else {
            $style = 'style="margin-top: 0;background-color: rgba(255, 255, 115, 0.5);"';
        }
        ?>
        <nav class="navbar navbar-inverse" <?php echo $style ?>>
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-2">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                </div>
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-2">
                    <ul class="nav navbar-nav">
                        <li><a href="admin/index.php">Заявки</a></li>
                        <li><a href="admin/delivery.php">Наряды</a></li>
                        <li><a href="admin/clients.php">Клиенты</a></li>
                        <li><a href="">Продажи спортзала</a></li>
                        <li><a href="">Справочники</a></li>
                    </ul>
                </div>
            </div>
        </nav>
    <?php } ?>
    <?php
}
if($status == 0) {?>
    <nav class="navbar navbar-default navbar-fixed-top" style="min-height: 81px">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse"
                        data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php"><img src="img/logo.png" alt="Dostyk Catering - правильное питание с доставкой по Алматы"></a>
            </div>

            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <?php
                    if (isset($fname)) {
                        ?>
                        <li><a href = "/profile"><?php echo $rowUser['first_name'] ?><br><?php echo $rowUser['last_name'] ?></a></li>
                        <li><a href = "/pay">Баланс <br><?php echo number_format(balance($user_id), 0, ',', ' '); ?> тг</a></li>
                        <li><a>Спортзал<br> <?php echo $rowUser['gym_name']; if(!$rowUser['gym_name']) echo 'Не выбран' ?></a></li>
                        <li><a href = "/calendar">План питания <br><?php if (empty($active_p['name_product'])) {echo "Не выбран";} else {echo $active_p['name_product'];} ?></a></li>
                    <?php } ?>
                    <?php if (isset($user_id)) { ?>
                        <li><a href="logout.php">Выйти</a></li>
                    <?php } ?>
                </ul>
            </div>
        </div>
    </nav>
    <nav class="navbar navbar-inverse" style="margin-top: 81px">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-2">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
            </div>
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-2">
                <ul class="nav navbar-nav">
                    <li><a href="index.php#block_menu">Меню</a></li>
                    <li><a href="index.php#programs">Программы</a></li>
                    <li><a href="index.php#secure" class="scroll">Оплата</a></li>
                    <li><a href="index.php#partners">Партнеры</a></li>
                    <li><a href="index.php#about">Контакты</a></li>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="http://facebook.com/dostykcatering/" target="_blank" title="Мы в Facebook"><img class="ss" src="img/facebook.png" alt=""></a></li>
                    <li><a href="https://www.instagram.com/dostykcatering/" target="_blank" title="Мы в Instagram"><img class="ss" src="img/instagram.png" alt=""></a></li>
                    <li><a href="tel:+77079110502"><img class="ss" src="img/whatsapp.png" alt=""> +7 (707) 911-0502</a></li>
                </ul>
                <div class="navbar-form navbar-right">
                    <!--<a href="#form" class="btn btn-warning" role="button" data-toggle="modal">Оставить заявку</a>-->
                    <a href="index.php#form" class="btn btn-warning">Оставить заявку</a>
                </div>
            </div>
        </div>
    </nav>
<?php }
?>

