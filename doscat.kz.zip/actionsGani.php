<?php
header('Content-type: text/html; charset=utf8');
session_start();
include("bd.php");
include("actions/filter.php");
include("actions/functions.php");
$id = $_SESSION["user_id"];

$action = $_POST["action"];
if (!empty($action)) {
    switch ($action) {
        case "getDescriptions":
            $description = filter ("program_id");
            if (!empty($description))
            {
                $result = $conn->query("set names utf8");
                $query = "SELECT  photo,description, name FROM Program WHERE id = '$description'";
                $result = $conn->query($query);
                while ($row = $result->fetch_assoc()) { ?>
                <div class="form-group" style="margin-top: -20px;">
                       <h3><?php echo $row["name"]?> </h3>

                        <div class="col-lg-8 " style = "margin-left: 60px;">
                            <img src="<?php echo $row["photo"] ?>" width="300px"; height="200px"  >
                        </div>

                    <br>
                    <div class="form-group">

                        <div class="col-lg-8 " style = "margin-left: 60px; margin-top:60px;">
                          <textarea rows="10" cols="40" name="text" style="color:black; resize: none;" disabled><?php echo $row["description"] ?></textarea>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-lg-8 " style = "margin-left: 60px;">
                          <div style="text-align: center;"> <button type="submit" class="btn btn-warning sendzakaz" style = "">��������</button></div>
                       </div>
                     </div>
                    <?php
                }

                $result->close();

            }
            break;
             case "getPrice":
            $description = filter ("program_id");
            $value = filter("value");
            if (!empty($description) && $value == 0)
            {
                $result = $conn->query("set names utf8");
                $query = "SELECT  photo,description, Price name FROM Program WHERE id = '$description' and type = '$value'";
                $result = $conn->query($query);
                while ($row = $result->fetch_assoc()) { ?>
                <div class="form-group" style="margin-top: -20px;">
                     <div class="form-group">

                                <label for="inputName" class="col-lg-4 control-label">��������� ����</label>
                                <div class="col-lg-8 text-left">
                                    <input class="form-control costPerDay" id="costPerDay" type="text" name="costPerDay" placeholder="" value = <?php echo $row["Price"] ?> disabled>
                                </div>
                            </div>
                    <?php

                }
            }
            if(!empty($description) && $value == 0)
                {
                     $result = $conn->query("set names utf8");
                $query = "SELECT  photo,description, name FROM Program WHERE id = '$description' and type = $value";
                $result = $conn->query($query);
                while ($row = $result->fetch_assoc()) { ?>
                   <select class="form-control" name="program" id="select" onchange="getDescription('getDescriptions', this.value);" required>

                                    <?php
                                    $query = "SELECT  name, id, type  FROM Program WHERE type = 0";
                                    $results = $conn->query($query);
                                    while ($row = $results->fetch_assoc()) { ?>
                                        <option value="<?php echo $row["id"]; ?>"><?php echo $row["name"]; ?> </option>
                                    <?php } ?>
                                </select>
                    <?php
                }
                $result->close();
                }
            break;
    }
}
?>