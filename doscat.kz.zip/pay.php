<?php
//ini_set('error_reporting', E_ALL);
//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);
header('Content-type: text/html; charset=utf8');
session_start();
$status = $_SESSION['status'];
include("bd.php");
require_once 'actions/functions.php';
require_once 'actions/filter.php';

//получим массив по плану
$result = $conn->query("set names utf8");
if(isset($_GET['id']) and ($_SESSION['status'] == 1 || $_SESSION['status'] == 2)) {
    //надо проверить 1 админ я в сессии или не админ
    if ($_SESSION["admin_id"] > 0) {

    } else {
        $_SESSION['admin_id'] = $_SESSION['user_id'];
    }
    $_SESSION['user_id'] = $_GET['id'];
} else {
    if ($_SESSION["admin_id"] > 0) {
        $_SESSION["user_id"] = $_SESSION["admin_id"];
        $_SESSION['admin_id'] = 0;
    }
}
$id = $_SESSION["user_id"];
if (!isset($id) and !is_numeric($id)) {
    //header("Location: login.php");
} else {
    $active_plan = active($id);
    $balance = balance($id);
    $sql = "SELECT u.id,u.first_name,u.last_name,u.email,u.phone,u.dateOfBirthday,
    (SELECT name FROM Gyms g WHERE g.id=u.id_gym) as gym_name,
    (SELECT address FROM Gyms g WHERE g.id=u.id_gym) as gym_address,u.custom_address,u.address_boolean,
    (SELECT lastPayment FROM HistoryOfPayment h WHERE h.user_id=u.id ORDER BY id DESC LIMIT 1) as lastPayment,
    (SELECT dateOfPayment FROM HistoryOfPayment h WHERE h.user_id=u.id ORDER BY id DESC LIMIT 1) as dateOfPayment,
    (SELECT paymentMethod FROM HistoryOfPayment h WHERE h.user_id=u.id ORDER BY id DESC LIMIT 1) as paymentMethod
    FROM Users u WHERE u.id = '$id'";
    $result = $conn->query($sql);

    $row = $result->fetch_assoc();
    $fname = $row['first_name'];
    $lname = $row['last_name'];
    $phone = $row['phone'];
    $email = $row['email'];
    $picture = $row['picture'];
    $dateOfBirthday = $row['dateOfBirthday'];
    $gym_name = $row['gym_name'];
    $gym_address = $row['gym_address'];
    $custom_address = $row['custom_address'];
    $bool = $row['address_boolean'];
    $lastPayment = $row['lastPayment'];
    $dateOfPayment = $row['dateOfPayment'];
    $paymentMethod = $row['paymentMethod'];
}


?>
<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name=viewport content="width=device-width, initial-scale=1">
    <meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
    <?php
    if (isset($id) and is_numeric($id)) {
        echo '<title>Баланс профиля - '.$fname.' '.$lname.'</title>';
    } else {
        echo '<title>Прием платежа за питание Dostyk Catering</title>';
    }
    ?>
    <link rel="canonical" href=""/>
    <meta name="robots" content="index, follow"/>
    <meta name="keywords" content=""/>
    <meta name="description" content=""/>

    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet/less" type="text/css" href="css/main.less">
    <script type="text/javascript" src="js/less.min.js"></script>

    <!-- Include Bootstrap Datepicker -->
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/css/datepicker.min.css"/>
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/css/datepicker3.min.css"/>
    <style>
        .block_cabinet .nav-tabs {
            margin-top: 10px;
        }
        .block_cabinet .nav-tabs li {
            width: auto;
            border: 1px;
        }
        .block_cabinet .nav-tabs li a {
            font-size: 16px;
        }
    </style>
</head>
<body>
<?php
include("template.php");
?>

<div class="container block_cabinet text-center" id="menu">
    <?php echo '<p style="text-align: left;font-size: 18px;margin-top: 20px;"><b>'.$fname.' '.$lname.'</b></p>' ?>
    <?php if($status == 1 || $status == 2) {echo '<p style="text-align: left;font-size: 18px;"><b>Баланс: '.$balance.'</b></p>';}  ?>
    <ul class="nav nav-tabs">
        <li><a href="profile.php?id=<?php echo $id ?>">Личные данные</a></li>
        <li class="active"><a href="#">Баланс и платежи</a></li>
        <li><a href="calendar.php?id=<?php echo $id ?>">Календарь питания</a></li>
        <li><a href="api.php?id=<?php echo $id ?>">Уведомления</a></li>
    </ul>
    <br><br>
        <?php
        $query_balance = $conn->prepare("SELECT id, dateOfPayment, lastPayment, paymentMethod, (SELECT name FROM PaymentMethod WHERE id = paymentMethod) as `paymentMethodName`, transaction, comment FROM HistoryOfPayment WHERE user_id = ? ORDER by dateOfPayment DESC");
        $query_balance->bind_param('i', $id);
        $query_balance->execute();
        $query_balance->store_result();
        if ($query_balance->num_rows > 0) {
            $query_balance->bind_result($id_balance,$dateOfPayment,$lastPayment,$paymentMethod,$paymentMethodName,$transaction,$comment);
            while ($query_balance->fetch()) {

                $arr_balance[] = array(
                    'id' => $id_balance,
                    'dateOfPayment' => $dateOfPayment,
                    'lastPayment' => $lastPayment,
                    'paymentMethod' => $paymentMethod,
                    'paymentMethodName' => $paymentMethodName,
                    'transaction' => $transaction,
                    'comment' => $comment
                );

            }
        }
        $query_balance->close();
        ?>

    <?php if(isset($_SESSION['admin_id'])) { ?>
        <div class="col-lg-6">
            <div class="text-left">
                <br><br>
                <p>Текущий баланс: <?php echo number_format(balance($id), 0, ',', ' '); ?> тг;</p>
                <p>Сумма последнего пополнения: <?php echo number_format($arr_balance[0]['lastPayment'], 0, ',', ' ')." тг"; ?>;</p>
                <p>Дата последнего пополнения: <?php echo human_date($arr_balance[0]['dateOfPayment']); ?>;</p>
                <p>Способ оплаты: <?php echo $arr_balance[0]['paymentMethodName']; ?>;</p>
                <br><br>
            </div>
        </div>
        <div class="col-lg-6">
            <h4 class="text-center">Пополнить баланс вручную:</h4>
            <div class="row text-center">
                <div class="col-lg-10 col-lg-offset-1">
                    <div class="form-group">
                        <label for="admin_sum" class="col-lg-12 control-label">Сумма платежа</label>
                        <div class="col-lg-8 col-lg-offset-2">
                            <input class="form-control" id="admin_sum" placeholder="Сумма платежа" type="number" name="sum" required oninvalid="this.setCustomValidity('Минимальная сумма 100 тг.')" oninput="setCustomValidity('')" title="Это поле обязательно" autocomplete="off">
                            <br>
                        </div>

                        <label for="admin_date" class="col-lg-12 control-label">Дата оплаты</label>
                        <div class="col-lg-8 col-lg-offset-2">
                            <input class="form-control date" id="admin_date" placeholder="Дата оплаты" type="text" name="admin_date" value="<?php echo date("Y-m-d"); ?>">
                            <br>
                        </div>

                    </div>
                    <div class="form-group">
                        <div class="col-lg-8 col-lg-offset-2 alert4">
                            <button type="submit" class="btn btn-primary" onclick="update_user('addUserBalance', <?php echo $_SESSION['user_id'] ?>)">Пополнить</button>
                        </div>
                    </div>
                </div>
            </div>
            <br><br>
        </div>
    <?php } else { ?>
        <div class="col-lg-12">
            <div class="text-left">
                <p>Текущий баланс: <?php echo number_format(balance($id), 0, ',', ' '); ?> тг;</p>
                <p>Сумма последнего пополнения: <?php echo number_format($arr_balance[0]['lastPayment'], 0, ',', ' ')." тг"; ?>;</p>
                <p>Дата последнего пополнения: <?php echo human_date($arr_balance[0]['dateOfPayment']); ?>;</p>
                <p>Способ оплаты: <?php echo $arr_balance[0]['paymentMethodName']; ?>;</p>
                <br><br>
            </div>
        </div>
    <?php } ?>

        <?php if (isset($arr_balance)) { ?>

            <h3>История платежей:</h3>
            <table class="table table-striped table-hover ">
                <thead>
                <tr>
                    <th>Сумма оплаты</th>
                    <th>Дата оплаты</th>
                    <th>Способ оплаты</th>
                    <th>Номер транзакции</th>
                    <th>Комментарий</th>
                </tr>
                </thead>
                <tbody>
                <?php
                foreach ($arr_balance as $i => $value) {
                    $arr = $arr_balance[$i];
                    echo "<tr>";
                    echo "<td>".number_format($arr['lastPayment'], 0, ',', ' ')." тг"."</td>";
                    echo "<td>".human_date($arr['dateOfPayment'])."</td>";
                    echo "<td>".$arr['paymentMethodName']."</td>";
                    echo "<td>".$arr['transaction']."</td>";
                    echo "<td>".$arr['comment']."</td>";
                    echo "</tr>";
                }
                ?>
                </tbody>
            </table>
        <?php } else { if (isset($id) and is_numeric($id)) {?>
            <p class="text-center">У Вас еще не было платежей.</p>
        <?php } else {
            echo "<h3 class='text-center'>Прием платежей за питание Dostyk Catering</h3><br><br>";
            echo "<p class='text-left'>Здесь вы можете оплатить подписку за доставку здорового питания Dostyk Catering. <br>
Для оплаты введите свой номер сотового телефона и сумму.<br>
По указанному номеру сотового телефона мы будем отличать ваш платеж.<br>
В следующем окне введите данные вашей банковской карты.<br>
После оплаты средства будут зачислены на ваш баланс в онлайн системе Dostyk Catering.<br>
Сумма на вашем балансе будет списываться по факту дней доставки питания.</p>";
        }
        } ?>


        <br><br>
        <?php if(!isset($_SESSION['admin_id'])) {
        if (isset($id) and is_numeric($id)) {
            ?>
            <h3>Пополнить баланс:</h3>
            <div class="row text-left" style="padding: 0 0 50px">
                <div class="col-lg-6">
                    <h4>Онлайн банкинг</h4>
                    <p>Прием платежей осуществляется посредством платежной платформы <a href="http://cloudPayments.kz">CloudPayments</a></p>
                    <form method="get" style="overflow: hidden" id="form">
                        <input type="hidden" name="orderid" value="<?php echo $id; ?>">
                        <div class="form-group">
                            <label for="inputSum" class="col-lg-12 control-label">Сумма платежа</label>
                            <div class="col-lg-12">
                                <input class="form-control" id="inputSum" placeholder="Сумма платежа" type="number" min="100" name="sum" required oninvalid="this.setCustomValidity('Минимальная сумма 100 тг.')" oninput="setCustomValidity('')" title="Это поле обязательно" autocomplete="off">
                                <br>
                                <button type="submit" class="btn btn-primary">Перейти к оплате</button>
                                <br>
                                <a style="cursor:pointer;" onclick='$("#myModal").modal("show");'>Безопасность онлайн платежей</a>
                            </div>

                        </div>
                    </form>

                </div>
                <!--<div class="col-lg-6">
                    <h4>2. Qiwi-терминал</h4>
                    <p>Прием наличных платежей осуществляется посредством платежных терминалов Qiwi.
                        Комиссия терминала 5% от суммы транзакции.</p>
                    <p>Для оплаты через терминал:<br>
                        1. Введите в главном окне поиск "Dostyk Catering". <br>
                        2. Выберите иконку Dostyk Catering. <br>
                        3. Введите сотовый номер указанный в личном кабинете сайта Dostyk Catering. <br>
                    </p><br>
                    <a href="https://w.qiwi.com/replenish/map.action" target="_blank" class="btn btn-primary">Найти терминал на карте</a>
                </div>-->
            </div>
        <?php } else { //вывод формы без авторизации ?>
            <div class="row text-left" style="padding: 0 0 50px">
                <div class="col-lg-6">
                    <form method="get" style="overflow: hidden" id="form2">
                        <input type="hidden" name="orderid" value="0">
                        <div class="form-group">
                            <label for="inputPhone" class="col-lg-12 control-label">Ваш номер телефона</label>
                            <div class="col-lg-12">
                                <input class="form-control" id="inputPhone" placeholder="Ваш номер телефона" type="tel" name="phone" required oninvalid="this.setCustomValidity('Это поле обязательно для заполнения.')" oninput="setCustomValidity('')" title="Это поле обязательно" autocomplete="off">
                            </div>
                            <label for="inputSum" class="col-lg-12 control-label">Сумма платежа</label>
                            <div class="col-lg-12">
                                <input class="form-control" id="inputSum" placeholder="Сумма платежа" type="number" min="100" name="sum" required oninvalid="this.setCustomValidity('Минимальная сумма пожертвования 100 тг.')" oninput="setCustomValidity('')" title="Это поле обязательно" autocomplete="off">
                            </div>
                            <div class="col-lg-12">
                                <br><button type="submit" class="btn btn-primary">Перейти к оплате</button>
                                <br><br>
                                <p>Прием платежей осуществляется посредством платежной платформы <a href="http://cloudPayments.kz" target="_blank">CloudPayments</a></p>
                                <p>По правилам платежной платформы осуществляется прием карт, выпущенных банками стран СНГ.</p>
                                <a style="cursor:pointer;" onclick='$("#myModal").modal("show");'>Гарантии и безопасность онлайн платежей</a>
                            </div>

                        </div>
                    </form>
                </div>
                <!--<div class="col-lg-6">
                    <h4>2. Qiwi-терминал</h4>
                    <p>Прием наличных платежей осуществляется посредством платежных терминалов Qiwi.
                        Комиссия терминала 5% от суммы транзакции.</p>
                    <p>Для оплаты через терминал:<br>
                        1. Введите в главном окне поиск "Dostyk Catering". <br>
                        2. Выберите иконку Dostyk Catering. <br>
                        3. Введите сотовый номер указанный в личном кабинете сайта Dostyk Catering. <br>
                    </p><br>
                    <a href="https://w.qiwi.com/replenish/map.action" target="_blank" class="btn btn-primary">Найти терминал на карте</a>
                </div>-->
            </div>
        <?php } }?>
    <br><br>
</div>


<div class="block_footer">
    <div class="container text-center">
        <a href="#menu" class="scroll"><span class="glyphicon glyphicon-arrow-up"></span>НАВЕРХ</a>
        <br><br><br><br>
        <p class="lead">Алматы, 2017</p>
    </div>
</div>

<!-- HTML-код модального окна -->
<div id="myModal" class="modal fade">
    <div class="modal-dialog">
        <div class="modal-content">
            <!-- Заголовок модального окна -->
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h4 class="modal-title">Безопасность онлайн платежей</h4>
            </div>
            <!-- Основное содержимое модального окна -->
            <div class="modal-body">
                <h4>  Платежи. Оплата банковской картой онлайн  </h4>
                <p>Наш сайт подключен к интернет-эквайрингу, и Вы можете оплатить Товар банковской картой Visa или Mastercard. После подтверждения выбранного Товара откроется защищенное окно с платежной страницей процессингового центра CloudPayments, где Вам необходимо ввести данные Вашей банковской карты. Для дополнительной аутентификации держателя карты используется протокол 3D Secure. Если Ваш Банк поддерживает данную технологию, Вы будете перенаправлены на его сервер для дополнительной идентификации. Информацию о правилах и методах дополнительной идентификации уточняйте в Банке, выдавшем Вам банковскую карту.</p>

                <h4>  Гарантии безопасности  </h4>
                <p>Процессинговый центр CloudPayments защищает и обрабатывает данные Вашей банковской карты по стандарту безопасности PCI DSS 3.0. Передача информации в платежный шлюз происходит с применением технологии шифрования SSL. Дальнейшая передача информации происходит по закрытым банковским сетям, имеющим наивысший уровень надежности. CloudPayments не передает данные Вашей карты нам и иным третьим лицам. Для дополнительной аутентификации держателя карты используется протокол 3D Secure.</p>
                <p>В случае, если у Вас есть вопросы по совершенному платежу, Вы можете обратиться в службу поддержки клиентов по электронной почте support@cloudpayments.kz.</p>

                <h4>  Безопасность онлайн платежей  </h4>
                <p>Предоставляемая Вами персональная информация (имя, адрес, телефон, e-mail, номер кредитной карты) является конфиденциальной и не подлежит разглашению. Данные Вашей кредитной карты передаются только в зашифрованном виде и не сохраняются на нашем Web-сервере.</p>

                <p>Безопасность обработки Интернет-платежей гарантирует ТОО «CloudPayments Kazakhstan». Все операции с платежными картами происходят в соответствии с требованиями VISA International, MasterCard и других платежных систем. При передаче информации используется специальные технологии безопасности карточных онлайн-платежей, обработка данных ведется на безопасном высокотехнологичном сервере процессинговой компании.  </p>
                <table cellspacing="10" cellpadding="10" align="center">
                    <tbody>
                    <tr>
                        <td><img alt="" src="http://cloudpayments.kz/images/docs/logo-small.png">
                            <img alt="" src="http://cloudpayments.kz/images/docs/vbv.png">
                            <img alt="" src="http://cloudpayments.kz/images/docs/mastercard-securecode.png">
                        </td>
                    </tr>
                    </tbody>
                </table>
                <br><br>
                <h4>  Правила доставки  </h4>
                <p>Доставка осуществляется бесплатно в спортзалы-партнеры Dostyk Catering для всех планов питания. Для планов питания "Day" бесплатная доставка осуществляется в квадрате улиц Аль-Фараби-Раимбека-Достык-Саина. Стандартное время доставки с 11.00 до 14.00.</p>

                <h4>  Конфиденциальность  </h4>

                <p><b>1. Определения
                    </b></p>
                <p>Интернет проект http://doscat.kz (далее – URL, «мы») серьезно относится к вопросу конфиденциальности информации своих клиентов и посетителей сайта http://doscat.kz (далее – «вы», «посетители сайта»). Персонифицированной мы называем информацию, содержащую персональные данные (например: ФИО, логин или название компании) посетителя сайта, а также информацию о действиях, совершаемых вами на сайте URL. (например: заказ посетителя сайта с его контактной информацией). Анонимными мы называем данные, которые невозможно однозначно идентифицировать с конкретным посетителем сайта (например: статистика посещаемости сайта).
                </p>
                <p><b>2. Использование информации </b></p>

                <p>Мы используем персонифицированную информацию конкретного посетителя сайта исключительно для обеспечения ему качественного оказания услуг и их учета. Мы не раскрываем персонифицированных данных одних посетителей сайта URL другим посетителям сайта. Мы никогда не публикуем персонифицированную информацию в открытом доступе и не передаем ее третьим лицам. Исключением являются лишь ситуации, когда предоставление такой информации уполномоченным государственным органам предписано действующим законодательством Республики Казахстан. Мы публикуем и распространяем только отчеты, построенные на основании собранных анонимных данных. При этом отчеты не содержат информацию, по которой было бы возможным идентифицировать персонифицированные данные пользователей услуг. Мы также используем анонимные данные для внутреннего анализа, целью которого является развитие продуктов и услуг URL.
                </p>
                <p><b>3. Ссылки </b></p>

                <p>Сайт http://doscat.kz может содержать ссылки на другие сайты, не имеющие отношения к нашей компании и принадлежащие третьим лицам. Мы не несем ответственности за точность, полноту и достоверность сведений, размещенных на сайтах третьих лиц, и не берем на себя никаких обязательств по сохранению конфиденциальности информации, оставленной вами на таких сайтах.
                </p>
                <p><b>4. Ограничение ответственности</b></p>

                <p>Мы делаем все возможное для соблюдения настоящей политики конфиденциальности, однако, мы не можем гарантировать сохранность информации в случае воздействия факторов находящихся вне нашего влияния, результатом действия которых станет раскрытие информации. Сайт http://doscat.kz и вся размещенная на нем информация представлены по принципу "как есть” без каких-либо гарантий. Мы не несем ответственности за неблагоприятные последствия, а также за любые убытки, причиненные вследствие ограничения доступа к сайту URL или вследствие посещения сайта и использования размещенной на нем информации.
                </p>
                <p><b>5. Контакты </b></p>

                <p>По вопросам, касающимся настоящей политики, просьба обращаться по адресу: zhkiro@gmail.com</p>

                <h4>  Возврат средств  </h4>

                <p>Если вы допустили ошибку в сумме платежа, вы всегда можете вернуть денежные средства, обратившись в банк-отправитель. В свою очередь, банк должен будет связаться с нами по вашему заявлению. После этого средства будут возвращены на ваш счет.
                </p>

                <h4>  Юридическое лицо  </h4>
                <p>ИП "Dostyk Catering"<br>
                    г.Алматы, Медеуский район, мкр.Самал-3, д.1,<br>
                    БИН 790906400827<br>
                    Расчетный счет АО "Capital Bank Kazakhstan", KZ557812204193986690<br>
                    Свидетельство ИП: Серия 0101 № 0047456<br>
                    Дата выдачи свидетельства: 17 ноября 2016
                </p>
                <p></p>
            </div>
            <!-- Футер модального окна -->
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Закрыть</button>
            </div>
        </div>
    </div>
</div>
</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://bootswatch.com/bower_components/bootstrap/dist/js/bootstrap.min.js" type="text/javascript"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/js/bootstrap-datepicker.min.js"></script>
<script type="text/javascript" src="js/owl.carousel.min.js"></script>
<script type="text/javascript" src="js/jquery.scrollTo.min.js"></script>
<script type="text/javascript" src="js/jquery.inputmask.bundle.js"></script>
<script type="text/javascript" src="js/sweetalert.min.js"></script>
<script type="text/javascript" src="js/js.js"></script>
<script src="https://widget.cloudpayments.kz/bundles/cloudpayments"></script>
<script type="text/javascript">

    this.pay = function () {
        var widget = new cp.CloudPayments();

        var data = {};

        widget.charge({ // options
                publicId: 'pk_3f7df9a08f13077be471d6f35cca5',
                amount: parseFloat($('#inputSum').val()),
                currency: 'KZT',
                <?php
    if (isset($id) and is_numeric($id)) {
        echo 'accountId: '.$id.',';
        echo "description: 'Пополнение баланса пользователя - ".$fname." ".$lname.".',";
    } else {
        echo "invoiceId: $('#inputPhone').val(),";
        echo "description: 'Доставка питания Dostyk Catering: '+ $('#inputPhone').val(),";
        //echo "data : { phone : 'myProp value' }";
    }
    ?>
            },
            function (options) { // success
                // alertObj(options);
                alert("Спасибо! Транзакция принята.");
            },
            function (reason, options) { // fail
                var groups = jQuery.parseJSON(options);
                alert("Ошибка! Попробуйте позже.");
            });
    };

    function alertObj(obj) {
        var str = "";
        for(k in obj) {
            str += k+": "+ obj[k]+"\r\n";
        }
        alert(str);
    }

    var createValidationShim = function ($form) {
        var requiredFields = $form.find("[required]");

        var validateRequired = function (x) {
            if (x.value) {
                $(x).tooltip("hide");
            }
            else {
                $(x).tooltip("show");
            }
            return x.value;
        }

        requiredFields.tooltip({ trigger: "manual" }).change(function (e) {
            if (e.target.value) $(e.target).tooltip("hide");
        });

        return function () {
            var isValid = true;
            requiredFields.each(function (i, x) {
                if(!validateRequired(x)) isValid = false;
            });

            return isValid;
        };
    }

    var isApple = navigator.vendor && navigator.vendor.indexOf('Apple') > -1;

    $(function () {
        var validate = createValidationShim($('#form'));
        $('#form').submit(function (e) {
            e.preventDefault();
            if (isApple) {
                var isValid = validate() && (!e.target.checkValidity || e.target.checkValidity());
                if (isValid) {
                    pay();
                }
            }
            else {
                pay();
            }
        });

        var validate2 = createValidationShim($('#form2'));
        $('#form2').submit(function (e) {
            e.preventDefault();
            if (isApple) {
                var isValid = validate2() && (!e.target.checkValidity || e.target.checkValidity());
                if (isValid) {
                    pay();
                }
            }
            else {
                pay();
            }
        });
    });

    function update_user(action, id) {
        var first_name = $('#user_fname').val();
        var last_name = $('#user_lname').val();
        var phone = $('#user_phone').val();
        var email = $('#user_email').val();
        var db = $('#user_db').val();
        var gym = $("#user_gym").val();
        var check = $('input:checkbox:checked').val();
        var custom = $("#custom_address").val();
        var sum = $("#admin_sum").val();
        var admin_date = $("#admin_date").val();
        if (sum == 0) {
            alert("Введите сумму!");
            return false;
        }
        $.ajax({
            url: "admin/actions.php",
            data: {action: action, id: id, first_name: first_name, last_name: last_name, phone: phone, email: email, db: db,
                gym:gym, check:check, custom:custom, admin_sum:sum,admin_date:admin_date},
            type: "POST",
            success: function (data) {
                switch (action) {
                    case "editUserInfo":
                        if(data){
                            $(".alert1").append(data);
                            $("#alert1").fadeIn( 300 ).delay( 1500 ).fadeOut( 400);
                        } else {
                            $(".alert1").append("<div id='alert1' class='alert-box success'>Профиль изменен</div>");
                            $("#alert1").fadeIn( 300 ).delay( 1500 ).fadeOut( 400);
                        }

                        break;
                    case "editUserGym":
                        $(".alert2").append("<div id='alert2' class='alert-box success'>Спортзал изменен</div>");
                        $("#alert2").fadeIn( 300 ).delay( 1500 ).fadeOut( 400);
                        break;
                    case "editUserAddress":
                        $(".alert3").append("<div id='alert3' class='alert-box success'>Адрес изменен</div>");
                        $("#alert3").fadeIn( 300 ).delay( 1500 ).fadeOut( 400);
                        break;
                    case "addUserBalance":
                        $(".alert4").append("<div id='alert4' class='alert-box success'>Баланс пополнен</div>");
                        $("#alert4").fadeIn( 300 ).delay( 1500 ).fadeOut( 400);
                        setTimeout(function(){
                            location.reload();
                        }, 500);
                        break;
                }
            }
        });
        $("#alert1").remove();
        $("#alert2").remove();
        $("#alert3").remove();
        $("#alert4").remove();
    }
</script>
<script>


    !function(a){a.fn.datepicker.dates.ru={days:["Воскресенье","Понедельник","Вторник","Среда","Четверг","Пятница","Суббота"],daysShort:["Вск","Пнд","Втр","Срд","Чтв","Птн","Суб"],daysMin:["Вс","Пн","Вт","Ср","Чт","Пт","Сб"],months:["Январь","Февраль","Март","Апрель","Май","Июнь","Июль","Август","Сентябрь","Октябрь","Ноябрь","Декабрь"],monthsShort:["Янв","Фев","Мар","Апр","Май","Июн","Июл","Авг","Сен","Окт","Ноя","Дек"],today:"Сегодня",clear:"Очистить",format:"dd.mm.yyyy",weekStart:1}}(jQuery);

    $('.date').datepicker({
            autoclose: true,
            format: 'yyyy-mm-dd',
            language: 'ru',
            todayHighlight: true
        });


</script>
</html>